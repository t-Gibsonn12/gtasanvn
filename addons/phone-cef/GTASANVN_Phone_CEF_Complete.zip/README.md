# Điện thoại CEF GTASANVN

Bộ source dựa trên GTASANVN iPhone SocialFix và dành cho gamemode OMPVN. Khi chạy trong game, dùng `/dienthoai` hoặc `/phonecef`. Esc hoặc nút × đóng điện thoại và trả điều khiển về game.

## Tính năng

- Màn hình khóa, thông báo và màn hình chính với giao diện trung tính.
- Gọi, nghe và cúp máy qua hệ thống cuộc gọi hiện có. Khi điện thoại đóng, cuộc gọi đến báo trên HUD và có thể nhận bằng `/pickup`.
- Tin nhắn CEF lưu theo UID, gửi được cho người offline và hiện trong hộp thư khi họ mở điện thoại. Có thể gửi vị trí ngoài trời và đặt GPS từ tin nhắn. Checkpoint hiện tại được ưu tiên.
- Danh bạ, số dư ngân hàng, hồ sơ nhân vật và thông tin bằng lái.
- Bảng tin có bài viết, ảnh từ URL HTTPS, lượt thích và bình luận.
- Pizza hiện nghề chính/phụ, trạng thái giao hàng và lương chờ nhận. Nút nhận bánh dùng điều kiện của `/laybanh` sẵn có.
- Kho xe hiện xe đang cất, xe đang dùng, tình trạng tạm giữ và nhiên liệu của xe đã lấy ra. Nút định vị, lấy xe, cất xe và lưu chỗ đỗ áp dụng quyền sở hữu và logic xe của gamemode.

## Cài trên server OMPVN đang chạy

1. Dùng cùng bộ compiler, include và plugin của bản OMPVN đã chạy được. Bản này cần CEF server/client tương thích với `includes/cef.inc` và API MySQL legacy của OMPVN. Nếu cần, chép `includes/cef.inc` vào thư mục include của compiler.
2. Sao lưu source và database. Chọn database hiện có của OMPVN và chạy `database/gtasanvn_phone_complete.sql` trên MariaDB. File tạo bảng còn thiếu và giữ lại dữ liệu danh bạ, bài viết cũ. Với MySQL không hỗ trợ cú pháp `ADD COLUMN IF NOT EXISTS`, chỉ chạy lệnh thêm `photo_url` khi bảng bài viết cũ thiếu cột đó.
3. Trên bản SocialFix nguyên gốc, chép đè `gamemodes/main/gtasanvn_phone.pwn`, `gamemodes/main/omp_base.pwn` và cả thư mục `scriptfiles/cef/gtasanvn_phone/`. Nếu đã sửa riêng `omp_base.pwn`, gộp các lời gọi `GTPhoneCallState` trong luồng gọi, nghe và cúp máy vào bản của bạn trước khi biên dịch.
4. Biên dịch `gamemodes/OMPVN.pwn`, khởi động lại server và làm mới cache CEF của client nếu còn thấy giao diện cũ.
5. Dùng hai nhân vật để thử cuộc gọi, nhắn tin, gửi GPS, đăng bài/bình luận và thử lấy/cất một xe sở hữu.

## Xem trước và giới hạn

Mở `scriptfiles/cef/gtasanvn_phone/index.html?demo=1` trong trình duyệt để xem giao diện và điều hướng bằng dữ liệu mẫu. Trong game dùng URL CEF mặc định, không thêm tham số `demo`.

Hộp thư CEF mới lưu giao dịch của chính nó. Tin nhắn cũ từ lệnh chat `/sms` vẫn thuộc hệ thống legacy và không tự nhập vào hộp thư mới. Ứng dụng Máy ảnh hướng dẫn dùng ảnh đã chụp trong game và liên kết HTTPS vì CEF hiện có không cung cấp API chụp/đăng ảnh tự động. Cuộc gọi dùng hệ thống game hiện có, gói này không thêm kênh voice. Gói này dành cho OMPVN SocialFix, không phải bản gamemode Pawn khác đang nằm trên GitHub.
