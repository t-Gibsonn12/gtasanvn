// Aura Speedometer - Pawn hook module for open.mp + aurora-mp/omp-cef
// Include this file in your gamemode: #include "Aura_Speedometer_Hook.pwn"
// Requires open.mp, cef.inc and YSI_Coding/y_hooks.
// Place scriptfiles/cef/speedometer/index.html on your server.

#if defined _AURA_SPEEDOMETER_INCLUDED
    #endinput
#endif
#define _AURA_SPEEDOMETER_INCLUDED

#include <open.mp>
#include <cef>
#include <YSI_Coding\y_hooks>

#define AURA_SPEEDO_BROWSER (52110)
#define AURA_SPEEDO_URL "http://cef/speedometer/index.html"
#define AURA_SPEEDO_INTERVAL (250)

new bool:AuraCefReady[MAX_PLAYERS];
new bool:AuraBrowserReady[MAX_PLAYERS];
new bool:AuraBrowserRequested[MAX_PLAYERS];
new bool:AuraSpeedoVisible[MAX_PLAYERS];
new AuraSpeedoTimer = -1;
new Float:AuraFuel[MAX_VEHICLES];
new Float:AuraOdo[MAX_VEHICLES];
new Float:AuraLastX[MAX_VEHICLES], Float:AuraLastY[MAX_VEHICLES], Float:AuraLastZ[MAX_VEHICLES];
new bool:AuraLastPosValid[MAX_VEHICLES];

forward AuraSpeedometerTick();

stock AuraSpeedoSend(playerid)
{
    if (!AuraBrowserReady[playerid]) return 0;
    new vehicleid = GetPlayerVehicleID(playerid);
    if (!vehicleid || GetPlayerState(playerid) != PLAYER_STATE_DRIVER)
    {
        if (AuraSpeedoVisible[playerid])
        {
            CEF_EmitEvent(playerid, AURA_SPEEDO_BROWSER, "speedo:hide");
            AuraSpeedoVisible[playerid] = false;
        }
        return 1;
    }

    new Float:vx, Float:vy, Float:vz, Float:health;
    GetVehicleVelocity(vehicleid, vx, vy, vz);
    GetVehicleHealth(vehicleid, health);
    new speed = floatround(floatsqroot(vx*vx + vy*vy + vz*vz) * 180.0);
    if (speed > 240) speed = 240;
    new engine, lights, alarm, doors, bonnet, boot, objective;
    GetVehicleParamsEx(vehicleid, engine, lights, alarm, doors, bonnet, boot, objective);
    new hp = floatround((health - 250.0) / 7.5);
    if (hp < 0) hp = 0;
    if (hp > 100) hp = 100;
    new fuel = floatround(AuraFuel[vehicleid]);
    if (fuel < 0) fuel = 0;
    if (fuel > 100) fuel = 100;
    CEF_EmitEvent(playerid, AURA_SPEEDO_BROWSER, "speedo:update",
        CEF_INT(speed), CEF_INT(fuel), CEF_INT(hp),
        CEF_INT(floatround(AuraOdo[vehicleid])), CEF_BOOL(engine == VEHICLE_PARAMS_ON),
        CEF_BOOL(lights == VEHICLE_PARAMS_ON), CEF_BOOL(doors == VEHICLE_PARAMS_ON));
    AuraSpeedoVisible[playerid] = true;
    return 1;
}

public AuraSpeedometerTick()
{
    for (new v = 1; v < MAX_VEHICLES; v++)
    {
        if (!IsValidVehicle(v)) { AuraLastPosValid[v] = false; continue; }
        new Float:x, Float:y, Float:z;
        GetVehiclePos(v, x, y, z);
        if (AuraLastPosValid[v])
        {
            new Float:dist = floatsqroot(floatpower(x-AuraLastX[v],2.0) + floatpower(y-AuraLastY[v],2.0) + floatpower(z-AuraLastZ[v],2.0));
            if (dist < 30.0) AuraOdo[v] += dist / 1000.0;
        }
        AuraLastX[v] = x; AuraLastY[v] = y; AuraLastZ[v] = z;
        AuraLastPosValid[v] = true;
    }
    for (new playerid = 0; playerid < MAX_PLAYERS; playerid++)
    {
        if (IsPlayerConnected(playerid) && AuraCefReady[playerid] && AuraBrowserReady[playerid]) AuraSpeedoSend(playerid);
    }
    return 1;
}

hook OnGameModeInit()
{
    CEF_AddResource("speedometer");
    for (new v = 1; v < MAX_VEHICLES; v++) AuraFuel[v] = 100.0;
    AuraSpeedoTimer = SetTimer("AuraSpeedometerTick", AURA_SPEEDO_INTERVAL, true);
    return 1;
}

hook OnGameModeExit()
{
    if (AuraSpeedoTimer != -1) KillTimer(AuraSpeedoTimer);
    return 1;
}

hook OnPlayerConnect(playerid)
{
    AuraCefReady[playerid] = false;
    AuraBrowserReady[playerid] = false;
    AuraBrowserRequested[playerid] = false;
    AuraSpeedoVisible[playerid] = false;
    return 1;
}

hook OnPlayerDisconnect(playerid, reason)
{
    AuraCefReady[playerid] = false;
    AuraBrowserReady[playerid] = false;
    AuraBrowserRequested[playerid] = false;
    AuraSpeedoVisible[playerid] = false;
    return 1;
}

hook OnCefInitialize(playerid, bool:success, E_CEF_INIT_REASON:reason, const message[])
{
    AuraCefReady[playerid] = success;
    return 1;
}

hook OnCefReady(playerid)
{
    if (!AuraCefReady[playerid] || AuraBrowserRequested[playerid]) return 1;
    AuraBrowserRequested[playerid] = true;
    CEF_CreateBrowser(playerid, AURA_SPEEDO_BROWSER, AURA_SPEEDO_URL, false);
    return 1;
}

hook OnCefBrowserCreated(playerid, browserid, bool:success, E_CEF_CREATE_STATUS:code, const reason[])
{
    if (browserid != AURA_SPEEDO_BROWSER) return 1;
    AuraBrowserReady[playerid] = success;
    if (success)
    {
        CEF_SetBrowserVisible(playerid, AURA_SPEEDO_BROWSER, true);
        CEF_EmitEvent(playerid, AURA_SPEEDO_BROWSER, "speedo:hide");
    }
    else AuraBrowserRequested[playerid] = false;
    return 1;
}

// Call these from your fuel system or vehicle spawn/destruction hooks.
stock AuraSetVehicleFuel(vehicleid, Float:amount)
{
    if (vehicleid < 1 || vehicleid >= MAX_VEHICLES) return 0;
    if (amount < 0.0) amount = 0.0;
    if (amount > 100.0) amount = 100.0;
    AuraFuel[vehicleid] = amount;
    return 1;
}
stock AuraResetVehicleSpeedo(vehicleid)
{
    if (vehicleid < 1 || vehicleid >= MAX_VEHICLES) return 0;
    AuraFuel[vehicleid] = 100.0;
    AuraOdo[vehicleid] = 0.0;
    AuraLastPosValid[vehicleid] = false;
    return 1;
}
