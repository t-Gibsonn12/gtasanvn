// Aura CEF Notify test module for open.mp, based on the supplied cef.inc.
// Include in your gamemode: #include "Aura_Notify_Hook.pwn"
// Dependencies: open.mp, cef.inc, YSI_Coding/y_hooks.
#if defined _AURA_NOTIFY_HOOK
    #endinput
#endif
#define _AURA_NOTIFY_HOOK

#include <a_samp>
#include <cef>
#include <YSI_Coding\y_hooks>

#define AURA_NOTIFY_BROWSER_ID (52111)
#define AURA_NOTIFY_URL "http://cef/notify/index.html?game=1"

new bool:gAuraNotifyReady[MAX_PLAYERS];
new bool:gAuraNotifyRequested[MAX_PLAYERS];
new bool:gAuraNotifyCreated[MAX_PLAYERS];

forward AuraNotifyFirstTest(playerid);

stock AuraNotifyShow(playerid, const type[], const title[], const message[], duration = 5000)
{
    if (!IsPlayerConnected(playerid) || !gAuraNotifyCreated[playerid]) return 0;
    if (duration < 500) duration = 500;
    if (duration > 60000) duration = 60000;
    CEF_EmitEvent(playerid, AURA_NOTIFY_BROWSER_ID, "notify:show",
        CEF_STR(type), CEF_STR(title), CEF_STR(message), CEF_INT(duration));
    return 1;
}

public AuraNotifyFirstTest(playerid)
{
    if (!IsPlayerConnected(playerid) || !gAuraNotifyCreated[playerid]) return 1;
    AuraNotifyShow(playerid, "success", "CEF DA KET NOI", "Thong bao tu Pawn: tu tat sau 5 giay!", 5000);
    return 1;
}

hook OnGameModeInit()
{
    CEF_AddResource("notify");
    return 1;
}

hook OnPlayerConnect(playerid)
{
    gAuraNotifyReady[playerid] = false;
    gAuraNotifyRequested[playerid] = false;
    gAuraNotifyCreated[playerid] = false;
    return 1;
}

hook OnPlayerDisconnect(playerid, reason)
{
    gAuraNotifyReady[playerid] = false;
    gAuraNotifyRequested[playerid] = false;
    gAuraNotifyCreated[playerid] = false;
    return 1;
}

hook OnCefInitialize(playerid, bool:success, E_CEF_INIT_REASON:reason, const message[])
{
    if (!success) SendClientMessage(playerid, 0xFF7777FF, "[CEF] Khoi tao that bai. Kiem tra client CEF.");
    return 1;
}

hook OnCefReady(playerid)
{
    gAuraNotifyReady[playerid] = true;
    if (!gAuraNotifyRequested[playerid])
    {
        gAuraNotifyRequested[playerid] = true;
        CEF_CreateBrowser(playerid, AURA_NOTIFY_BROWSER_ID, AURA_NOTIFY_URL, false);
    }
    return 1;
}

hook OnCefBrowserCreated(playerid, browserid, bool:success, E_CEF_CREATE_STATUS:code, const reason[])
{
    if (browserid != AURA_NOTIFY_BROWSER_ID) return 1;
    if (!success)
    {
        gAuraNotifyRequested[playerid] = false;
        SendClientMessage(playerid, 0xFF7777FF, "[CEF] Tao browser Notify that bai. Kiem tra URL/resource.");
        return 1;
    }
    gAuraNotifyCreated[playerid] = true;
    CEF_SetBrowserLayer(playerid, AURA_NOTIFY_BROWSER_ID, 10);
    CEF_SetBrowserVisible(playerid, AURA_NOTIFY_BROWSER_ID, true);
    SendClientMessage(playerid, 0x7CFFB0FF, "[CEF] Notify da san sang! /testnotify /testerror /testwarning /testinfo");
    // Allow the HTML/JS to finish loading before the first event.
    SetTimerEx("AuraNotifyFirstTest", 1200, false, "i", playerid);
    return 1;
}

hook OnPlayerCommandText(playerid, cmdtext[])
{
    if (!strcmp(cmdtext, "/testnotify", true))
    {
        if (!AuraNotifyShow(playerid, "success", "THANH CONG", "Ban da nhan duoc $5,000!", 5000))
            SendClientMessage(playerid, 0xFF7777FF, "[CEF] Notify chua san sang.");
        return 1;
    }
    if (!strcmp(cmdtext, "/testerror", true))
    {
        AuraNotifyShow(playerid, "error", "THAT BAI", "Ban khong co du tien!", 5000);
        return 1;
    }
    if (!strcmp(cmdtext, "/testwarning", true))
    {
        AuraNotifyShow(playerid, "warning", "CANH BAO", "Ban dang o khu vuc nguy hiem!", 5000);
        return 1;
    }
    if (!strcmp(cmdtext, "/testinfo", true))
    {
        AuraNotifyShow(playerid, "info", "THONG BAO", "Chao mung den voi Roleplay!", 5000);
        return 1;
    }
    return 0;
}
