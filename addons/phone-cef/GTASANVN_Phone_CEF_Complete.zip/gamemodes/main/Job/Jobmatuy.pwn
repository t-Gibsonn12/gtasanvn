#include <a_samp>
#include <a_mysql>
#include <foreach>
#include <ZCMD>
#include <YSI_Coding\y_hooks>

#define DIALOG_NHANCONGVIECMATUY (2100)
#define DIALOG_UPDATEMATUY (2101)
#define DIALOG_LAMVIECMATUY (2102)
#define DIALOG_CVMATUY (2103)
#define DIALOG_RUATIENBAN (2104)

#define POS_1 2635.6682,-2012.9988,14.1443,303.8497
#define POS_2 2073.3630,-1583.2140,13.4741,86.0014
#define POS_3 1550.0555,-33.7871,21.3330,354.0240
#define POS_4 2086.1667,2154.0652,10.8203,358.6847
#define POS_5 2039.6442,2765.3362,10.8203,179.5215
#define POS_6 -346.5252,-1045.8179,59.8125,177.5973


new NPCmatuy1,NPCmatuy2,NPCmatuy3,NPCmatuy4,NPCmatuy5,NPCmatuy6;
new Npc_lamviec;
new Npcruatienban;

new chiecxematuy;

new giatritienban;


stock On_GameModeInit(){
	new playerid;
	new xuongmatuy;

	Npcruatienban = CreateActor(28,POS_6);
	CreateDynamic3DTextLabel("DynZ's\nChuyen Rua Tien Ban", COLOR_SYNTAX , -346.5252,-1045.8179,59.8125+1, 20.0);

    NPCmatuy1 = CreateActor(125, -78.4655,-1555.0226,2.6107,138.0392);
    /*CreateDynamic3DTextLabel("Dan Em - Phan Phoi Ma Tuy", COLOR_SYNTAX , -78.4655,-1555.0226,2.6107+1, 20.0);*/
    ApplyActorAnimation(NPCmatuy1, "BD_FIRE", "wash_up", 4.0, 1, 0, 0, 0, 0);

    NPCmatuy2 = CreateActor(126, -75.1784,-1557.8827,2.6107,139.1881);
    /*CreateDynamic3DTextLabel("Dan Em - Phan Phoi Ma Tuy", COLOR_SYNTAX , -78.4655,-1555.0226,2.6107+1, 20.0);*/
    ApplyActorAnimation(NPCmatuy2, "BD_FIRE", "wash_up", 4.0, 1, 0, 0, 0, 0);
    
    NPCmatuy3 = CreateActor(124, -71.9554,-1560.6855,2.6107,134.8223);
    /*CreateDynamic3DTextLabel("Dan Em - Phan Phoi Ma Tuy", COLOR_SYNTAX , -78.4655,-1555.0226,2.6107+1, 20.0);*/
    ApplyActorAnimation(NPCmatuy3, "BD_FIRE", "wash_up", 4.0, 1, 0, 0, 0, 0);

    NPCmatuy4 = CreateActor(125, -74.7292,-1563.7338,2.6107,322.0278);
    /*CreateDynamic3DTextLabel("Dan Em - Phan Phoi Ma Tuy", COLOR_SYNTAX , -78.4655,-1555.0226,2.6107+1, 20.0);*/
    ApplyActorAnimation(NPCmatuy4, "BD_FIRE", "wash_up", 4.0, 1, 0, 0, 0, 0);

    NPCmatuy5 = CreateActor(124, -77.8665,-1561.0067,2.6107,319.0406);
    /*CreateDynamic3DTextLabel("Dan Em - Phan Phoi Ma Tuy", COLOR_SYNTAX , -78.4655,-1555.0226,2.6107+1, 20.0);*/
    ApplyActorAnimation(NPCmatuy5, "BD_FIRE", "wash_up", 4.0, 1, 0, 0, 0, 0);

    NPCmatuy6 = CreateActor(126, -81.1320,-1558.1702,2.6107,319.0406);
    /*CreateDynamic3DTextLabel("Dan Em - Phan Phoi Ma Tuy", COLOR_SYNTAX , -78.4655,-1555.0226,2.6107+1, 20.0);*/
    ApplyActorAnimation(NPCmatuy6, "BD_FIRE", "wash_up", 4.0, 1, 0, 0, 0, 0);

    Npc_lamviec = CreateActor(293, -82.8366,-1555.4144,2.6107,319.3400);
    CreateDynamic3DTextLabel("Dai Ca - Cho Dau Moi", COLOR_SYNTAX , -82.8366,-1555.4144,2.6107+1, 20.0);
    ApplyActorAnimation(Npc_lamviec, "DEALER", "shop_pay", 4.1,0,0,0,0,0);
	
	RemoveBuildingForPlayer(playerid, 1413, -53.812, -1585.859, 3.085, 0.250);
	RemoveBuildingForPlayer(playerid, 1447, -50.828, -1581.770, 3.164, 0.250);
	RemoveBuildingForPlayer(playerid, 1412, -47.554, -1577.650, 3.164, 0.250);
	RemoveBuildingForPlayer(playerid, 1412, -44.562, -1573.369, 3.164, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -43.742, -1563.689, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 3174, -44.289, -1561.310, 1.679, 0.250);
	RemoveBuildingForPlayer(playerid, 727, -49.398, -1560.010, 1.460, 0.250);
	RemoveBuildingForPlayer(playerid, 3175, -55.281, -1557.449, 1.406, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -56.156, -1560.459, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -64.000, -1550.260, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 3173, -67.234, -1544.219, 1.554, 0.250);
	RemoveBuildingForPlayer(playerid, 1438, -77.062, -1542.599, 1.617, 0.250);
	RemoveBuildingForPlayer(playerid, 3173, -90.640, -1562.939, 1.554, 0.250);
	RemoveBuildingForPlayer(playerid, 1438, -93.210, -1569.479, 1.500, 0.250);
	RemoveBuildingForPlayer(playerid, 1457, -91.015, -1576.630, 3.195, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -100.819, -1580.420, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 3175, -101.819, -1577.689, 1.406, 0.250);
	RemoveBuildingForPlayer(playerid, 727, -73.820, -1569.170, 1.351, 0.250);
	RemoveBuildingForPlayer(playerid, 1457, -71.000, -1574.089, 3.195, 0.250);
	RemoveBuildingForPlayer(playerid, 3175, -77.937, -1581.310, 1.406, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -74.187, -1583.989, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 1472, -75.585, -1581.069, 2.023, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -61.664, -1573.459, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 3175, -64.382, -1572.209, 1.406, 0.250);
	RemoveBuildingForPlayer(playerid, 1438, -62.273, -1569.290, 1.500, 0.250);
	RemoveBuildingForPlayer(playerid, 1438, -56.062, -1575.660, 1.500, 0.250);
	RemoveBuildingForPlayer(playerid, 1447, -66.289, -1601.229, 3.210, 0.250);
	RemoveBuildingForPlayer(playerid, 1412, -70.414, -1604.380, 3.460, 0.250);
	RemoveBuildingForPlayer(playerid, 1447, -74.820, -1607.260, 3.460, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -72.414, -1596.770, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 1438, -79.257, -1593.469, 1.500, 0.250);
	RemoveBuildingForPlayer(playerid, 3174, -75.171, -1596.300, 1.679, 0.250);
	RemoveBuildingForPlayer(playerid, 1438, -88.109, -1598.719, 1.500, 0.250);
	RemoveBuildingForPlayer(playerid, 3173, -93.093, -1593.520, 1.554, 0.250);
	RemoveBuildingForPlayer(playerid, 1370, -86.570, -1595.140, 2.156, 0.250);
	RemoveBuildingForPlayer(playerid, 1462, -93.679, -1588.079, 1.507, 0.250);

	xuongmatuy = CreateDynamicObject(10831, -77.805480, -1564.251708, 6.101606, 0.000000, 0.000000, 48.799980, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 9514, "711_sfw", "shingles2", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 1, 16640, "a51", "ws_stationfloor", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -82.237632, -1560.312377, 2.260718, 0.000004, 0.000004, 48.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 1, 19076, "xmastree1", "goldplate", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 2, 19076, "xmastree1", "goldplate", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -71.511123, -1558.777954, 2.260718, 0.000004, 0.000004, 48.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -75.626976, -1570.835327, 2.260718, 0.000015, 0.000003, 138.799972, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -70.976097, -1565.523315, 2.260718, 0.000015, 0.000003, 138.799972, -1, -1, -1, 300.00, 300.00);
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -82.379455, -1571.194213, 2.260718, 0.000004, 0.000004, 48.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -76.925590, -1564.962280, 2.260718, 0.000004, 0.000004, 48.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -87.685005, -1566.534545, 2.260718, 0.000004, 0.000004, 48.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -76.843009, -1554.148925, 2.260718, 0.000004, 0.000004, 48.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -78.071510, -1556.652709, 2.626004, 0.000000, 0.000000, -41.500007, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -79.575202, -1555.133911, 2.626004, -0.000004, 0.000004, -69.999984, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -79.577537, -1555.207641, 2.736005, 0.000000, 0.000007, -20.100008, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -80.294418, -1557.944458, 2.626004, -0.000004, 0.000004, -49.299987, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -79.784759, -1558.522338, 2.626004, -0.000004, 0.000004, -49.299987, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -79.936943, -1557.727661, 2.736005, 0.000000, 0.000007, 0.599996, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -81.138259, -1557.139160, 2.626004, -0.000012, 0.000007, -77.799972, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -80.725982, -1556.773681, 2.626004, -0.000012, 0.000007, -77.799972, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -75.206848, -1559.535522, 2.626004, -0.000009, 0.000009, -49.299987, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -75.546920, -1559.258789, 2.736005, 0.000000, 0.000014, 0.599996, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -76.920440, -1557.919311, 2.626004, -0.000018, 0.000009, -77.799972, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -76.502830, -1557.899291, 2.736005, -0.000004, 0.000020, -27.899995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -77.544960, -1560.015258, 2.626004, -0.000027, 0.000011, -67.699966, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -77.438568, -1559.213256, 2.736005, -0.000007, 0.000028, -17.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -73.229850, -1563.740112, 2.626004, -0.000020, 0.000020, -39.199989, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 1, 18901, "matclothes", "zorromask", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 2, 18901, "matclothes", "zorromask", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -75.106170, -1561.906616, 2.626004, -0.000034, 0.000014, -67.699966, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -74.699142, -1561.739868, 2.626004, -0.000034, 0.000014, -67.699966, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -72.632926, -1561.879272, 2.626004, -0.000025, 0.000027, -39.199989, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -72.029830, -1562.358886, 2.626004, -0.000025, 0.000027, -39.199989, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -72.319015, -1561.603271, 2.736005, 0.000003, 0.000037, 10.699995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -73.263122, -1560.802368, 2.626004, -0.000040, 0.000017, -67.699966, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(1575, -73.498519, -1560.432373, 2.736005, -0.000012, 0.000041, -17.799995, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 14674, "civic02cj", "sl_hotelwallplain1", 0x00000000);
	xuongmatuy = CreateDynamicObject(19379, -85.804061, -1557.190795, 2.260718, 0.000004, 0.000004, 138.799987, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(xuongmatuy, 0, 16640, "a51", "concretemanky", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 1, 19076, "xmastree1", "goldplate", 0x00000000);
	SetDynamicObjectMaterial(xuongmatuy, 2, 19076, "xmastree1", "goldplate", 0x00000000);
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	xuongmatuy = CreateDynamicObject(11290, -60.000667, -1542.939453, 6.800726, 0.000000, 0.000000, -132.100021, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3292, -100.874191, -1576.028076, 1.429680, 0.000000, 0.000000, -40.900012, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -110.169410, -1576.904663, 3.137187, 0.000000, 0.000000, -57.000102, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -103.390907, -1588.116210, 3.137187, 0.000000, 0.000000, -57.700111, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -100.931838, -1586.130981, 3.127187, 0.000000, 0.000000, 126.399803, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -106.511039, -1566.631225, 3.137187, 0.000000, 0.000000, -136.200057, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -97.131950, -1562.588989, 3.137187, 0.000000, 0.000000, 49.499942, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -87.059532, -1547.365356, 3.137187, 0.000000, 0.000000, -135.800064, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3630, -88.864929, -1579.830810, 3.026159, 0.000000, 0.000000, -130.800033, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3630, -85.534133, -1582.705444, 3.026159, 0.000000, 0.000000, -130.800033, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3643, -83.245933, -1587.896972, 6.232484, 0.000000, 0.000000, -44.899986, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1684, -85.719039, -1610.483886, 3.104412, 0.000000, 0.000000, -151.900039, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2567, -80.549148, -1607.221679, 3.757066, 0.000000, -7.599997, -61.700008, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2567, -78.189521, -1605.950195, 3.757066, 0.000000, -7.599997, -61.700008, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3630, -94.979347, -1601.597778, 3.026159, 0.000000, 0.000000, -57.200008, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -86.368209, -1572.958129, 3.127187, 0.000000, 0.000000, -41.400173, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(18260, -71.601104, -1556.207153, 3.127187, 0.000000, 0.000000, -41.400173, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3799, -61.667587, -1563.059814, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3799, -77.346267, -1580.275878, 1.610720, 0.000000, 0.000000, -20.199996, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3761, -75.807502, -1572.326538, 3.567188, 0.000000, 0.000000, -41.399993, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3761, -69.366340, -1565.020996, 3.567188, 0.000000, 0.000000, -41.399993, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3799, -72.070259, -1569.091796, 1.480718, 0.000000, 0.000000, -40.800014, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3799, -72.176216, -1568.999877, 3.710717, 0.000000, 0.000000, -40.800014, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1685, -78.763885, -1546.122558, 2.340718, 0.000000, 0.000000, -41.900009, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1685, -76.873336, -1547.819213, 2.340718, 0.000000, 0.000000, -41.900009, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1685, -78.041885, -1546.770507, 3.840718, 0.000000, 0.000000, -41.900009, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(931, -94.642837, -1566.802001, 2.660720, 0.000000, 0.000000, -41.199996, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(931, -92.332916, -1568.823608, 2.660720, 0.000000, 0.000000, -41.199996, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1685, -73.679695, -1577.858764, 2.197185, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3383, -72.754081, -1561.561645, 1.610720, 0.000000, 0.000000, -41.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3383, -73.902214, -1562.882690, 1.610720, 0.000000, 0.000000, 139.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3383, -77.132270, -1560.074707, 1.610720, 0.000000, 0.000000, 139.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3383, -80.407623, -1557.227539, 1.610720, 0.000000, 0.000000, 139.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3383, -75.976631, -1558.760620, 1.610720, 0.000000, 0.000000, -41.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3383, -79.252029, -1555.914550, 1.610720, 0.000000, 0.000000, -41.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -78.770721, -1556.688110, 2.626004, 0.000000, 0.000000, -41.500007, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3593, -89.667243, -1594.954223, 2.050719, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -78.187355, -1557.191406, 2.626004, 0.000000, 0.000000, -41.500007, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3593, -87.162117, -1595.014160, 2.711004, -12.100006, 0.000000, -93.200004, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1386, -47.506149, -1565.747314, 8.257181, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2935, -47.563785, -1564.540649, 3.481410, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -79.716049, -1556.004760, 2.626004, -0.000004, 0.000004, -69.999984, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -79.357192, -1555.586669, 2.626004, -0.000004, 0.000004, -69.999984, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3578, -71.397422, -1604.916015, 2.582294, 0.000000, 0.799999, 35.600006, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -79.960830, -1557.657958, 2.626004, -0.000004, 0.000004, -49.299987, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -79.596870, -1558.004394, 2.626004, -0.000004, 0.000004, -49.299987, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(9131, -43.031276, -1571.485473, 2.734821, 0.000000, 0.000000, 59.200004, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(9131, -50.290374, -1583.602661, 2.734821, 0.000000, 0.000000, 52.900020, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -80.880531, -1556.295532, 2.626004, -0.000012, 0.000007, -77.799972, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(9131, -57.106651, -1592.088500, 2.734193, -0.600000, 0.000000, 45.700057, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(9131, -66.892959, -1601.696411, 2.730843, -0.600000, 0.000000, 34.500064, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3568, -78.799629, -1601.051269, 3.947186, 0.000000, 0.000000, -88.899932, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -75.570808, -1559.189086, 2.626004, -0.000009, 0.000009, -49.299987, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(849, -66.069084, -1586.110351, 1.957454, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(849, -55.709079, -1578.950439, 1.897454, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -76.490509, -1557.826660, 2.626004, -0.000018, 0.000009, -77.799972, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(910, -74.177650, -1584.304199, 2.908411, 0.000000, 0.000000, 57.199977, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -76.335960, -1558.304809, 2.626004, -0.000018, 0.000009, -77.799972, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(13591, -51.953853, -1572.877075, 1.899779, 0.000000, 0.000000, -92.800003, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(14600, -61.147338, -1567.146362, 1.610720, 0.000000, 0.000000, 133.399993, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2674, -56.836151, -1585.980712, 1.801025, 0.000000, -0.899999, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -75.969879, -1561.139770, 2.626004, -0.000015, 0.000014, -39.199989, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -75.875724, -1560.596801, 2.626004, -0.000015, 0.000014, -39.199989, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -76.169982, -1560.855468, 2.736005, 0.000000, 0.000022, 10.699995, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2674, -61.828735, -1580.174560, 1.660720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -77.846199, -1559.306274, 2.626004, -0.000027, 0.000011, -67.699966, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -77.439170, -1559.139526, 2.626004, -0.000027, 0.000011, -67.699966, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -77.203170, -1559.583251, 2.626004, -0.000027, 0.000011, -67.699966, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -77.585197, -1559.670043, 2.736005, -0.000007, 0.000028, -17.799995, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2674, -72.440940, -1592.471801, 1.627187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2677, -65.642662, -1594.918212, 1.935010, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -73.135696, -1563.197143, 2.626004, -0.000020, 0.000020, -39.199989, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(2677, -68.637298, -1571.171997, 1.957187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1369, -70.287117, -1572.128906, 2.197186, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1462, -63.478187, -1568.250122, 1.597187, 0.000000, 0.000000, -137.900024, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -74.463142, -1562.183593, 2.626004, -0.000034, 0.000014, -67.699966, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1462, -62.411952, -1566.908325, 1.597187, 0.000000, 0.000000, -137.900024, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(926, -60.870998, -1588.467773, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -72.354751, -1561.538696, 2.626004, -0.000025, 0.000027, -39.199989, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -71.935676, -1561.815917, 2.626004, -0.000025, 0.000027, -39.199989, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(922, -57.966541, -1583.227416, 2.520719, 0.000000, -1.399999, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3462, -76.232452, -1570.714111, 3.010719, 0.000000, 0.000000, -29.199995, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -73.499122, -1560.358642, 2.626004, -0.000040, 0.000017, -67.699966, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -73.604911, -1561.234375, 2.626004, -0.000040, 0.000017, -67.699966, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -75.930618, -1586.387207, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -78.142944, -1586.331909, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -77.355575, -1587.596679, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -72.540344, -1588.494018, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(3462, -78.433441, -1572.493774, 2.045326, 0.000000, 83.599967, 51.500003, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -75.122070, -1594.438232, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -80.615097, -1593.527343, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -75.340270, -1591.094726, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -68.554374, -1593.589599, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -68.662948, -1600.442993, 1.796988, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -54.296424, -1561.515258, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -52.166236, -1557.544799, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -46.030490, -1557.331420, 1.613204, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -61.080394, -1557.332885, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -68.009300, -1549.733154, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
	xuongmatuy = CreateDynamicObject(692, -75.841529, -1539.515747, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -83.348251, -1546.434570, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -81.117965, -1541.336791, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -81.342857, -1544.568969, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -74.218002, -1541.301757, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -77.278503, -1538.686523, 1.610720, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -68.639846, -1545.552246, 1.617187, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(692, -63.499656, -1552.163818, 1.632269, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1685, -84.056236, -1557.387451, 2.290719, 0.000000, 0.000000, -43.499996, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(19922, -77.313796, -1565.939086, 1.610720, 0.000000, 0.000000, -41.099967, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(19922, -80.094467, -1563.513427, 1.610720, 0.000000, 0.000000, -41.099967, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(19922, -83.417686, -1560.614379, 1.610720, 0.000000, 0.000000, -41.099967, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(19922, -86.382431, -1564.012817, 1.610720, 0.000000, 0.000000, -41.099967, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(19922, -83.098670, -1566.956909, 1.610720, 0.000000, 0.000000, -41.099967, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(19922, -80.298263, -1569.359985, 1.610720, 0.000000, 0.000000, -41.099967, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1579, -80.249267, -1569.417236, 2.330719, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1579, -79.809265, -1569.917724, 2.330719, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1580, -79.602348, -1569.400634, 2.360719, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1580, -81.062347, -1568.730346, 2.360719, 0.000000, 0.000000, -94.099990, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(351, -76.684974, -1566.805541, 2.487226, -96.599922, -40.499996, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1271, -79.829765, -1564.007690, 2.810719, 0.000000, 0.000000, -40.399997, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1271, -77.577560, -1565.663330, 2.640719, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1578, -82.913955, -1566.913696, 2.360719, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1578, -83.633972, -1566.913696, 2.380719, 0.000000, 0.000000, -88.499992, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -82.445335, -1567.431518, 2.320719, 0.000000, 0.000000, -37.399990, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -86.679588, -1564.194458, 2.280719, 0.000000, 0.000000, -37.399990, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -86.303062, -1563.702514, 2.280719, 0.000000, 0.000000, -37.399990, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1575, -85.689422, -1564.612182, 2.280719, 0.000000, 0.000000, -128.999984, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1271, -80.857833, -1563.132934, 2.810719, 0.000000, 0.000000, -40.399997, -1, -1, -1, 300.00, 300.00); 
	xuongmatuy = CreateDynamicObject(1271, -80.789314, -1563.191284, 3.460719, 0.000000, 0.000000, -40.399997, -1, -1, -1, 300.00, 300.00);
	return 1;
}

hook OnGameModeExit(playerid){
	DeletePVar(playerid,"Dangluachon");
    DeletePVar(playerid, "giaohangmatuyda");
    DeletePVar(playerid, "giaohangmatuyvien");
    DeletePVar(playerid, "giaohangthuoclac");
    DeletePVar(playerid, "giaohangcansa");
    DeletePVar(playerid, "giaohangmatuytem");
    DeletePVar(playerid,"diadiemnhantien1");
    DeletePVar(playerid,"diadiemnhantien2");
    DeletePVar(playerid,"diadiemnhantien3");
    DeletePVar(playerid,"diadiemnhantien4");
    DeletePVar(playerid,"diadiemnhantien5");
	DestroyVehicle(chiecxematuy);
	RemovePlayerAttachedObject(playerid, 0);
	return 1;
}

hook OnPlayerDisconnect(playerid, reason){
	DeletePVar(playerid,"Dangluachon");
    DeletePVar(playerid, "giaohangmatuyda");
    DeletePVar(playerid, "giaohangmatuyvien");
    DeletePVar(playerid, "giaohangthuoclac");
    DeletePVar(playerid, "giaohangcansa");
    DeletePVar(playerid, "giaohangmatuytem");
    DeletePVar(playerid,"diadiemnhantien1");
    DeletePVar(playerid,"diadiemnhantien2");
    DeletePVar(playerid,"diadiemnhantien3");
    DeletePVar(playerid,"diadiemnhantien4");
    DeletePVar(playerid,"diadiemnhantien5");
	RemovePlayerAttachedObject(playerid, 0);
	return 1;
}

/*CMD:noichuyennpc(playerid,params[]){
	if(GetPVarInt(playerid,"Danghuongdan") == 1) return SCM(playerid,COLOR_RED,"He Thong Loi: Ban dang trong qua trinh huong dan cong viec roi!");
	if(IsPlayerInRangeOfActor(playerid,NPChuongdan,4.0)){
		ShowPlayerDialog(playerid,DIALOG_HUONGDANMATUY,DIALOG_STYLE_LIST,"HUONG DAN","Nhan Cong Viec\nHuong Dan\nUpdate..","Dong y","Huy bo");	
	}
	SetPVarInt(playerid,"Danghuongdan",1);
	return 1;
}*/

CMD:tienban(playerid,params[]){
	new string[128];
	format(string,sizeof(string),"Tien Ban Hien Co: %d$",PlayerInfo[playerid][pTienban]);
	SendClientMessage(playerid,-1,string);
	return 1;
}

hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys){
	if(IsPlayerInRangeOfActor(playerid,Npc_lamviec,5.0)){
		if(newkeys & KEY_YES){
			if(PlayerInfo[playerid][pLevel] >= 3){
				if(GetPVarInt(playerid,"Dangluachon") == 0){
					ShowPlayerDialog(playerid,DIALOG_LAMVIECMATUY,DIALOG_STYLE_TABLIST,"[Dai Ca - CHO DAU MOI]","Lay Hang\nUpdate..","Dong y","Huy bo");
					SetPVarInt(playerid,"Dangluachon",1);
					return 1;
				}
			}else{
				SCM(playerid,COLOR_RED,"Cong Viec: Ban can dat du level 3 de lam cong viec nay!");
			}
		}
	}
	if(IsPlayerInRangeOfActor(playerid,Npcruatienban,5.0)){
		if(newkeys & KEY_YES){
			ShowPlayerDialog(playerid,DIALOG_RUATIENBAN,DIALOG_STYLE_INPUT,"DynZ's - Rua Tien Ban","Hay nhap so tien can rua:","Dong y","Huy bo");
			SetPVarInt(playerid,"Dangruatien",1);
		}
	}
	return 1;
}

/*CMD:laymatuy(playerid,params[]){
	if(GetPVarInt(playerid,  "luachonmatuy") == 1) return SCM(playerid,COLOR_RED,"Cong Viec: Ban dang trong qua trinh lam viec roi!");
	if(PlayerInfo[playerid][pLevel] >= 3){
		if(IsPlayerInRangeOfActor(playerid,Npclamviec,4.0)){
			ShowPlayerDialog(playerid,DIALOG_LAMVIECMATUY,DIALOG_STYLE_TABLIST,"[TRO LY - CHO DAU MOI]","Bat Dau Lam Viec\nHuong Dan Cong Viec","Dong y","Huy bo");		
			SetPVarInt(playerid, "luachonmatuy", 1);
			return 1;
		}
	}else{
		SCM(playerid,COLOR_RED,"Cong Viec: Ban can dat du level 3 de lam cong viec nay!");
	}
	return 1;
}*/

stock Matuy_OnDialogResponse(playerid, dialogid, response, listitem,inputtext[]){
	if(dialogid == DIALOG_LAMVIECMATUY){
		if(response){
			if(listitem == 0){
				if(GetPVarInt(playerid,"Dangluachon") == 1){
					ShowPlayerDialog(playerid,DIALOG_CVMATUY,DIALOG_STYLE_TABLIST,"LUA CHON MAT HANG","Ma Tuy Vien\t5g\t50k/Luot\tThue Nhap Hang 20k/Luot\nMa Tuy Da\t5 Bich\t100k/Luot\tThue Nhap Hang 40k/Luot\n\
					Thuoc Lac\tBich/5 Vien\t110k/Luot\tThue Nhap Hang 45k/Luot\nCan Sa\t10g\t150k/Luot\tThue Nhap Hang 60k/Luot\nMa Tuy Tem\t1 Lo\t200k/Luot\tThue Nhap Hang 110k/Luot","Dong y","Huy bo");
				}
			}
			if(listitem == 1){
				SCM(playerid,COLOR_RED,"He Thong Loi: Dang trong qua trinh bao tri!");
				DeletePVar(playerid,"Dangluachon");
			}
		}
	}
	if(dialogid == DIALOG_CVMATUY){
		if(response){
			//Matuyvienc
			if(listitem == 0){
				SetTimer("FinishMTV",10000, false);
				GameTextForPlayer(playerid, "Dang Lay Hang....", 10000, 1);
				TogglePlayerControllable(playerid, 0);
				SCM(playerid,COLOR_SYNTAX,"Cong Viec: Tien thue nhap hang cua ban la 20000$");
				PlayerInfo[playerid][pCash] -= 20000;
				return 1;
			}
			//Matuyda
			if(listitem == 1){
				SetTimer("FinishMTDa",10000, false);
				GameTextForPlayer(playerid, "Dang Lay Hang....", 10000, 1);
				TogglePlayerControllable(playerid, 0);
				SCM(playerid,COLOR_SYNTAX,"Cong Viec: Tien thue nhap hang cua ban la 40000$");
				PlayerInfo[playerid][pCash] -= 40000;
				return 1;
			}
			//Thuoclac
			if(listitem == 2){
				SetTimer("FinishThuoclac",10000, false);
				GameTextForPlayer(playerid, "Dang Lay Hang....", 10000, 1);
				TogglePlayerControllable(playerid, 0);
				SCM(playerid,COLOR_SYNTAX,"Cong Viec: Tien thue nhap hang cua ban la 45000$");
				PlayerInfo[playerid][pCash] -= 45000;
			}
			//Cansa
			if(listitem == 3){
				SetTimer("FinishCansa",10000, false);
				GameTextForPlayer(playerid, "Dang Lay Hang....", 10000, 1);
				TogglePlayerControllable(playerid, 0);
				SCM(playerid,COLOR_SYNTAX,"Cong Viec: Tien thue nhap hang cua ban la 60000$");
				PlayerInfo[playerid][pCash] -= 60000;
			}
			//Matuytem
			if(listitem == 4){
				SetTimer("FinishMTTem",10000, false);
				GameTextForPlayer(playerid, "Dang Lay Hang....", 10000, 1);
				TogglePlayerControllable(playerid, 0);
				SCM(playerid,COLOR_SYNTAX,"Cong Viec: Tien thue nhap hang cua ban la 110000$");
				PlayerInfo[playerid][pCash] -= 110000;
			}
		}
	}
	if(dialogid == DIALOG_RUATIENBAN){
		if(response){
			if(GetPVarInt(playerid,"Dangruatien") == 1){
				if(strval(inputtext) <= 0){
					SCM(playerid,COLOR_RED,"He Thong Loi: Ban can nhap thong tin lon hon 0!");
				}else{
					giatritienban = strval(inputtext);
					printf("Giá trị nhập vào: %d", giatritienban);
					PlayerInfo[playerid][pCash] += giatritienban / 2;
					PlayerInfo[playerid][pTienban] -= giatritienban;
				    new string[128];
				    format(string,sizeof(string),"DynZ's: Ban da rua %d$ tien ban thanh tien sach, cam on ban da rua tien ban qua toi!",giatritienban);
				    SendClientMessage(playerid,COLOR_SYNTAX,string);
				    SCM(playerid,COLOR_SYNTAX,"DynZ's: Thue cua ban la 0,25 phan tram.");
				    mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Tienban = %i WHERE uid = %i", PlayerInfo[playerid][pTienban], PlayerInfo[playerid][pID]);
					mysql_tquery(connectionID, queryBuffer);
				}
			}
			return 1;
		}
	}
	return 1;
}

forward FinishMTV(playerid);
public FinishMTV(playerid){
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Xe dang doi ban o ngoai");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Toi ung truoc cho ban nua so tien, giao hang xong ban se nhan duoc so tien con lai.");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: mong rang ban se lam tot nhiem vu cua minh");
	PlayerInfo[playerid][pMatuyda] += 1;
	PlayerInfo[playerid][pMatuygiao] += 1;
	PlayerInfo[playerid][pTienban] += 25000;
	xematuy();
	TogglePlayerControllable(playerid, 1);
	randomcameraai();
	SetPVarInt(playerid,"giaohangmatuyda",1);
	SetPlayerCheckpoint(playerid,2635.6682,-2012.9988,14.1443,3);
    SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
	return 1;
}

forward FinishMTDa(playerid);
public FinishMTDa(playerid){
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Xe dang doi ban o ngoai");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Toi ung truoc cho ban nua so tien, giao hang xong ban se nhan duoc so tien con lai.");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: mong rang ban se lam tot nhiem vu cua minh");
	PlayerInfo[playerid][pMatuyda] += 1;
	PlayerInfo[playerid][pMatuygiao] += 1;
	PlayerInfo[playerid][pTienban] += 50000;
	xematuy();
	TogglePlayerControllable(playerid, 1);
	randomcameraai();
	SetPVarInt(playerid,"giaohangmatuyda",1);
	SetPlayerCheckpoint(playerid,2073.3630,-1583.2140,13.4741,3);
    SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
	return 1;
}

forward FinishThuoclac(playerid);
public FinishThuoclac(playerid){
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Xe dang doi ban o ngoai");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Toi ung truoc cho ban nua so tien, giao hang xong ban se nhan duoc so tien con lai.");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: mong rang ban se lam tot nhiem vu cua minh");
	PlayerInfo[playerid][pThuoclac] += 1;
	PlayerInfo[playerid][pTienban] += 55000;
	xematuy();
	TogglePlayerControllable(playerid, 1);
	randomcameraai();
	SetPVarInt(playerid,"giaohangthuoclac",1);
	SetPlayerCheckpoint(playerid,1550.0555,-33.7871,21.3330,3);
    SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
	return 1;
}

forward FinishCansa(playerid);
public FinishCansa(playerid){
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Xe dang doi ban o ngoai");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Toi ung truoc cho ban nua so tien, giao hang xong ban se nhan duoc so tien con lai.");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: mong rang ban se lam tot nhiem vu cua minh");
	PlayerInfo[playerid][pCansa] += 1;
	PlayerInfo[playerid][pTienban] += 75000;
	xematuy();
	randomcameraai();
	TogglePlayerControllable(playerid, 1);
	SetPVarInt(playerid,"giaohangcansa",1);
	SetPlayerCheckpoint(playerid,2086.1667,2154.0652,10.8203,3);
    SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
	return 1;
}

forward FinishMTTem(playerid);
public FinishMTTem(playerid){
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Xe dang doi ban o ngoai");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: Toi ung truoc cho ban nua so tien, giao hang xong ban se nhan duoc so tien con lai.");
	SendClientMessage(playerid,COLOR_SYNTAX,"Tro Ly: mong rang ban se lam tot nhiem vu cua minh");
	PlayerInfo[playerid][pMatuytem] += 1;
	PlayerInfo[playerid][pTienban] += 100000;
	xematuy();
	SetPlayerCheckpoint(playerid,2039.6442,2765.3362,10.8203,3);
    SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
	randomcameraai();
	TogglePlayerControllable(playerid, 1);
	SetPVarInt(playerid,"giaohangmatuytem",1);
	return 1;
}

stock randomcameraai(){
	new rdcameraai = random(70);
	switch(rdcameraai){
		case 0..10:{
			//5s
			SetTimer("CAMERAAI5giay",5000,false);
		}
		case 11..21:{
			//8s
			SetTimer("CAMERAAI8giay",8000,false);
		}
		case 22..32:{
			//10s
			SetTimer("CAMERAAI10giay",10000,false);
		}
		case 33..43:{
			//1p
			SetTimer("CAMERAAI1PHUT",60000,false);
		}
		case 44..54:{
			//2p
			SetTimer("CAMERAAI2PHUT",120000,false);
		}
		case 55..65:{
			//20 giay
			SetTimer("CAMERAAI3PHUT",20000,false);
		}
		case 66..76:{
			//Khong bao
			return 1;
		}
	}
	return 1;
}

forward CAMERAAI3PHUT(playerid);
public CAMERAAI3PHUT(playerid){
	SCMA(COLOR_WHITE, "{FFFFFF}----------{FFFFFF}{FFFF00}[CAMERA AI]{FFFF00} {FFFFFF}TO{FFFFFF} {0000FF}[POLICE]{0000FF}{FFFFFF}----------{FFFFFF}");
	SMA(COLOR_BLUE, "{FF0000}Phat hien nhom nguoi to chuc giao hang trang{FF0000}");
	return 1;
}

forward CAMERAAI2PHUT(playerid);
public CAMERAAI2PHUT(playerid){
	SCMA(COLOR_WHITE, "{FFFFFF}----------{FFFFFF}{FFFF00}[CAMERA AI]{FFFF00} {FFFFFF}TO{FFFFFF} {0000FF}[POLICE]{0000FF}{FFFFFF}----------{FFFFFF}");
	SMA(COLOR_BLUE, "{FF0000}Phat hien nhom nguoi to chuc giao hang trang{FF0000}");
	return 1;
}

forward CAMERAAI1PHUT(playerid);
public CAMERAAI1PHUT(playerid){
	SCMA(COLOR_WHITE, "{FFFFFF}----------{FFFFFF}{FFFF00}[CAMERA AI]{FFFF00} {FFFFFF}TO{FFFFFF} {0000FF}[POLICE]{0000FF}{FFFFFF}----------{FFFFFF}");
	SMA(COLOR_BLUE, "{FF0000}Phat hien nhom nguoi to chuc giao hang trang{FF0000}");
	return 1;
}

forward CAMERAAI10giay(playerid);
public CAMERAAI10giay(playerid){
	SCMA(COLOR_WHITE, "{FFFFFF}----------{FFFFFF}{FFFF00}[CAMERA AI]{FFFF00} {FFFFFF}TO{FFFFFF} {0000FF}[POLICE]{0000FF}{FFFFFF}----------{FFFFFF}");
	SMA(COLOR_BLUE, "{FF0000}Phat hien nhom nguoi to chuc giao hang trang{FF0000}");
	return 1;
}

forward CAMERAAI8giay(playerid);
public CAMERAAI8giay(playerid){
	SCMA(COLOR_WHITE, "{FFFFFF}----------{FFFFFF}{FFFF00}[CAMERA AI]{FFFF00} {FFFFFF}TO{FFFFFF} {0000FF}[POLICE]{0000FF}{FFFFFF}----------{FFFFFF}");
	SMA(COLOR_BLUE, "{FF0000}Phat hien nhom nguoi to chuc giao hang trang{FF0000}");
	return 1;
}

forward CAMERAAI5giay(playerid);
public CAMERAAI5giay(playerid){
	SCMA(COLOR_WHITE, "{FFFFFF}----------{FFFFFF}{FFFF00}[CAMERA AI]{FFFF00} {FFFFFF}TO{FFFFFF} {0000FF}[POLICE]{0000FF}{FFFFFF}----------{FFFFFF}");
	SMA(COLOR_BLUE, "{FF0000}Phat hien nhom nguoi to chuc giao hang trang{FF0000}");
	return 1;
}

/*stock ramdoncheckpointmatuy(playerid){
	new rdcp = random(50);
	switch(rdcp){
        case 0..10:{
            SetPlayerCheckpoint(playerid,2635.6682,-2012.9988,14.1443,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
        }
        case 11..21:{
            SetPlayerCheckpoint(playerid,2073.3630,-1583.2140,13.4741,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
        }
        case 22..32:{
            SetPlayerCheckpoint(playerid,1550.0555,-33.7871,21.3330,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
        }
        case 33..44:{
        	SetPlayerCheckpoint(playerid,2086.1667,2154.0652,10.8203,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
        }
        case 45..55:{
        	SetPlayerCheckpoint(playerid,2039.6442,2765.3362,10.8203,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban nhan duoc hang trang, hay can than camera va canh sat");
        }
    }
    return 1;
}*/

stock xematuy(){
	chiecxematuy = AddStaticVehicle(418,-64.9409,-1581.0187,2.7069,208.6837,0,2);
	return 1;
}

hook OnPlayerEnterCheckpoint(playerid){
	if(GetPVarInt(playerid,"giaohangmatuyvien") == 1){
		PlayerInfo[playerid][pMatuyvien] -= 1;
		SendClientMessage(playerid,COLOR_SYNTAX,"John'N: Cam on ban da giao hang cho toi...");
		PlayerInfo[playerid][pTienban] += 25000;
		SendClientMessage(playerid,COLOR_SYNTAX,"John'N: Mot nua so tien con lai cua ban day, hay tiep tuc cong viec nhe!");
		PlayerInfo[playerid][pMatuygiao] -= 1;
		DeletePVar(playerid, "giaohangmatuyvien");
		DeletePVar(playerid,"Dangluachon");
		ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Tienban = %i WHERE uid = %i", PlayerInfo[playerid][pTienban], PlayerInfo[playerid][pID]);
    	mysql_tquery(connectionID, queryBuffer);
	}
	if(GetPVarInt(playerid,"giaohangmatuyda") == 1){
		PlayerInfo[playerid][pMatuyda] -= 1;
		SendClientMessage(playerid,COLOR_SYNTAX,"Jame's: Cam on ban da giao hang cho toi...");
		PlayerInfo[playerid][pTienban] += 50000;
		SendClientMessage(playerid,COLOR_SYNTAX,"Jame's: Mot nua so tien con lai cua ban day, hay tiep tuc cong viec nhe!");
		PlayerInfo[playerid][pMatuygiao] -= 1;
		DeletePVar(playerid, "giaohangmatuyda");
		DeletePVar(playerid,"Dangluachon");
		ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Tienban = %i WHERE uid = %i", PlayerInfo[playerid][pTienban], PlayerInfo[playerid][pID]);
    	mysql_tquery(connectionID, queryBuffer);
	}
	if(GetPVarInt(playerid,"giaohangthuoclac") == 1){
		PlayerInfo[playerid][pThuoclac] -= 1;
		SendClientMessage(playerid,COLOR_SYNTAX,"Tony'D: Cam on ban da giao hang cho toi...");
		DeletePVar(playerid, "giaohangthuoclac");
		PlayerInfo[playerid][pTienban] += 55000;
		SendClientMessage(playerid,COLOR_SYNTAX,"Tony'D: Mot nua so tien con lai cua ban day, hay tiep tuc cong viec nhe!");
		DeletePVar(playerid,"Dangluachon");
		ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Tienban = %i WHERE uid = %i", PlayerInfo[playerid][pTienban], PlayerInfo[playerid][pID]);
   	 	mysql_tquery(connectionID, queryBuffer);
	}
	if(GetPVarInt(playerid,"giaohangcansa") == 1){
		PlayerInfo[playerid][pCansa] -= 1;
		SendClientMessage(playerid,COLOR_SYNTAX,"Scall's: Cam on ban da giao hang cho toi...");
		DeletePVar(playerid, "giaohangcansa");
		PlayerInfo[playerid][pTienban] += 75000;
		SendClientMessage(playerid,COLOR_SYNTAX,"Scall's: Mot nua so tien con lai cua ban day, hay tiep tuc cong viec nhe!");
		DeletePVar(playerid,"Dangluachon");
		ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Tienban = %i WHERE uid = %i", PlayerInfo[playerid][pTienban], PlayerInfo[playerid][pID]);
    	mysql_tquery(connectionID, queryBuffer);
	}
	if(GetPVarInt(playerid,"giaohangmatuytem") == 1){
		PlayerInfo[playerid][pMatuytem] -= 1;
		SendClientMessage(playerid,COLOR_SYNTAX,"Gast's: Cam on ban da giao hang cho toi...");
		DeletePVar(playerid, "giaohangmatuytem");
		DeletePVar(playerid,"Dangluachon");
		PlayerInfo[playerid][pTienban] += 100000;
		SendClientMessage(playerid,COLOR_SYNTAX,"Gast's: Mot nua so tien con lai cua ban day, hay tiep tuc cong viec nhe!");
		SetPVarInt(playerid,"diadiemnhantien5",1);
		ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Tienban = %i WHERE uid = %i", PlayerInfo[playerid][pTienban], PlayerInfo[playerid][pID]);
    	mysql_tquery(connectionID, queryBuffer);
	}
	return 1;
}


stock IsPlayerInRangeOfActor(playerid, actorid, Float:radius = 5.0)
{
    new Float:x,
        Float:y,
        Float:z;

    if (GetActorPos(actorid, x, y, z))
    {
        return IsPlayerInRangeOfPoint(playerid, radius, x, y, z);
    }
    return 0;
}