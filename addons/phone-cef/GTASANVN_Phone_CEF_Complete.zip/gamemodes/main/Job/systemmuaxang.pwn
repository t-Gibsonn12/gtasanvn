#include <a_samp>
#include <a_mysql>
#include <foreach>
#include <ZCMD>
#include <YSI_Coding\y_hooks>
#include <YSI\y_hooks>

new binhxanglon95,
	binhxangnho95,
	binhxanglon92,
	binhxangnho92,
	Text3D:binhxanglon953Dtext,
	Text3D:binhxangnho953Dtext,
	Text3D:binhxanglon923Dtext,
	Text3D:binhxangnho923Dtext,
    Float: x,
    Float: y,
    Float: z,
    Float: a,
    string[128];

#define DIALOG_THONGTIN	(10001)
#define DIALOG_MENUXANG	(10003)
#define DIALOG_THONGTIN2 (10006)
#define DIALOG_MENUVUTXANG (10007)
#define DIALOG_INPUTVUTXANGLON95 (10008)
#define DIALOG_INPUTVUTXANGNHO95 (10009)
#define DIALOG_INPUTVUTXANGLON92 (10010)
#define DIALOG_INPUTVUTXANGNHO92 (10011)
#define DIALOG_DATBINHXANG (10012)
#define DIALOG_NHATBINHXANG (10013)
#define DIALOG_MENUDOBINHXANG (10014)
CMD:menuxang(playerid,params[]){
	/*if(!VehicleDistinguishCar(vehicleid) != PlayerInfo[playerid][pXang95]){
		return SCM(playerid, COLOR_RED,"He Thong: Ban can do xang theo loai xang 95");
	}
	if(!VehicleDistinguishMoto(vehicleid) != PlayerInfo[playerid][pXang92]){
		return SCM(playerid, COLOR_RED,"He Thong: Ban can do xang theo loai xang 92");
	}*/
	if(PlayerInfo[playerid][pInjured] > 0 || PlayerInfo[playerid][pTazedTime] > 0 || PlayerInfo[playerid][pCuffed] > 0) return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong the su dung lenh nay vao luc nay!");
	if(!IsPlayerAtFuelStation(playerid)){
		SCM(playerid, COLOR_SYNTAX, "He Thong: Ban can phai o tram xang, hoac ben trong nha de xe!");
	}else{
		ShowPlayerDialog(playerid,DIALOG_MENUXANG,DIALOG_STYLE_TABLIST,"[MENU XANG] - Hay lua chon binh xang phu hop voi xe","Binh Xang Lon\tLoai 95\t100.000$\nBinh Xang Nho\tLoai 95\t50.000$\nBinh Xang Lon\tLoai 92\t100.000$\nBinh Xang Nho\tLoai 92\t50.000$","Dong y","Huy bo");
	}
	return 1;
}

CMD:vutxang(playerid,params[]){
	ShowPlayerDialog(playerid,DIALOG_MENUVUTXANG,DIALOG_STYLE_TABLIST,"MENU VUT XANG","Binh Xang Lon\t95\nBinh Xang Nho\t95\nBinh Xang Lon\t92\nBinh Xang Nho\t92","Dong y","Huy bo");
	return 1;
}

hook OnGameModeExit(playerid){
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	SetPVarInt(playerid, "Dangdoxang", 0);
	return 1;
}

hook OnPlayerDisconnect(playerid, reason){
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	SetPVarInt(playerid, "Dangdoxang", 0);
	return 1;
}

stock datbinhxanglon95(playerid){
	if(PlayerInfo[playerid][pBinhxanglon95] >= 1){
	    GetPlayerPos(playerid, x, y, z);
	    GetPlayerFacingAngle(playerid, a);
	    format(string, sizeof(string), "Binh Xang Lon\nLoai 95",string);
	   	PlayerInfo[playerid][pBinhxanglon95] -= 1;
	    PlayerInfo[playerid][pBinhxangdatroilon95] = 1;
	    binhxanglon95 = CreateDynamicObject(1650, x, y, z - 0.7, 0.0, 0.0, a, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
	    binhxanglon953Dtext = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
	    ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
	    SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da dat mot binh xang lon xuong dat.", GetRPName(playerid));
	}else{
	    SendClientMessage(playerid,COLOR_SYNTAX,"He Thong: Ban khong co binh xang lon de dat.");
	}
	return 1;
}

stock datbinhxangnho95(playerid){
	if(PlayerInfo[playerid][pBinhxanglon92] >= 1){
        GetPlayerPos(playerid, x, y, z);
        GetPlayerFacingAngle(playerid, a);
        format(string, sizeof(string), "Binh Xang Nho\nLoai 95",string);
       	PlayerInfo[playerid][pBinhxangnho95] -= 1;
        PlayerInfo[playerid][pBinhxangdatroinho95] = 1;
        binhxangnho95 = CreateDynamicObject(1650, x, y, z - 0.7, 0.0, 0.0, a, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
        binhxangnho953Dtext = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
        ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
        SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da dat mot binh xang nho xuong dat.", GetRPName(playerid));
    }else{
        SendClientMessage(playerid,COLOR_SYNTAX,"He Thong: Ban khong co binh xang nho de dat.");
    }
    return 1;
}

stock datbinhxanglon92(playerid){
	if(PlayerInfo[playerid][pBinhxanglon92] >= 1){
        GetPlayerPos(playerid, x, y, z);
        GetPlayerFacingAngle(playerid, a);
        format(string, sizeof(string), "Binh Xang Lon\nLoai 92",string);
       	PlayerInfo[playerid][pBinhxanglon92] -= 1;
        PlayerInfo[playerid][pBinhxangdatroilon92] = 1;
        binhxanglon92 = CreateDynamicObject(1650, x, y, z - 0.7, 0.0, 0.0, a, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
        binhxanglon923Dtext = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
        ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
        SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da dat mot binh xang lon xuong dat.", GetRPName(playerid));
    }else{
        SendClientMessage(playerid,COLOR_SYNTAX,"He Thong: Ban khong co binh xang lon de dat.");
    }
    return 1;
}

stock datbinhxangnho92(playerid){
	if(PlayerInfo[playerid][pBinhxangnho92] >= 1){
        GetPlayerPos(playerid, x, y, z);
        GetPlayerFacingAngle(playerid, a);
        format(string, sizeof(string), "Binh Xang Nho\nLoai 92",string);
       	PlayerInfo[playerid][pBinhxangnho92] -= 1;
        PlayerInfo[playerid][pBinhxangdatroinho92] = 1;
        binhxangnho92 = CreateDynamicObject(1650, x, y, z - 0.7, 0.0, 0.0, a, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
        binhxangnho923Dtext = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
        ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
        SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da dat mot binh xang nho xuong dat.", GetRPName(playerid));
    }else{
        SendClientMessage(playerid,COLOR_SYNTAX,"He Thong: Ban khong co binh xang nho de dat.");
    }
    return 1;
}

CMD:datbinhxang(playerid,params[]){
	ShowPlayerDialog(playerid,DIALOG_DATBINHXANG,DIALOG_STYLE_TABLIST,"DAT BINH XANG","Binh Xang Lon\tLoai 95\nBinh Xang Nho\tLoai 95\nBinh Xang Lon\tLoai 92\nBinh Xang Nho\tLoai 92","Dong y","Huy bo");
    return 1;
}

CMD:nhatbinhxang(playerid,params[]){
	ShowPlayerDialog(playerid,DIALOG_NHATBINHXANG,DIALOG_STYLE_TABLIST,"NHAT BINH XANG","Binh Xang Lon\tLoai 95\nBinh Xang Nho\tLoai 95\nBinh Xang Lon\tLoai 92\nBinh Xang Nho\tLoai 92","Dong y","Huy bo");
	return 1;
}
stock nhatbinhxanglon95(playerid){
	if(!PlayerInfo[playerid][pBinhxangdatroilon95])
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong dat binh xang lon.");
    }
    if(!IsPlayerInRangeOfDynamicObject(playerid, binhxanglon95, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong nam trong pham vi cua binh xang.");
    }
    GetDynamicObjectPos(binhxanglon95, x,y,z);
    SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s dat nhat binh xang lon va cat no di.", GetRPName(playerid));
    DestroyDynamicObject(binhxanglon95);
    DestroyDynamic3DTextLabel( Text3D:binhxanglon953Dtext );
    ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
    PlayerInfo[playerid][pBinhxanglon95] += 1;
    PlayerInfo[playerid][pBinhxangdatroilon95] = 0;
	return 1;
}

stock nhatbinhxangnho95(playerid){
	if(!PlayerInfo[playerid][pBinhxangdatroinho95])
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong dat binh xang nho.");
    }
    if(!IsPlayerInRangeOfDynamicObject(playerid, binhxangnho95, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong nam trong pham vi cua binh xang.");
    }
    GetDynamicObjectPos(binhxangnho95, x,y,z);
    SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s dat nhat binh xang nho va cat no di.", GetRPName(playerid));
    DestroyDynamicObject(binhxangnho95);
    DestroyDynamic3DTextLabel( Text3D:binhxangnho953Dtext );
    ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
    PlayerInfo[playerid][pBinhxangnho95] += 1;
    PlayerInfo[playerid][pBinhxangdatroinho95] = 0;
    return 1;
}

stock nhatbinhxanglon92(playerid){
	if(!PlayerInfo[playerid][pBinhxangdatroilon92])
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong dat binh xang lon.");
    }
    if(!IsPlayerInRangeOfDynamicObject(playerid, binhxanglon92, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong nam trong pham vi cua binh xang.");
    }
    GetDynamicObjectPos(binhxanglon92, x,y,z);
    SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s dat nhat binh xang lon va cat no di.", GetRPName(playerid));
    DestroyDynamicObject(binhxanglon92);
    DestroyDynamic3DTextLabel( Text3D:binhxanglon923Dtext );
    ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
    PlayerInfo[playerid][pBinhxanglon92] += 1;
    PlayerInfo[playerid][pBinhxangdatroilon92] = 0;
    return 1;
}

stock nhatbinhxangnho92(playerid){
	if(!PlayerInfo[playerid][pBinhxangdatroinho92])
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong dat binh xang nho.");
    }
    if(!IsPlayerInRangeOfDynamicObject(playerid, binhxangnho92, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong nam trong pham vi cua binh xang.");
    }
    GetDynamicObjectPos(binhxangnho92, x,y,z);
    SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s dat nhat binh xang nho va cat no di.", GetRPName(playerid));
    DestroyDynamicObject(binhxangnho92);
    DestroyDynamic3DTextLabel( Text3D:binhxangnho923Dtext );
    ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
    PlayerInfo[playerid][pBinhxangnho92] += 1;
    PlayerInfo[playerid][pBinhxangdatroinho92] = 0;
    return 1;
}

CMD:soluongbinhxang(playerid,params[]){
	new string[128];
	format(string, 128, "Binh Xang Lon - [95]: %d", PlayerInfo[playerid][pBinhxanglon95]);
	SendClientMessage(playerid, -1, string);
	format(string, 128, "Binh Xang Nho - [95]: %d", PlayerInfo[playerid][pBinhxangnho95]);
	SendClientMessage(playerid, -1, string);
	format(string, 128, "Binh Xang Lon - [92]: %d", PlayerInfo[playerid][pBinhxanglon92]);
	SendClientMessage(playerid, -1, string);
	format(string, 128, "Binh Xang Nho - [92]: %d", PlayerInfo[playerid][pBinhxangnho92]);
	SendClientMessage(playerid, -1, string);
	SendClientMessage(playerid, -1,"---------------DEV OMPVN-------------");
	return 1;
}

stock On_PlayerDialogResponse(playerid, dialogid, response, listitem, inputtext[]){
	if(dialogid == DIALOG_THONGTIN){
		if(response){
			if(listitem == 0){
				ShowPlayerDialog(playerid,DIALOG_THONGTIN2,DIALOG_STYLE_MSGBOX,"THONG TIN GIA XANG","\tBANG GIA BINH XANG\n\tBinh Xang Lon\tLoai 95\t100.000$\nBinh Xang Nho\tLoai 95\t50.000$\nBinh Xang Lon\tLoai 92\t100.000$\nBinh Xang Nho\tLoai 92\t50.000$","Dong y","Huy bo");
			}
		}	
		return 1;	
	}
	if(dialogid == DIALOG_THONGTIN2){
		if(response){
			return 1;
		}
	}
	if(dialogid == DIALOG_INPUTVUTXANGLON95){
		if(response){
			if(strval(inputtext) < 0){
				SendClientMessage(playerid, COLOR_RED,"He Thong: ban can nhap gia tri lon hon 0!");
			}else{
				if(PlayerInfo[playerid][pBinhxanglon95] <= 0){
					SendClientMessage(playerid, COLOR_RED,"He Thong: ban khong con binh xang nao!");
				}else{
					if(strval(inputtext) > PlayerInfo[playerid][pBinhxanglon95]){
						SCM(playerid,COLOR_RED,"He Thong: Ban khong du binh xang de vut!");
					}else{
						new giatribinhxanglon95 = strval(inputtext);
						PlayerInfo[playerid][pBinhxanglon95] -= giatribinhxanglon95;
					}
				}
				return 1;
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		return 1;
	}
	if(dialogid == DIALOG_INPUTVUTXANGNHO95){
		if(response){
			if(strval(inputtext) < 0){
				SendClientMessage(playerid, COLOR_RED,"He Thong: ban can nhap gia tri lon hon 0!");
			}else{
				if(PlayerInfo[playerid][pBinhxanglon92] <= 0){
					SendClientMessage(playerid, COLOR_RED,"He Thong: ban khong con binh xang nao!");
				}else{
					if(strval(inputtext) > PlayerInfo[playerid][pBinhxangnho95]){
						SCM(playerid,COLOR_RED,"He Thong: Ban khong du binh xang de vut!");
					}else{
						new giatribinhxangnho95 = strval(inputtext);
						PlayerInfo[playerid][pBinhxangnho95] -= giatribinhxangnho95;
					}
				}
				return 1;
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		return 1;
	}
	if(dialogid == DIALOG_INPUTVUTXANGLON92){
		if(response){
			if(strval(inputtext) < 0){
				SendClientMessage(playerid, COLOR_RED,"He Thong: ban can nhap gia tri lon hon 0!");
			}else{
				if(PlayerInfo[playerid][pBinhxanglon92] <= 0){
					SendClientMessage(playerid, COLOR_RED,"He Thong: ban khong con binh xang nao!");
				}else{
					if(strval(inputtext) > PlayerInfo[playerid][pBinhxanglon92]){
						SCM(playerid,COLOR_RED,"He Thong: Ban khong du binh xang de vut!");
					}else{
						new giatribinhxanglon92 = strval(inputtext);
						PlayerInfo[playerid][pBinhxanglon92] -= giatribinhxanglon92;
					} 
				}
				return 1;
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		return 1;
	}
	if(dialogid == DIALOG_INPUTVUTXANGNHO92){
		if(response){
			if(strval(inputtext) < 0){
				SendClientMessage(playerid, COLOR_RED,"He Thong: ban can nhap gia tri lon hon 0!");
			}else{
				if(PlayerInfo[playerid][pBinhxangnho92] <= 0) {
					SendClientMessage(playerid, COLOR_RED,"He Thong: ban khong con binh xang nao!");
				}else{
					if(strval(inputtext) > PlayerInfo[playerid][pBinhxangnho92]){
						SCM(playerid,COLOR_RED,"He Thong: Ban khong du binh xang de vut!");
					}else{
						new giatribinhxangnho92 = strval(inputtext);
						PlayerInfo[playerid][pBinhxangnho92] -= giatribinhxangnho92;
					}
				}
				return 1;					
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		return 1;
	}
	if(dialogid == DIALOG_MENUVUTXANG){
		if(response){
			if(listitem == 0){
				ShowPlayerDialog(playerid,DIALOG_INPUTVUTXANGLON95,DIALOG_STYLE_INPUT,"[VUT XANG LON] - 95","Nhap gia tri can vut:","Dong y","Huy bo");
			}
			if(listitem == 1){
				ShowPlayerDialog(playerid,DIALOG_INPUTVUTXANGNHO95,DIALOG_STYLE_INPUT,"[VUT XANG NHO] - 95","Nhap gia tri can vut:","Dong y","Huy bo");
			}
			if(listitem == 2){
				ShowPlayerDialog(playerid,DIALOG_INPUTVUTXANGLON92,DIALOG_STYLE_INPUT,"[VUT XANG LON] - 92","Nhap gia tri can vut:","Dong y","Huy bo");
			}
			if(listitem == 3){
				ShowPlayerDialog(playerid,DIALOG_INPUTVUTXANGNHO92,DIALOG_STYLE_INPUT,"[VUT XANG NHO] - 92","Nhap gia tri can vut:","Dong y","Huy bo");
			}
			return 1;
		}
	}
	if(dialogid == DIALOG_MENUXANG){
		if(response){
			if(listitem == 0){
				if(PlayerInfo[playerid][pCash] >= 1000000){
					PlayerInfo[playerid][pBinhxanglon95] += 1;
					PlayerInfo[playerid][pCash] -= 1000000;
					SendClientMessage(playerid, -1,"He Thong: ban vua mua 1 binh xang lon loai 95");
				}else{
					SendClientMessage(playerid, COLOR_RED,"He Thong: Ban khong du tien de mua binh xang");
				}
			}
			if(listitem == 1){
				if(PlayerInfo[playerid][pCash] >= 500000){
					PlayerInfo[playerid][pBinhxangnho95] += 1;
					PlayerInfo[playerid][pCash] -= 500000;
					SendClientMessage(playerid, -1, "He Thong: ban vua mua 1 binh xang nho loai 95");
				}else{
					SendClientMessage(playerid, COLOR_RED,"He Thong: Ban khong du tien de mua binh xang");
				}
			}
			if(listitem == 2){
				if(PlayerInfo[playerid][pCash] >= 1000000){
					PlayerInfo[playerid][pBinhxanglon92] += 1;
					PlayerInfo[playerid][pCash] -= 1000000;
					SendClientMessage(playerid, -1, "He Thong: ban vua mua 1 binh xang lon loai 92");
				}else{
					SendClientMessage(playerid, COLOR_RED,"He Thong: Ban khong du tien de mua binh xang");
				}
			}
			if(listitem == 3){
				if(PlayerInfo[playerid][pCash] >= 500000){
					PlayerInfo[playerid][pBinhxangnho92] += 1;
					PlayerInfo[playerid][pCash] -= 500000;
					SendClientMessage(playerid, -1, "He Thong: ban vua mua 1 binh xang nho loai 92");
				}else{
					SendClientMessage(playerid, COLOR_RED,"He Thong: Ban khong du tien de mua binh xang");
				}
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET cash = %i WHERE uid = %i", PlayerInfo[playerid][pCash],PlayerInfo[playerid][pID]);
	    mysql_tquery(connectionID, queryBuffer);
		return 1;	
	}
	if(dialogid == DIALOG_DATBINHXANG){
		if(response){
			if(listitem == 0){
				datbinhxanglon95(playerid);
			}
			if(listitem == 1){
				datbinhxangnho95(playerid);
			}
			if(listitem == 2){
				datbinhxanglon92(playerid);
			}
			if(listitem == 3){
				datbinhxangnho92(playerid);
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);

		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
	}
	if(dialogid == DIALOG_NHATBINHXANG){
		if(response){
			if(listitem == 0){
				nhatbinhxanglon95(playerid);
			}
			if(listitem == 1){
				nhatbinhxangnho95(playerid);
			}
			if(listitem == 2){
				nhatbinhxanglon92(playerid);
			}
			if(listitem == 3){
				nhatbinhxangnho92(playerid);
			}
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);

		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroilon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroilon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangdatroinho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangdatroinho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
	}
	if(dialogid == DIALOG_MENUDOBINHXANG){
		new vehicleid = GetPlayerVehicleID(playerid);
		if(response){
			if(listitem == 0){
				if(!VehicleDistinguishCar(vehicleid)){
					SCM(playerid, COLOR_SYNTAX,"He Thong: Loai xang khong phu hop voi xe!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}
				if(!VehicleHasEngine(vehicleid))
				{
				    SCM(playerid, COLOR_SYNTAX, "He Thong: Xe nay khong co dong co, ban khong the do xang!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}else{	
					SetTimer("_@Time_Doxanglonloai95",10000, false);
					GameTextForPlayer(playerid, "Dang Do Xang....", 10000, 1);
				}
				return 1;
			}
			if(listitem == 1){
				if(!VehicleDistinguishCar(vehicleid)){
					SCM(playerid, COLOR_SYNTAX,"He Thong: Loai xang khong phu hop voi xe!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}
				if(!VehicleHasEngine(vehicleid))
				{
				    SCM(playerid, COLOR_SYNTAX, "He Thong: Xe nay khong co dong co, ban khong the do xang!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}else{
					SetTimer("_@Time_Doxangnholoai95",10000, false);
					GameTextForPlayer(playerid, "Dang Do Xang....", 10000, 1);
				}	
				return 1;
			}
			if(listitem == 2){
				if(!VehicleHasEngine(vehicleid))
				{
				    SCM(playerid, COLOR_SYNTAX, "He Thong: Xe nay khong co dong co, ban khong the do xang!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}
				//Loai 92 - 2 banh
				if(!VehicleDistinguishMoto(vehicleid)){
					SCM(playerid, COLOR_SYNTAX,"He Thong: Loai xang khong phu hop voi xe!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}else{
					SetTimer("_@Time_Doxanglonloai92",10000, false);
					GameTextForPlayer(playerid, "Dang Do Xang....", 10000, 1);
				}
				return 1;
			}
			if(listitem == 3){
				if(!VehicleHasEngine(vehicleid))
				{
				    SCM(playerid, COLOR_SYNTAX, "He Thong: Xe nay khong co dong co, ban khong the do xang!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}
				//Loai 92 - 2 banh
				if(!VehicleDistinguishMoto(vehicleid)){
					SCM(playerid, COLOR_SYNTAX,"He Thong: Loai xang khong phu hop voi xe!");
					SetPVarInt(playerid, "Dangdoxang", 0);
				}else{
					SetTimer("_@Time_Doxangnholoai92",10000, false);
					GameTextForPlayer(playerid, "Dang Do Xang....", 10000, 1);
				}
				return 1;
			}	
		}
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
		mysql_tquery(connectionID, queryBuffer);
		SetPVarInt(playerid, "Dangdoxang", 0);
	}
	return 1;
}

forward _@Time_Doxanglonloai95(playerid);
public _@Time_Doxanglonloai95(playerid){
	new vehicleid = GetPlayerVehicleID(playerid);
	if(vehicleFuel[vehicleid] >= 100)
	{
	    SCM(playerid, COLOR_SYNTAX, "He Thong: Binh xang trong phuong tien nay da day!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}else{
		vehicleFuel[vehicleid] = 100;
		PlayerInfo[playerid][pBinhxanglon95] -= 1;
		SCM(playerid, COLOR_SYNTAX, "He Thong: phuong tien cua ban da duoc day day binh!");
		SCM(playerid, COLOR_SYNTAX, "He Thong: ban da bi tru di 1 binh xang!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}
	return 1;
}
forward _@Time_Doxangnholoai95(playerid);
public _@Time_Doxangnholoai95(playerid){
	new vehicleid = GetPlayerVehicleID(playerid);
	if(vehicleFuel[vehicleid] >= 100)
	{
	    SCM(playerid, COLOR_SYNTAX, "He Thong: Binh xang trong phuong tien nay da day!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}else{
		vehicleFuel[vehicleid] = 100;
		PlayerInfo[playerid][pBinhxangnho95] -= 1;
		SCM(playerid, COLOR_SYNTAX, "He Thong: phuong tien cua ban da duoc day day binh!");
		SCM(playerid, COLOR_SYNTAX, "He Thong: ban da bi tru di 1 binh xang!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}
	return 1;
}
forward _@Time_Doxanglonloai92(playerid);
public _@Time_Doxanglonloai92(playerid){
	new vehicleid = GetPlayerVehicleID(playerid);
	if(vehicleFuel[vehicleid] >= 100)
	{
	    SCM(playerid, COLOR_SYNTAX, "He Thong: Binh xang trong phuong tien nay da day!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}else{
		vehicleFuel[vehicleid] = 100;
		PlayerInfo[playerid][pBinhxanglon92] -= 1;
		SCM(playerid, COLOR_SYNTAX, "He Thong: phuong tien cua ban da duoc day day binh!");
		SCM(playerid, COLOR_SYNTAX, "He Thong: ban da bi tru di 1 binh xang!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}
	return 1;
}
forward _@Time_Doxangnholoai92(playerid);
public _@Time_Doxangnholoai92(playerid){
	new vehicleid = GetPlayerVehicleID(playerid);
	if(vehicleFuel[vehicleid] >= 100)
	{
	    SCM(playerid, COLOR_SYNTAX, "He Thong: Binh xang trong phuong tien nay da day!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}else{
		vehicleFuel[vehicleid] = 100;
		PlayerInfo[playerid][pBinhxangnho92] -= 1;
		SCM(playerid, COLOR_SYNTAX, "He Thong: phuong tien cua ban da duoc day day binh!");
		SCM(playerid, COLOR_SYNTAX, "He Thong: ban da bi tru di 1 binh xang!");
		SetPVarInt(playerid, "Dangdoxang", 0);
	}
	return 1;
}

CMD:dobinhxangxe(playerid,params[]){
	new vehicleid = GetPlayerVehicleID(playerid);
	if(GetPVarInt(playerid, "Dangdoxang") == 1){
		SendClientMessage(playerid,COLOR_RED,"He Thong: Ban dang trong qua trinh lua chon xang hoac do xang roi!");
	}else{
		if(GetPlayerState(playerid) != PLAYER_STATE_DRIVER)
		{
		    return SCM(playerid, COLOR_RED, "He Thong: Ban khong lai bat ky phuong tien nao.");
		}
		if(!VehicleHasEngine(vehicleid))
		{
		    return SCM(playerid, COLOR_RED, "He Thong: Xe nay khong co dong co, ban khong the do xang.");
		}
	 	if(GetVehicleParams(vehicleid, VEHICLE_ENGINE))
	    {
         	return SCM(playerid, COLOR_RED, "He Thong: Dong co phuong tien can duoc tat, truoc khi tiep tuc thuc hien dieu nay.");
	    }
		if(vehicleFuel[vehicleid] >= 100)
		{
		    return SCM(playerid, COLOR_RED, "He Thong: Binh xang trong phuong tien nay da day.");
		}else{
			if(PlayerInfo[playerid][pBinhxanglon95] > 0 || PlayerInfo[playerid][pBinhxangnho95] > 0 || PlayerInfo[playerid][pBinhxanglon92] > 0 || PlayerInfo[playerid][pBinhxangnho92] > 0){
				ShowPlayerDialog(playerid,DIALOG_MENUDOBINHXANG,DIALOG_STYLE_TABLIST,"MENU DO BINH XANG","Binh Xang Lon\tLoai 95\nBinh Xang Nho\tLoai 95\nBinh Xang Lon\tLoai 92\nBinh Xang Nho\tLoai 92","Dong y","Huy bo");
				SetPVarInt(playerid, "Dangdoxang", 1);
			}else{
				SendClientMessage(playerid,COLOR_RED,"He Thong: Ban can co it nhat 1 binh xang de do xang cho xe!");
			}
			return 1;
		}
	}
	return 1;
}

CMD:banbinhxang(playerid,params[]){
	new targetid;
	if(!IsPlayerConnected(targetid) || !PlayerInfo[targetid][pLogged])
	{
	    return SCM(playerid, COLOR_SYNTAX, "He Thong: Khong the su dung lenh nay o thoi diem hien tai or hasn't logged in yet.");
	}
	if(targetid == playerid)
	{
	    return SCM(playerid, COLOR_SYNTAX, "He Thong: Ban khong the chuyen tien cho chinh minh.");
	}
	new string[128], 
		option[8],
		amount,
		money;
	new name[MAX_PLAYER_NAME];
	GetPlayerName(playerid, name, sizeof(name));
	if(sscanf(params, "udd", targetid, option, amount,money))
	{
		SendClientMessageEx(playerid, COLOR_GREY, "SU DUNG: /banbinhxang [player] [option] [amount] [sotien]");
		SendClientMessageEx(playerid, -1, "|1 Binh Xang Lon - 95 |2 Binh Xang Nho - 95 |3 Binh Xang Lon - 92 |4 Binh Xang Nho - 92");
		return 1;
	}
	if(targetid != INVALID_PLAYER_ID){
		if(!strcmp(option, "1", true))
		{
			PlayerInfo[playerid][pBinhxanglon95] += amount;
		 	PlayerInfo[targetid][pBinhxanglon95] -= amount;
		 	PlayerInfo[playerid][pCash] += money;
		 	PlayerInfo[targetid][pCash] -= money;
		 	format(string, sizeof(string), "%s's Vua ban %d binh xang lon loai 95 cho %s voi gia voi gia %d",name,GetPlayerNameEx(targetid),amount);
			SendClientMessageEx(playerid, -1, string);	
			return 1;
		}
		if(!strcmp(option, "2", true))
		{

		 	PlayerInfo[playerid][pBinhxangnho95] += amount;
		 	PlayerInfo[targetid][pBinhxangnho95] -= amount;
		 	PlayerInfo[playerid][pCash] += money;
		 	PlayerInfo[targetid][pCash] -= money;				 	
	 		format(string, sizeof(string), "%s's Vua ban %d binh xang lon loai 95 cho %s voi gia voi gia %d",name,GetPlayerNameEx(targetid),amount);
			SendClientMessageEx(playerid, -1, string);	
			return 1;
		}
		if(!strcmp(option, "3", true))
		{
		 	PlayerInfo[playerid][pBinhxanglon92] += amount;
		 	PlayerInfo[targetid][pBinhxanglon92] -= amount;
		 	PlayerInfo[playerid][pCash] += money;
		 	PlayerInfo[targetid][pCash] -= money;
		 	format(string, sizeof(string), "%s's Vua ban %d binh xang lon loai 95 cho %s voi gia voi gia %d",name,GetPlayerNameEx(targetid),amount);
			SendClientMessageEx(playerid, -1, string);	
			return 1;
		}
		if(!strcmp(option, "4", true))
		{
		 	PlayerInfo[playerid][pBinhxangnho92] += amount;
		 	PlayerInfo[targetid][pBinhxangnho92] -= amount;
		 	PlayerInfo[playerid][pCash] += money;
		 	PlayerInfo[targetid][pCash] -= money;
			format(string, sizeof(string), "%s's Vua ban %d binh xang lon loai 95 cho %s voi gia voi gia %d",name,GetPlayerNameEx(targetid),amount);
			SendClientMessageEx(playerid, -1, string);
			return 1;
		}
		return 1;
	}
	//Player
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho95], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxanglon92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[playerid][pBinhxangnho92], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET cash = %i WHERE uid = %i", PlayerInfo[playerid][pCash],PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, queryBuffer);

	//Tagertid
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon95 = %i WHERE uid = %i", PlayerInfo[targetid][pBinhxanglon95], PlayerInfo[targetid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho95 = %i WHERE uid = %i", PlayerInfo[targetid][pBinhxangnho95], PlayerInfo[targetid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxanglon92 = %i WHERE uid = %i", PlayerInfo[targetid][pBinhxanglon92], PlayerInfo[targetid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Binhxangnho92 = %i WHERE uid = %i", PlayerInfo[targetid][pBinhxangnho92], PlayerInfo[targetid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET cash = %i WHERE uid = %i", PlayerInfo[targetid][pCash],PlayerInfo[targetid][pID]);
    mysql_tquery(connectionID, queryBuffer);
	return 1;
}


/*stock IsPlayerInRangeOfActor(playerid, actorid, Float:radius = 5.0)
{
        new Float:x,
            Float:y,
            Float:z;

        if (GetActorPos(actorid, x, y, z))
        {
            return IsPlayerInRangeOfPoint(playerid, radius, x, y, z);
        }
        return 0;
}*/