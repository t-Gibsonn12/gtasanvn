#include <YSI\y_hooks>

#define DIALOG_HUONGDAN (2000)
#define DIALOG_HUONGDANTRANGKE (2001)

new Text3D:vehiclescarbus[MAX_VEHICLES],carbus[4];
new Npc_xinvieclam;
new buscompany;

hook OnGameModeInit(playerid){
	Npc_xinvieclam = CreateActor(255, 916.1121,-1235.2084,17.2109,84.6230);
	CreateDynamic3DTextLabel("Quan Ly Bus", -1, 916.1121,-1235.2084,17.2109+1, 20.0);
    ApplyActorAnimation(Npc_xinvieclam, "DEALER", "shop_pay", 4.1,0,0,0,0,0);	

    //cho lam cong ty bus
	buscompany = CreateDynamicObject(7313, 923.476806, -1221.399902, 21.395515, 0.000000, 0.000000, 89.600013, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterialText(buscompany, 0, "{ff0000} Bus Company", 70, "Ariel", 25, 1, 0x00000000, 0x00000001, 1);
	buscompany = CreateDynamicObject(19482, 924.988952, -1221.516967, 24.668680, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	SetDynamicObjectMaterial(buscompany, 0, 10101, "2notherbuildsfe", "ferry_build14", 0x00000000);
	SetDynamicObjectMaterialText(buscompany, 0, "{ffffff}BUS", 50, "Calibri", 50, 1, 0x00FF0000, 0x00000000, 1);

	//Spawn Car BUS
	carbus[0] = CreateVehicle(431,848.8061,-1184.9834,16.9766,179.5221,-1 , -1,60);
	carbus[1] = CreateVehicle(431,884.5059,-1186.5009,16.9766,178.8326,-1 , -1,60);
	carbus[2] = CreateVehicle(431,917.5449,-1186.8055,16.9766,178.6028,-1 , -1,60);
	carbus[3] = CreateVehicle(431,882.5764,-1269.4237,14.7267,271.6637,-1 , -1,60);
	
	//TEXTCAR
    vehiclescarbus[carbus[0]] = Create3DTextLabel( "{FFFF00}Bus Company", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
    vehiclescarbus[carbus[1]] = Create3DTextLabel( "{FFFF00}Bus Company", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
    vehiclescarbus[carbus[2]] = Create3DTextLabel( "{FFFF00}Bus Company", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
    vehiclescarbus[carbus[3]] = Create3DTextLabel( "{FFFF00}Bus Company", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );


    Attach3DTextLabelToVehicle(vehiclescarbus[carbus[0]],carbus[0], 0.0, 0.0, 2.0);
    Attach3DTextLabelToVehicle(vehiclescarbus[carbus[1]],carbus[1], 0.0, 0.0, 2.0);
    Attach3DTextLabelToVehicle(vehiclescarbus[carbus[2]],carbus[2], 0.0, 0.0, 2.0);
    Attach3DTextLabelToVehicle(vehiclescarbus[carbus[3]],carbus[3], 0.0, 0.0, 2.0);
	return 1;
}

/*CMD:tuongtacnpc(playerid){
	if(PlayerInfo[playerid][pLevel] >= 2){
		ShowPlayerDialog(playerid, DIALOG_HUONGDAN, DIALOG_STYLE_MSGBOX, "Quan Ly Bus", "\tSo Luoc Cong Viec [BUS COMPANY]\nCong viec cua [Bus Company] la dang cong viec pho thong\nai cung co the lam con viec nay\nnhung toi thieu bat buoc tren cap do 2\n\t TRANG KE TIEP >>>>", "Trang Ke", "Huy bo");
		return 1;
	}
	else{
		SendClientMessage(playerid, COLOR_RED, "Cong Viec: Ban phai dat cap do 2 moi co the xin viec lam cua [Bus Company]");
	}
	return 1;
}*/

CMD:ruockhach(playerid){
	if(GetPVarType(playerid, "timdiadiem1") != 0){
		    return SendClientMessage(playerid, COLOR_RED, "Cong Viec: Ban dang check ban do cua thanh pho!");
    }
    if(GetVehicleModel(GetPlayerVehicleID(playerid)) == carbus[0] || GetVehicleModel(GetPlayerVehicleID(playerid)) == carbus[1] || GetVehicleModel(GetPlayerVehicleID(playerid)) == carbus[2] || GetVehicleModel(GetPlayerVehicleID(playerid)) == carbus[3])
	{
		if(GetPlayerState(playerid) != PLAYER_STATE_DRIVER){
			SendClientMessage(playerid, COLOR_RED,"Cong Viec: Ban phai o tren xe moi co the thuc hien cong viec [Bus Company]!");
		}else{
            SetPVarInt(playerid, "timdiadiem1", 1);
            SendClientMessage(playerid, COLOR_WHITE, "Ban dang thuc hien cong viec..");
            return 1;
		}
	}
	return 1;
}

hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
	if(IsPlayerInRangeOfActor(playerid,Npc_xinvieclam,5.0)){
	    if(newkeys & KEY_YES){
	        if(PlayerInfo[playerid][pLevel] >= 2){
			ShowPlayerDialog(playerid, DIALOG_HUONGDAN, DIALOG_STYLE_MSGBOX, "Quan Ly Bus", "\tSo Luoc Cong Viec [BUS COMPANY]\nCong viec cua [Bus Company] la dang cong viec pho thong\nai cung co the lam con viec nay\nnhung toi thieu bat buoc tren cap do 2\n\t TRANG KE TIEP >>>>", "Trang Ke", "Huy bo");
			return 1;
			}
			else{
				SendClientMessage(playerid, COLOR_RED, "Cong Viec: Ban phai dat cap do 2 moi co the xin viec lam cua [Bus Company]");
			}
	    }
	}
    return 1;
}

hook OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]){
	if(dialogid == DIALOG_HUONGDAN){
		if(response){
			ShowPlayerDialog(playerid, DIALOG_HUONGDANTRANGKE, DIALOG_STYLE_MSGBOX, "Quan Ly Bus", "\tHuong Dan Cong Viec [BUS COMPANY]\nBuoc 1: Ngoi  len xe cong ty\nBuoc 2: /batdaucongviec\nBuoc 3: Chay theo tung diem den co tren ban do\nBuoc 4: sau khi chay het diem den cua ban do\nBuoc 5: Quay ve lai cong ty va nhan thuong", "Dong y", "Huy bo");
		}
	}
	if(dialogid == DIALOG_HUONGDANTRANGKE){
		if(response){
			SendClientMessage(playerid, COLOR_WHITE, "Cong Viec: Cong ty da cap cho ban dong phuc chut ban thanh cong!");
		}
	}
	return 1;
}


stock IsPlayerInRangeOfActor(playerid, actorid, Float:radius = 5.0)
{
        new Float:x,
            Float:y,
            Float:z;

        if (GetActorPos(actorid, x, y, z))
        {
            return IsPlayerInRangeOfPoint(playerid, radius, x, y, z);
        }
        return 0;
}