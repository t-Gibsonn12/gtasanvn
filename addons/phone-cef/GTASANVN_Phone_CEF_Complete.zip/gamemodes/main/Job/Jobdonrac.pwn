#include <YSI\y_hooks>

#define DIALOG_congviecdonrac 1
#define DIALOG_dongphuc 2

new NPC_Nhanviec;
new Text3D:vehiclesdonrac[MAX_VEHICLES],spawnxerac[3];
new Text3D:vehiclesdonrac2[MAX_VEHICLES];


hook OnGameModeInit(playerid){
    NPC_Nhanviec = CreateActor(28, 2171.3254,-1975.1503,13.5553,181.3829);
    CreateDynamic3DTextLabel("Quan Li Dannl", -1 , 2171.3254,-1975.1503,13.5553+1, 20.0);
    ApplyActorAnimation(NPC_Nhanviec, "DEALER", "shop_pay", 4.1,0,0,0,0,0);

    //SpawnCar
    spawnxerac[0] = CreateVehicle( 408,2137.4856,-1969.7838,13.5546,89.4999,-1 , -1,60 );
    spawnxerac[1] = CreateVehicle( 408,2161.6882,-1971.2611,13.5530,89.9590,-1 , -1,60 );
    spawnxerac[2] = CreateVehicle( 408,2152.2991,-1970.2654,13.5469,89.2701,-1 , -1,60 );
    

    //TEXTCAR
    vehiclesdonrac[spawnxerac[0]] = Create3DTextLabel( "{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: Chua Co", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
    vehiclesdonrac[spawnxerac[1]] = Create3DTextLabel( "{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: Chua Co", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
    vehiclesdonrac[spawnxerac[2]] = Create3DTextLabel( "{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: Chua Co", 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
    
    
    Attach3DTextLabelToVehicle(vehiclesdonrac[spawnxerac[0]],spawnxerac[0], 0.0, 0.0, 2.0);
    Attach3DTextLabelToVehicle(vehiclesdonrac[spawnxerac[1]],spawnxerac[1], 0.0, 0.0, 2.0);
    Attach3DTextLabelToVehicle(vehiclesdonrac[spawnxerac[2]],spawnxerac[2], 0.0, 0.0, 2.0);

    //Object Bichrac
    CreateDynamicObject(1265, 1937.880249, -1925.866333, 12.947396, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
    CreateDynamicObject(1265, 2074.466796, -1738.749511, 12.921195, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
    CreateDynamicObject(1328, 2368.129638, -1665.537109, 13.092818, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);
    
    //Object thungrac
    CreateDynamicObject(1328, 1938.680053, -1925.984008, 13.056854, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
    CreateDynamicObject(1328, 2074.614013, -1737.980468, 13.073176, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
    CreateDynamicObject(1265, 2368.931640, -1665.557739, 12.996877, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
    
    return 1;
} 

stock textvehicles(playerid){
    new vehicleid;
    new string[1280];
    if(PlayerInfo[playerid][pRactrenxe] == 1){
        Delete3DTextLabel(vehiclesdonrac[spawnxerac[0]]);
        Delete3DTextLabel(vehiclesdonrac[spawnxerac[1]]);
        Delete3DTextLabel(vehiclesdonrac[spawnxerac[2]]);
        Attach3DTextLabelToVehicle(vehiclesdonrac2[spawnxerac[0]],spawnxerac[0], 0.0, 0.0, 2.0);
        Attach3DTextLabelToVehicle(vehiclesdonrac2[spawnxerac[1]],spawnxerac[1], 0.0, 0.0, 2.0);
        Attach3DTextLabelToVehicle(vehiclesdonrac2[spawnxerac[2]],spawnxerac[2], 0.0, 0.0, 2.0);
        vehiclesdonrac2[spawnxerac[0]] = Create3DTextLabel( "{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: %d/1",PlayerInfo[playerid][pRactrenxe], 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
        vehiclesdonrac2[spawnxerac[1]] = Create3DTextLabel( "{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: %d/1",PlayerInfo[playerid][pRactrenxe], 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );
        vehiclesdonrac2[spawnxerac[2]] = Create3DTextLabel( "{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: %d/1",PlayerInfo[playerid][pRactrenxe], 0xFF0000AA, 0.0, 0.0, 0.0, 50.0, 0, 1 );

    }
    else{
        if(vehicleid == vehiclesdonrac[spawnxerac[0]])
        {
            format(string, sizeof(string),"{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: Chua Co");
            Update3DTextLabelText(vehiclesdonrac[spawnxerac[0]], 0xFFFFFFFF,string);
            return 1;
        }
        if(vehicleid == vehiclesdonrac[spawnxerac[1]])
        {
            format(string, sizeof(string),"{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: Chua Co");
            Update3DTextLabelText(vehiclesdonrac[spawnxerac[1]], 0xFFFFFFFF,string);
            return 1;
        }
        if(vehicleid == vehiclesdonrac[spawnxerac[2]])
        {
            format(string, sizeof(string),"{FFFF00}Xe Don Rac\n{FFFF00}Bich Rac: Chua Co");
            Update3DTextLabelText(vehiclesdonrac[spawnxerac[2]], 0xFFFFFFFF,string);
            return 1;
        }
    }
    return 1;
}

stock xinvieclam(playerid){
    if(IsPlayerInAnyVehicle(playerid)) return SendClientMessageEx(playerid, COLOR_RED, "Cong Viec: Ban khong the xin viec trong mot chiec xe!");
    if(PlayerInfo[playerid][pLevel] < 2) return SendClientMessage(playerid,COLOR_RED,"Cong Viec: Cap do phai tu Level 2 tro len moi co the nhan viec!");
	if(IsPlayerInAnyVehicle(playerid)) return SendClientMessageEx(playerid, COLOR_GRAD1, "Ban khong the xin viec trong mot chiec xe.");
	if(GetPlayerState(playerid) == 1 && PlayerInfo[playerid][pJob] == 0 || PlayerInfo[playerid][pJob2] == 0) {
		if(IsPlayerInRangeOfActor(playerid,NPC_Nhanviec,5.0)){
			if(PlayerInfo[playerid][pJob] == 0){
				SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban da lua chon cong viec don rac, gio thi bat dau vao cong viec!");
				GettingJob[playerid] = 22;
                PlayerInfo[playerid][pJob] =22;
				return 1;
			}
			if((PlayerInfo[playerid][pDonateRank] > 0 || PlayerInfo[playerid][pFamed] > 0) && PlayerInfo[playerid][pJob2] == 0) {
				SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban da lua chon cong viec don rac, gio thi bat dau vao cong viec!");
				GettingJob2[playerid] = 22;
                PlayerInfo[playerid][pJob2] =22;
				return 1;
			}
		}
		else {
			SendClientMessageEx(playerid, COLOR_RED, "Cong Viec: Ban khong o gan cho xin viec lam!");
		}
	}
	else {
		if(PlayerInfo[playerid][pDonateRank] == 0){
			SendClientMessageEx(playerid, COLOR_RED, "Cong Viec: Ban dang co mot cong viec, su dung /nghiviec de thoat khoi cong viec!");
            SendClientMessageEx(playerid, COLOR_RED, "Cong Viec: Chi VIP/Famed moi co the nhan duoc hai cong viec!");
		}
		else{
			SendClientMessageEx(playerid, COLOR_TWGRAY, "Cong Viec: Ban dang co 2 cong viec, su dung /nghiviec de thoat khoi cong viec!");
		}
	}
    return 1;
}

CMD:trogiupcongviec(playerid,params[]){
    new trogiup;
    if(PlayerInfo[playerid][pJob] == 22){
        if(sscanf(params, "cv", trogiup)) {
            SendClientMessageEx(playerid, COLOR_GREEN, "_______________________________________");
            SendClientMessageEx(playerid, COLOR_GRAD4, "Buoc 1: Nhan viec va chuan bi 1 chiec xe don rac");
            SendClientMessageEx(playerid, COLOR_GRAD4, "Buoc 2: Dung lenh [/donrac] de lam bat dau lam viec");
            SendClientMessageEx(playerid, COLOR_GRAD3, "Buoc 3: Di den checkpoint hien thi tren ban do");
            SendClientMessageEx(playerid, COLOR_GRAD4, "Buoc 4: Dung Lenh [/layrac] hoac [Y] de lay rac");
            SendClientMessageEx(playerid, COLOR_GRAD4, "Buoc 5: Di toi xe rac va [/dorac]");
            SendClientMessageEx(playerid, COLOR_GRAD4, "Buoc 6: Quay ve lai dia diem nhan viec va nhan tien thuong");
            SendClientMessageEx(playerid, COLOR_RED, "Luu Y: Xe don rac se duoc reset thuong xuyen, tranh tinh trang afk!");
            SendClientMessageEx(playerid, COLOR_GREEN, "_______________________________________");
            return 1;
        }
    }
    else{
        SendClientMessage(playerid,COLOR_RED,"Cong Viec: Ban khong phai nhan vien don rac,nen khong the xem muc huong dan cong viec!");
    }
    return 1;
}

CMD:timrac(playerid,params[]){
    if(PlayerInfo[playerid][pJob] != 22 && PlayerInfo[playerid][pJob2] != 22)
	{
		return SendClientMessage(playerid, COLOR_RED, "Cong Viec: Ban khong phai nhan vien don rac!");
	}
    if(PlayerInfo[playerid][pJob] == 22 || PlayerInfo[playerid][pJob2] == 22){
        if(PlayerInfo[playerid][pRactrenxe] == 7) return SendClientMessage(playerid, COLOR_RED, "Cong Viec: Rac tren xe cua ban da day!");
        if(GetPVarType(playerid, "timrac1") != 0){
		    return SendClientMessage(playerid, COLOR_RED, "Cong Viec: Ban dang check ban do rac cua thanh pho!");
        }
        if(GetVehicleModel(GetPlayerVehicleID(playerid)) == 408)
	    {
            SetPVarInt(playerid, "timrac1", 1);
            randomcheckpoint(playerid);
            return 1;
		}
        else{
		SendClientMessage(playerid, COLOR_RED,"Cong Viec: Ban khong co xe don rac, nen khong the tiep tuc cong viec!");
		}
    }
    return 1;
}

CMD:kiemtrarac(playerid,params[]){
    new string[128];
    format(string, 128, "Bichrac: %d", PlayerInfo[playerid][pRactrentay]);
	SendClientMessage(playerid, -1, string);
    return 1;
}

CMD:donrac(playerid,params[]){
    if(PlayerInfo[playerid][pJob] != 22 && PlayerInfo[playerid][pJob2] != 22)
	{
		return SendClientMessage(playerid, COLOR_RED, "Cong Viec: Ban khong phai nhan vien don rac!");
	}
    if(PlayerInfo[playerid][pJob] == 22 || PlayerInfo[playerid][pJob2] == 22){
        if(PlayerInfo[playerid][pRactrenxe] == 7) return SendClientMessage(playerid, COLOR_RED, "Cong Viec: Rac tren xe cua ban da day!");
        if(GetPVarType(playerid, "donrac1") == 1){
		    return 1;
        }
        if(GetPlayerState(playerid) != PLAYER_STATE_ONFOOT) SendClientMessage(playerid, COLOR_RED,"Cong Viec: Ban phai o ngoai xe moi co the thuc hien viec don rac!");      
        SetPVarInt(playerid, "donrac1", 1);
    }
    return 1;
}

hook OnPlayerEnterCheckpoint(playerid){
    if(GetPVarType(playerid, "donrac1") == 1)
    {
        SetTimerEx("OnPlayerDonRac", 10000, false, "i", playerid);
        GameTextForPlayer(playerid,"~w~Bat Dau Don Rac...", 5000, 1);
        ApplyAnimation(playerid, "BOMBER", "BOM_Plant",4.1,1,0,0,1,1);
        PlayerInfo[playerid][pRactrentay] += 1;
    }
    if(GetPVarType(playerid, "tienluong") == 1)
    {
        PlayerInfo[playerid][pRactrenxe] -= 1;
        PlayerInfo[playerid][pCash] += 20000;
        SendClientMessage(playerid,COLOR_GREEN,"Cong Viec: ban da hoan thanh nhiem vu voi muc luong 20k!");
        DisablePlayerCheckpoint(playerid);
    }
}

stock randomcheckpoint(playerid){
    new rdcp = random(10);
    switch(rdcp){
        case 0..3:{
            SetPlayerCheckpoint(playerid,1937.880249, -1925.866333, 12.947396,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban da nhan duoc nhiem vu, hay chu y den ban do!");
        }
        case 4..7:{
            SetPlayerCheckpoint(playerid,2074.466796, -1738.749511, 12.921195,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban da nhan duoc nhiem vu, hay chu y den ban do!");
        }
        case 8..10:{
            SetPlayerCheckpoint(playerid,2368.129638, -1665.537109, 13.092818,3);
            SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban da nhan duoc nhiem vu, hay chu y den ban do!");
        }
    }
    return 1;
}

CMD:chatrac(playerid,params[]){
    new xedonracgannhat = GetClosestCar(playerid);
    if(IsPlayerInRangeOfVehicle(playerid, xedonracgannhat, 5.0)){
        if(PlayerInfo[playerid][pRactrentay] == 1)
        {
            ApplyAnimation(playerid, "BOMBER", "BOM_Plant",4.1,1,0,0,1,1);
            SetPVarInt(playerid, "ketthuc", 1);
            SetTimerEx("OnPlayerChatRac", 5000, false, "i", playerid);
            PlayerInfo[playerid][pRactrenxe] += 1;
        }
    }
    else{
        SendClientMessage(playerid,COLOR_RED,"Cong Viec: Ban phai o gan chiec xe do rac!");
    }
    return 1;
}

CMD:ractrenxe(playerid,params[]){
    new string[128];
    format(string, 128, "Rac Tren Xe: %d", PlayerInfo[playerid][pRactrenxe]);
	SendClientMessage(playerid, -1, string);
    return 1;
}

forward OnPlayerChatRac(playerid);
public OnPlayerChatRac(playerid){
    if(GetPVarType(playerid, "ketthuc") == 1){
        RemovePlayerAttachedObject(playerid, 0);
        RemovePlayerAttachedObject(playerid, 1);
        SetPlayerSpecialAction(playerid, 0);
        ClearAnimations(playerid, 0);
        PlayerInfo[playerid][pRactrentay] -= 1;
        DeletePVar(playerid, "donrac1");
        DeletePVar(playerid, "chatrac1");
        DeletePVar(playerid, "timrac1");
        DeletePVar(playerid, "ketthuc");
        textvehicles(playerid);
        SetTimerEx("Nhantien", 3000, false, "i", playerid);
    }
    else{
        SendClientMessage(playerid,COLOR_RED,"Cong Viec: ban khong co bich rac nao tren tay ca!");
    }
    return 1;
}

forward Nhantien(playerid);
public Nhantien(playerid){
    SetPlayerCheckpoint(playerid,2171.3254,-1975.1503,13.5553,3);
    SetPVarInt(playerid, "tienluong", 1);
    RemovePlayerAttachedObject(playerid, 0);
    RemovePlayerAttachedObject(playerid, 1);
    SetPlayerSpecialAction(playerid, 0);
    ClearAnimations(playerid, 0);
    return 1;
}


forward OnPlayerDonRac(playerid);
public OnPlayerDonRac(playerid){
    if(GetPVarType(playerid, "donrac1") == 1){
        ClearAnimations(playerid);
        TogglePlayerControllable(playerid, 1);
        SetPVarInt(playerid, "chatrac1", 1);
        DisablePlayerCheckpoint(playerid);
        SetPlayerSpecialAction(playerid, 0);
        SetPlayerAttachedObject (playerid, 0, 1265, 13, 0.560999, -0.317000, -0.194999, 0.000000, 0.000000, 0.000000, 1.000000, 1.000000, 1.000000);
        SetPlayerSpecialAction(playerid, SPECIAL_ACTION_CARRY);
        SendClientMessage(playerid, COLOR_GREEN, "Cong Viec: Ban da nhat bich rac tren tay, hay di do chung!");
    }
    return 1;
}

hook OnPlayerDisconnect(playerid, reason)
{
    DeletePVar(playerid, "donrac1");
    DeletePVar(playerid, "chatrac1");
    DeletePVar(playerid, "timrac1");
    DeletePVar(playerid, "ketthuc");
	RemovePlayerAttachedObject(playerid, 0);
    RemovePlayerAttachedObject(playerid, 1);
    Delete3DTextLabel(vehiclesdonrac[spawnxerac[0]]);
    Delete3DTextLabel(vehiclesdonrac[spawnxerac[1]]);
    Delete3DTextLabel(vehiclesdonrac[spawnxerac[2]]);
	return 1;
}



hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
    if(newkeys & KEY_YES)
    {
        if(IsPlayerInRangeOfActor(playerid,NPC_Nhanviec,5.0)){
            ShowPlayerDialog(playerid, DIALOG_congviecdonrac, DIALOG_STYLE_LIST, "Cong Viec Don Rac", "Xin Viec Lam\t{98fb98}Mo Tuyen...{98fb98}\nDong Phuc", "Dong Y", "Huy Bo");
        }
    }
    if(newkeys & KEY_YES){
        cmd_donrac(playerid, "\1");
    }
    return 1;
}

hook OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]){
    if(dialogid == DIALOG_congviecdonrac)
    {
        switch(listitem)
        {
            //Xinvieclam
            case 0:{
                xinvieclam(playerid);
            }
            //Dongphuc
            case 1:{
                ShowPlayerDialog(playerid, DIALOG_dongphuc, DIALOG_STYLE_LIST, "Dong Phuc", "Dong Phuc 1\nDong Phuc 2", "Dong Y", "Huy Bo"); 
            }
        }
        return 1;
    }
    if(dialogid == DIALOG_dongphuc){
        switch(listitem)
        {
            case 0:{
                SetPlayerSkin(playerid,305);
                PlayerInfo[playerid][pModel] = 305;
            }
            case 1:{
                SetPlayerSkin(playerid,50);
                PlayerInfo[playerid][pModel] = 50;
            }
        }
    }
    return 1;
}

stock IsPlayerInRangeOfActor(playerid, actorid, Float:radius = 5.0)
{
        new Float:x,
            Float:y,
            Float:z;

        if (GetActorPos(actorid, x, y, z))
        {
            return IsPlayerInRangeOfPoint(playerid, radius, x, y, z);
        }
        return 0;
}