#include <a_samp>


stock CreateCS(csid)
{
	if(csid > sizeof(PosCanSa)) return printf("Can Sa ID: %d Cann't Create", i);

	CSInfo[csid][object] = CreateObject(19473,PosCanSa[csid][0],PosCanSa[csid][1],PosCanSa[csid][2],0,0,0,300);
	CSInfo[csid][status] = 1;
	CSInfo[csid][collecting] = 0;
}

hook OnGameModeInit()
{
	for(new i = 0 ; i < sizeof(PosCanSa); i++)
	{
		CreateCS(csid);
	}
	return 1;
}

stock IsInRangeOfCS(playerid, Float:range)
{
	for(new i = 0 ; i < sizeof(PosCanSa) ; i++){
		if(IsPlayerInRangeOfPoint(playerid, range, PosCanSa[i][0],PosCanSa[i][1],PosCanSa[csid][2]))
		{
			return i;
		}
	}
	return -1;
}
new CS_Collecting[MAX_PLAYERS];
hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
	if(newkeys == KEY_YES)
	{
		new csid = IsInRangeOfCS(playerid, 2.0);
		if(csid != -1)
		{
			if(CS_Collecting[playerid] == 0)
			{
				CS_Collecting[playerid] = 1;
				CSInfo[csid][status] = 0;	
				CSInfo[csid][collecting] = 1;
				StartProgress(playerid, 20, "Dang hai can sa", "FinishCS");
				SetPVarInt(playerid,"CSID_", csid);
			}
			else SendClientMessage(playerid, COLOR_YELLOW, "CANH BAO: Ban dang hai can sa , khong the tiep tuc");
		}
		else SendClientMessage(playerid,COLOR_RED, "THONG BAO LOI: Ban khong dung gan cay can xa nao");
	}
	return 1;
}

forward FinishCS(playerid);
public FinishCS(playerid)
{
	new csid = GetPVarInt(playerid,"CSID_");
	CSInfo[csid][status] = 0;	
	CSInfo[csid][collecting] = 0;
	CS_Collecting[playerid] = 0;
	DestroyObject(CSInfo[csid][object]);

	PlayerInfo[playerid][pLaCS] ++;
	SendClientMessage(playerid, COLOR_GREEN, "THONG BAO: Ban da hai thanh cong 1 cay can sa");
	return 1;
}