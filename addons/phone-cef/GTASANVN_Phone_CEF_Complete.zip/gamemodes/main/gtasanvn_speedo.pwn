// GTASANVN Speedometer CEF | requires cef.inc, y_hooks, a_samp
#if defined _GTASANVN_SPEEDO
    #endinput
#endif
#define _GTASANVN_SPEEDO
#define GT_SPEEDO_BROWSER (52420)
#define GT_SPEEDO_URL "http://cef/gtasanvn_speedo/index.html"
#define GT_SPEEDO_INTERVAL (300)
new bool:gtSpeedoReady[MAX_PLAYERS];
new bool:gtSpeedoCreated[MAX_PLAYERS];
new bool:gtSpeedoVisible[MAX_PLAYERS];
new gtSpeedoTimer = -1;
new Float:gtSpeedoFuel[MAX_VEHICLES];
new Float:gtSpeedoOdo[MAX_VEHICLES];
new Float:gtSpeedoLastX[MAX_VEHICLES], Float:gtSpeedoLastY[MAX_VEHICLES], Float:gtSpeedoLastZ[MAX_VEHICLES];
new bool:gtSpeedoLastValid[MAX_VEHICLES];
forward GTASANVN_SpeedoTick();
stock GTASANVN_SetSpeedoFuel(vehicleid, Float:percent)
{
    if (vehicleid < 1 || vehicleid >= MAX_VEHICLES) return 0;
    if (percent < 0.0) percent = 0.0;
    if (percent > 100.0) percent = 100.0;
    gtSpeedoFuel[vehicleid] = percent;
    return 1;
}
stock GTASANVN_ResetSpeedo(vehicleid)
{
    if (vehicleid < 1 || vehicleid >= MAX_VEHICLES) return 0;
    gtSpeedoFuel[vehicleid] = 100.0;
    gtSpeedoOdo[vehicleid] = 0.0;
    gtSpeedoLastValid[vehicleid] = false;
    return 1;
}
stock GTSpeedoHookInit()
{
    CEF_AddResource("gtasanvn_speedo");
    for (new v = 1; v < MAX_VEHICLES; v++) gtSpeedoFuel[v] = 100.0;
    gtSpeedoTimer = SetTimer("GTASANVN_SpeedoTick", GT_SPEEDO_INTERVAL, true);
    return 1;
}
stock GTSpeedoHookExit()
{
    if (gtSpeedoTimer != -1) KillTimer(gtSpeedoTimer);
    return 1;
}
stock GTSpeedoHookConnect(playerid)
{
    gtSpeedoReady[playerid] = false;
    gtSpeedoCreated[playerid] = false;
    gtSpeedoVisible[playerid] = false;
    return 1;
}
stock GTSpeedoHookDisconnect(playerid, reason)
{
    gtSpeedoReady[playerid] = false;
    gtSpeedoCreated[playerid] = false;
    gtSpeedoVisible[playerid] = false;
    return 1;
}
stock GTSpeedoHookReady(playerid)
{
    if (gtSpeedoReady[playerid]) return 1;
    gtSpeedoReady[playerid] = true;
    CEF_CreateBrowser(playerid, GT_SPEEDO_BROWSER, GT_SPEEDO_URL, false);
    return 1;
}
stock GTSpeedoHookBrowserCreated(playerid, browserid, bool:success, E_CEF_CREATE_STATUS:code, const reason[])
{
    if (browserid != GT_SPEEDO_BROWSER) return 1;
    gtSpeedoCreated[playerid] = success;
    if (success)
    {
        CEF_SetBrowserLayer(playerid, browserid, 5);
        CEF_SetBrowserVisible(playerid, browserid, true);
        CEF_EmitEvent(playerid, browserid, "speedo:hide");
    }
    else printf("[GT SPEEDO] CEF create failed player=%d: %s", playerid, reason);
    return 1;
}
public GTASANVN_SpeedoTick()
{
    // Odometer is session-only and in approximate GTA world kilometres.
    for (new v = 1; v < MAX_VEHICLES; v++)
    {
        if (!IsValidVehicle(v)) { gtSpeedoLastValid[v] = false; continue; }
        new Float:x, Float:y, Float:z;
        GetVehiclePos(v, x, y, z);
        if (gtSpeedoLastValid[v])
        {
            new Float:dx = x - gtSpeedoLastX[v], Float:dy = y - gtSpeedoLastY[v], Float:dz = z - gtSpeedoLastZ[v];
            new Float:dist = floatsqroot(dx*dx + dy*dy + dz*dz);
            if (dist < 30.0) gtSpeedoOdo[v] += dist / 1000.0;
        }
        gtSpeedoLastX[v] = x; gtSpeedoLastY[v] = y; gtSpeedoLastZ[v] = z;
        gtSpeedoLastValid[v] = true;
    }
    for (new playerid = 0; playerid < MAX_PLAYERS; playerid++)
    {
        if (!IsPlayerConnected(playerid) || !gtSpeedoCreated[playerid]) continue;
        new vehicleid = GetPlayerVehicleID(playerid);
        if (GetPlayerState(playerid) != PLAYER_STATE_DRIVER || vehicleid < 1 || !IsValidVehicle(vehicleid))
        {
            if (gtSpeedoVisible[playerid])
            {
                CEF_EmitEvent(playerid, GT_SPEEDO_BROWSER, "speedo:hide");
                gtSpeedoVisible[playerid] = false;
            }
            continue;
        }
        new Float:vx, Float:vy, Float:vz, Float:health;
        GetVehicleVelocity(vehicleid, vx, vy, vz);
        GetVehicleHealth(vehicleid, health);
        new speed = floatround(floatsqroot(vx*vx + vy*vy + vz*vz) * 180.0);
        if (speed > 360) speed = 360;
        new hp = floatround((health - 250.0) / 7.5);
        if (hp < 0) hp = 0;
        if (hp > 100) hp = 100;
        new engine, lights, alarm, doors, bonnet, boot, objective;
        GetVehicleParamsEx(vehicleid, engine, lights, alarm, doors, bonnet, boot, objective);
        CEF_EmitEvent(playerid, GT_SPEEDO_BROWSER, "speedo:update",
            CEF_INT(speed), CEF_INT(floatround(gtSpeedoFuel[vehicleid])), CEF_INT(hp),
            CEF_INT(floatround(gtSpeedoOdo[vehicleid] * 10.0)),
            CEF_BOOL(engine == VEHICLE_PARAMS_ON), CEF_BOOL(lights == VEHICLE_PARAMS_ON),
            CEF_BOOL(doors == VEHICLE_PARAMS_ON));
        gtSpeedoVisible[playerid] = true;
    }
    return 1;
}
