// GTASANVN CEF login/register integration. Include AFTER omp_base.pwn.
#if defined _GTASANVN_AUTH_PWN
    #endinput
#endif
#define _GTASANVN_AUTH_PWN
#define AURA_AUTH_BROWSER (52220)
#define AURA_AUTH_URL "http://cef/gtasanvn_login_v2/index.html"

new bool:gAuthReady[MAX_PLAYERS];
new bool:gAuthCreated[MAX_PLAYERS];
new bool:gAuthRequested[MAX_PLAYERS];
new bool:gAuthPending[MAX_PLAYERS];
new gAuthMode[MAX_PLAYERS]; // 1 login, 2 register
new gAuthRequestTick[MAX_PLAYERS];

stock AuraAuthResult(playerid, bool:ok, const msg[])
{
    if (gAuthCreated[playerid]) CEF_EmitEvent(playerid, AURA_AUTH_BROWSER, "auth:result", CEF_BOOL(ok), CEF_STR(msg));
    printf("[GTASANVN AUTH] result player=%d ok=%d msg=%s", playerid, _:ok, msg);
    gAuthPending[playerid] = false;
    gAuthRequestTick[playerid] = 0;
    return 1;
}
stock AuraAuthClose(playerid)
{
    gAuthMode[playerid] = 0;
    gAuthPending[playerid] = false;
    gAuthRequestTick[playerid] = 0;
    if (gAuthCreated[playerid])
    {
        CEF_FocusBrowser(playerid, AURA_AUTH_BROWSER, false);
        CEF_SetBrowserVisible(playerid, AURA_AUTH_BROWSER, false);
    }
    return 1;
}
stock AuraAuthShow(playerid, bool:login)
{
    gAuthMode[playerid] = login ? 1 : 2;
    if (!gAuthReady[playerid] || !gAuthCreated[playerid])
    {
        // Keep requested mode until OnCefReady + browser created.
        return 1;
    }
    CEF_SetBrowserVisible(playerid, AURA_AUTH_BROWSER, true);
    CEF_FocusBrowser(playerid, AURA_AUTH_BROWSER, true);
    CEF_EmitEvent(playerid, AURA_AUTH_BROWSER, "auth:mode", CEF_STR(login ? "login" : "register"), CEF_STR(GetPlayerNameEx(playerid)));
    return 1;
}

hook OnGameModeInit()
{
    GTPhoneHookInit();
    GTSpeedoHookInit();
    CEF_AddResource("gtasanvn_login_v2");
    SetTimer("GTASANVN_AuthWatchdog", 1000, true);
    CEF_RegisterEvent("auth:login", "GTASANVN_OnLogin", Argument_String);
    CEF_RegisterEvent("auth:register", "GTASANVN_OnRegister", Argument_String);
    CEF_RegisterEvent("auth:ready", "GTASANVN_OnUIReady");
    return 1;
}
hook OnPlayerConnect(playerid)
{
    GTPhoneHookConnect(playerid);
    GTSpeedoHookConnect(playerid);
    gAuthReady[playerid] = false;
    gAuthCreated[playerid] = false;
    gAuthRequested[playerid] = false;
    gAuthPending[playerid] = false;
    gAuthMode[playerid] = 0;
    gAuthRequestTick[playerid] = 0;
    return 1;
}
hook OnPlayerDisconnect(playerid, reason)
{
    GTPhoneHookDisconnect(playerid, reason);
    GTSpeedoHookDisconnect(playerid, reason);
    gAuthReady[playerid] = false;
    gAuthCreated[playerid] = false;
    gAuthRequested[playerid] = false;
    gAuthPending[playerid] = false;
    gAuthMode[playerid] = 0;
    gAuthRequestTick[playerid] = 0;
    return 1;
}
hook OnCefReady(playerid)
{
    GTPhoneHookReady(playerid);
    GTSpeedoHookReady(playerid);
    gAuthReady[playerid] = true;
    if (!gAuthRequested[playerid])
    {
        gAuthRequested[playerid] = true;
        CEF_CreateBrowser(playerid, AURA_AUTH_BROWSER, AURA_AUTH_URL, false);
    }
    return 1;
}
hook OnCefBrowserCreated(playerid, browserid, bool:success, E_CEF_CREATE_STATUS:code, const reason[])
{
    GTPhoneHookBrowserCreated(playerid, browserid, success, code, reason);
    GTSpeedoHookBrowserCreated(playerid, browserid, success, code, reason);
    if (browserid != AURA_AUTH_BROWSER) return 1;
    if (!success)
    {
        gAuthRequested[playerid] = false;
        SendClientMessage(playerid, 0xFF7777FF, "[CEF] Khong the mo giao dien dang nhap.");
        return 1;
    }
    gAuthCreated[playerid] = true;
    CEF_SetBrowserLayer(playerid, AURA_AUTH_BROWSER, 20);
    CEF_SetBrowserVisible(playerid, AURA_AUTH_BROWSER, false);
    if (gAuthMode[playerid] != 0)
        SetTimerEx("GTASANVN_DeferredShow", 800, false, "i", playerid);
    return 1;
}
forward GTASANVN_DeferredShow(playerid);
public GTASANVN_DeferredShow(playerid)
{
    if (IsPlayerConnected(playerid) && !PlayerInfo[playerid][pLogged] && gAuthMode[playerid])
        AuraAuthShow(playerid, gAuthMode[playerid] == 1);
    return 1;
}

// Username is always resolved on the server from the connected SA-MP player.
forward GTASANVN_OnUIReady(playerid);
public GTASANVN_OnUIReady(playerid)
{
    if (!IsPlayerConnected(playerid) || PlayerInfo[playerid][pLogged]) return 1;
    printf("[GTASANVN AUTH] UI ready player=%d created=%d mode=%d", playerid, _:gAuthCreated[playerid], gAuthMode[playerid]);
    if (gAuthCreated[playerid] && gAuthMode[playerid]) AuraAuthShow(playerid, gAuthMode[playerid] == 1);
    return 1;
}
forward GTASANVN_OnLogin(playerid, const password[]);
public GTASANVN_OnLogin(playerid, const password[])
{
    printf("[GTASANVN AUTH] LOGIN event player=%d mode=%d pending=%d", playerid, gAuthMode[playerid], _:gAuthPending[playerid]);
    if (!IsPlayerConnected(playerid) || PlayerInfo[playerid][pLogged] || gAuthMode[playerid] != 1 || gAuthPending[playerid]) return 1;
    if (strlen(password) < 3 || strlen(password) > 72)
        return AuraAuthResult(playerid, false, "Mat khau khong hop le.");
    new hash[129], specifiers[] = "%D of %M, %Y @ %k:%i";
    WP_Hash(hash, sizeof(hash), password);
    gAuthPending[playerid] = true;
    gAuthRequestTick[playerid] = GetTickCount();
    printf("[GTASANVN AUTH] DB request: player=%d mode=%d", playerid, gAuthMode[playerid]);
    mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "SELECT *, DATE_FORMAT(lastlogin, '%s') AS login_date FROM users WHERE username = '%e' AND password = '%e'", specifiers, GetPlayerNameEx(playerid), hash);
    mysql_tquery(connectionID, queryBuffer, "OnQueryFinished", "ii", THREAD_PROCESS_LOGIN, playerid);
    return 1;
}
forward GTASANVN_OnRegister(playerid, const password[]);
public GTASANVN_OnRegister(playerid, const password[])
{
    printf("[GTASANVN AUTH] REGISTER event player=%d mode=%d pending=%d", playerid, gAuthMode[playerid], _:gAuthPending[playerid]);
    if (!IsPlayerConnected(playerid) || PlayerInfo[playerid][pLogged] || gAuthMode[playerid] != 2 || gAuthPending[playerid]) return 1;
    if (strlen(password) < 3 || strlen(password) > 72)
        return AuraAuthResult(playerid, false, "Mat khau phai tu 3 den 72 ky tu.");
    new hash[129];
    WP_Hash(hash, sizeof(hash), password);
    gAuthPending[playerid] = true;
    gAuthRequestTick[playerid] = GetTickCount();
    printf("[GTASANVN AUTH] DB request: player=%d mode=%d", playerid, gAuthMode[playerid]);
    mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "INSERT INTO users (username, password, regdate, lastlogin, ip) VALUES('%e', '%e', NOW(), NOW(), '%e')", GetPlayerNameEx(playerid), hash, GetPlayerIP(playerid));
    mysql_tquery(connectionID, queryBuffer, "OnQueryFinished", "ii", THREAD_ACCOUNT_REGISTER, playerid);
    // Increment registration count after DB confirms insert (not before).
    return 1;
}

// Watchdog: never leave the browser permanently stuck in "Dang xac thuc".
forward GTASANVN_AuthWatchdog();
public GTASANVN_AuthWatchdog()
{
    for (new i = 0; i < MAX_PLAYERS; i++)
    {
        if (!IsPlayerConnected(i) || !gAuthPending[i] || !gAuthRequestTick[i]) continue;
        if (GetTickCount() - gAuthRequestTick[i] >= 15000)
        {
            printf("[GTASANVN AUTH] TIMEOUT player=%d mode=%d: check MySQL and OnQueryFinished", i, gAuthMode[i]);
            AuraAuthResult(i, false, "May chu xac thuc qua lau. Kiem tra MySQL / server_log.");
        }
    }
    return 1;
}

hook OnGameModeExit()
{
    GTSpeedoHookExit();
    return 1;
}
