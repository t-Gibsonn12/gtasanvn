// GTASANVN Phone CEF. Include AFTER omp_base.pwn. Requires a_mysql, zcmd, y_hooks, cef.
#if defined _GTASANVN_PHONE
    #endinput
#endif
#define _GTASANVN_PHONE
#define GT_PHONE_BROWSER (52310)
#define GT_PHONE_URL "http://cef/gtasanvn_phone/index.html"
#define GT_PHONE_MAX_CONTACTS (50)
new bool:gtPhoneCreated[MAX_PLAYERS], bool:gtPhoneOpen[MAX_PLAYERS];
new gtPhoneQueryToken[MAX_PLAYERS], gtPhoneLastAction[MAX_PLAYERS], gtPhoneAlertToken[MAX_PLAYERS];

stock GTPhoneRowCount()
{
    new rows, fields;
    cache_get_data(rows, fields, connectionID);
    return rows;
}

stock GTPhoneError(playerid, const message[])
{
    if (gtPhoneCreated[playerid]) CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:error", CEF_STR(message));
    return 1;
}
stock GTPhoneAllowed(playerid)
{
    if (!IsPlayerConnected(playerid) || !PlayerInfo[playerid][pLogged]) return 0;
    if (!PlayerInfo[playerid][pPhone]) { GTPhoneError(playerid, "Ban chua co dien thoai."); return 0; }
    if (PlayerInfo[playerid][pTogglePhone]) { GTPhoneError(playerid, "Dien thoai dang tat."); return 0; }
    if (PlayerInfo[playerid][pTazedTime] || PlayerInfo[playerid][pInjured] ||
        PlayerInfo[playerid][pHospital] || PlayerInfo[playerid][pTied] ||
        PlayerInfo[playerid][pCuffed] || PlayerInfo[playerid][pJailTime])
    {
        GTPhoneError(playerid, "Khong the su dung dien thoai luc nay.");
        return 0;
    }
    return 1;
}
stock bool:GTPhoneSession(playerid, uid, token)
{
    return IsPlayerConnected(playerid) && gtPhoneCreated[playerid] &&
        PlayerInfo[playerid][pLogged] && PlayerInfo[playerid][pID] == uid &&
        gtPhoneQueryToken[playerid] == token;
}

stock bool:GTPhoneAction(playerid)
{
    if (!gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return false;
    new now = GetTickCount();
    if (gtPhoneLastAction[playerid] && now - gtPhoneLastAction[playerid] < 650)
    {
        GTPhoneError(playerid, "Hay doi mot chut roi thu lai.");
        return false;
    }
    gtPhoneLastAction[playerid] = now;
    return true;
}

stock GTPhoneState(playerid)
{
    if (!gtPhoneCreated[playerid] || !PlayerInfo[playerid][pLogged]) return 0;
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:state", CEF_INT(PlayerInfo[playerid][pPhone]), CEF_INT(PlayerInfo[playerid][pBank]), CEF_STR(GetPlayerNameEx(playerid)));
    return 1;
}
stock GTPhoneOpen(playerid)
{
    if (!GTPhoneAllowed(playerid)) { SendClientMessage(playerid, -1, "[Phone] Ban can dang nhap, co dien thoai va bat dien thoai."); return 0; }
    if (!gtPhoneCreated[playerid]) { SendClientMessage(playerid, -1, "[Phone] CEF chua san sang."); return 0; }
    gtPhoneOpen[playerid] = true;
    CEF_SetBrowserVisible(playerid, GT_PHONE_BROWSER, true);
    CEF_FocusBrowser(playerid, GT_PHONE_BROWSER, true);
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:open");
    GTPhoneState(playerid);
    GTPhoneCallState(playerid);
    return 1;
}
stock GTPhoneClose(playerid)
{
    gtPhoneOpen[playerid] = false;
    if (gtPhoneCreated[playerid])
    {
        CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:closed");
        CEF_FocusBrowser(playerid, GT_PHONE_BROWSER, false);
        CEF_SetBrowserVisible(playerid, GT_PHONE_BROWSER, false);
    }
    return 1;
}
CMD:dienthoai(playerid, params[])
{
    if (gtPhoneOpen[playerid]) GTPhoneClose(playerid);
    else GTPhoneOpen(playerid);
    return 1;
}
CMD:phonecef(playerid, params[]) return cmd_dienthoai(playerid, params);

stock GTPhoneHookInit()
{
    CEF_AddResource("gtasanvn_phone");
    CEF_RegisterEvent("iphone:feed", "GTIPhoneFeed");
    CEF_RegisterEvent("iphone:post", "GTIPhonePost", Argument_String, Argument_String);
    CEF_RegisterEvent("iphone:transfer", "GTIPhoneTransfer", Argument_Integer, Argument_Integer);
    CEF_RegisterEvent("phone:ready", "GTPhoneOnReady");
    CEF_RegisterEvent("phone:close", "GTPhoneOnClose");
    CEF_RegisterEvent("phone:contacts", "GTPhoneContacts");
    CEF_RegisterEvent("phone:contactAdd", "GTPhoneContactAdd", Argument_String, Argument_Integer);
    CEF_RegisterEvent("phone:contactDelete", "GTPhoneContactDelete", Argument_Integer);
    CEF_RegisterEvent("phone:sms", "GTPhoneSMS", Argument_Integer, Argument_String);
    CEF_RegisterEvent("phone:history", "GTPhoneHistory");
    CEF_RegisterEvent("phone:call", "GTPhoneCall", Argument_Integer);
    CEF_RegisterEvent("phone:pickup", "GTPhonePickup");
    CEF_RegisterEvent("phone:hangup", "GTPhoneHangup");
    CEF_RegisterEvent("phone:refresh", "GTPhoneRefresh");
    CEF_RegisterEvent("phone:profile", "GTPhoneProfile");
    CEF_RegisterEvent("phone:jobs", "GTPhoneJobs");
    CEF_RegisterEvent("phone:pizza", "GTPhonePizza", Argument_Integer);
    CEF_RegisterEvent("phone:vehicles", "GTPhoneVehicles");
    CEF_RegisterEvent("phone:vehicleLocate", "GTPhoneVehicleLocate", Argument_Integer, Argument_Integer);
    CEF_RegisterEvent("phone:vehiclePark", "GTPhoneVehiclePark", Argument_Integer, Argument_Integer);
    CEF_RegisterEvent("phone:vehicleStorage", "GTPhoneVehicleStorage", Argument_Integer, Argument_Integer);
    CEF_RegisterEvent("phone:sendPosition", "GTPhoneSendPosition", Argument_Integer);
    CEF_RegisterEvent("phone:waypoint", "GTPhoneWaypoint", Argument_Integer);
    CEF_RegisterEvent("iphone:like", "GTPhoneLike", Argument_Integer);
    CEF_RegisterEvent("iphone:comments", "GTPhoneComments", Argument_Integer);
    CEF_RegisterEvent("iphone:comment", "GTPhoneComment", Argument_Integer, Argument_String);
    return 1;
}
stock GTPhoneHookConnect(playerid)
{
    gtPhoneCreated[playerid] = false;
    gtPhoneOpen[playerid] = false;
    gtPhoneQueryToken[playerid]++;
    gtPhoneLastAction[playerid] = 0;
    gtPhoneAlertToken[playerid]++;
    return 1;
}
stock GTPhoneHookDisconnect(playerid, reason)
{
    gtPhoneCreated[playerid] = false;
    gtPhoneOpen[playerid] = false;
    gtPhoneQueryToken[playerid]++;
    gtPhoneLastAction[playerid] = 0;
    gtPhoneAlertToken[playerid]++;
    return 1;
}
stock GTPhoneHookReady(playerid)
{
    CEF_CreateBrowser(playerid, GT_PHONE_BROWSER, GT_PHONE_URL, false);
    return 1;
}
stock GTPhoneHookBrowserCreated(playerid, browserid, bool:success, E_CEF_CREATE_STATUS:code, const reason[])
{
    if (browserid != GT_PHONE_BROWSER) return 1;
    if (!success) { printf("[GT PHONE] Browser error player=%d reason=%s", playerid, reason); return 1; }
    gtPhoneCreated[playerid] = true;
    CEF_SetBrowserLayer(playerid, GT_PHONE_BROWSER, 30);
    CEF_SetBrowserVisible(playerid, GT_PHONE_BROWSER, false);
    return 1;
}
forward GTPhoneOnReady(playerid);
public GTPhoneOnReady(playerid)
{
    if (!gtPhoneOpen[playerid]) return 1;
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:open");
    GTPhoneState(playerid);
    GTPhoneCallState(playerid);
    return 1;
}
forward GTPhoneOnClose(playerid);
public GTPhoneOnClose(playerid) { GTPhoneClose(playerid); return 1; }
forward GTPhoneRefresh(playerid);
public GTPhoneRefresh(playerid) { if (GTPhoneAllowed(playerid)) GTPhoneState(playerid); return 1; }

forward GTPhoneContacts(playerid);
public GTPhoneContacts(playerid)
{
    if (!GTPhoneAllowed(playerid)) return 1;
    new query[256];
    mysql_format(connectionID, query, sizeof query, "SELECT id, name, number FROM gt_phone_contacts WHERE owner_uid=%d ORDER BY name LIMIT 50", PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, query, "GTPhoneContactsLoaded", "iii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid]);
    return 1;
}
forward GTPhoneContactsLoaded(playerid, uid, token);
public GTPhoneContactsLoaded(playerid, uid, token)
{
    if (!IsPlayerConnected(playerid) || !gtPhoneCreated[playerid] || PlayerInfo[playerid][pID] != uid || gtPhoneQueryToken[playerid] != token) return 1;
    new rows=GTPhoneRowCount(), id, number, name[49];
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:contactsClear");
    for (new i=0; i<rows; i++)
    {
        id = cache_get_field_content_int(i, "id");
        number = cache_get_field_content_int(i, "number");
        cache_get_field_content(i, "name", name, connectionID, sizeof name);
        CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:contactItem", CEF_INT(id), CEF_STR(name), CEF_INT(number));
    }
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:contactsDone");
    return 1;
}
forward GTPhoneContactAdd(playerid, const name[], number);
public GTPhoneContactAdd(playerid, const name[], number)
{
    if (!GTPhoneAction(playerid)) return 1;
    if (strlen(name) < 1 || strlen(name) > 48 || number < 1000 || number > 999999999) return GTPhoneError(playerid, "Ten hoac so dien thoai khong hop le.");
    new query[300];
    mysql_format(connectionID, query, sizeof query, "INSERT INTO gt_phone_contacts(owner_uid,name,number) SELECT %d,'%e',%d WHERE (SELECT COUNT(*) FROM gt_phone_contacts WHERE owner_uid=%d)<50 ON DUPLICATE KEY UPDATE name=VALUES(name)", PlayerInfo[playerid][pID], name, number, PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, query, "GTPhoneAfterContact", "iii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid]);
    return 1;
}
forward GTPhoneContactDelete(playerid, id);
public GTPhoneContactDelete(playerid, id)
{
    if (!GTPhoneAction(playerid) || id <= 0) return 1;
    new query[180];
    mysql_format(connectionID, query, sizeof query, "DELETE FROM gt_phone_contacts WHERE id=%d AND owner_uid=%d", id, PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, query, "GTPhoneAfterContact", "iii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid]);
    return 1;
}
forward GTPhoneAfterContact(playerid, uid, token);
public GTPhoneAfterContact(playerid, uid, token)
{
    if (IsPlayerConnected(playerid) && PlayerInfo[playerid][pID] == uid && gtPhoneQueryToken[playerid] == token) GTPhoneContacts(playerid);
    return 1;
}
forward GTPhoneSMS(playerid, number, const message[]);
public GTPhoneSMS(playerid, number, const message[])
{
    if (strlen(message) < 1 || strlen(message) > 240) return GTPhoneError(playerid, "Tin nhan tu 1 den 240 byte.");
    return GTPhoneSendMessage(playerid, number, message, false);
}
forward GTPhoneCall(playerid, number);
public GTPhoneCall(playerid, number)
{
    if (!GTPhoneAction(playerid) || number < 1) return 1;
    new params[16]; format(params, sizeof params, "%d", number);
    cmd_goi(playerid, params);
    GTPhoneCallState(playerid);
    return 1;
}
forward GTPhonePickup(playerid);
public GTPhonePickup(playerid)
{
    if (GTPhoneAction(playerid)) cmd_pickup(playerid, "");
    return 1;
}
forward GTPhoneHangup(playerid);
public GTPhoneHangup(playerid)
{
    if (GTPhoneAction(playerid)) cmd_hangup(playerid, "");
    return 1;
}
forward GTPhoneHistory(playerid);
public GTPhoneHistory(playerid)
{
    if (!gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    new query[320], uid = PlayerInfo[playerid][pID];
    mysql_format(connectionID, query, sizeof query,
        "SELECT id,sender_number,recipient_number,body,has_position FROM gt_phone_messages WHERE sender_uid=%d OR recipient_uid=%d ORDER BY id DESC LIMIT 50", uid, uid);
    mysql_tquery(connectionID, query, "GTPhoneHistoryLoaded", "iii", playerid, uid, gtPhoneQueryToken[playerid]);
    return 1;
}
forward GTPhoneHistoryLoaded(playerid, uid, token);
public GTPhoneHistoryLoaded(playerid, uid, token)
{
    if (!GTPhoneSession(playerid, uid, token) || !gtPhoneOpen[playerid]) return 1;
    new rows = GTPhoneRowCount(), msg[241];
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:historyClear");
    for (new i; i < rows; i++)
    {
        cache_get_field_content(i, "body", msg, connectionID, sizeof msg);
        CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:historyItem",
            CEF_INT(cache_get_field_content_int(i, "id")), CEF_INT(cache_get_field_content_int(i, "sender_number")),
            CEF_INT(cache_get_field_content_int(i, "recipient_number")), CEF_STR(msg),
            CEF_INT(cache_get_field_content_int(i, "has_position")));
    }
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:historyDone");
    return 1;
}

// iPhone extensions: social feed and existing bank transfer command.
forward GTIPhoneFeed(playerid);
public GTIPhoneFeed(playerid)
{
    if (!gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    new q[384];
    mysql_format(connectionID, q, sizeof q,
        "SELECT p.id,p.author,p.body,p.photo_url,(SELECT COUNT(*) FROM gt_iphone_likes WHERE post_id=p.id) AS likes,(SELECT COUNT(*) FROM gt_iphone_likes WHERE post_id=p.id AND user_uid=%d) AS liked FROM gt_iphone_posts p ORDER BY p.id DESC LIMIT 30", PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, q, "GTIPhoneFeedLoaded", "iii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid]);
    return 1;
}
forward GTIPhoneFeedLoaded(playerid, uid, token);
public GTIPhoneFeedLoaded(playerid, uid, token)
{
    if (!IsPlayerConnected(playerid) || !gtPhoneCreated[playerid] || !PlayerInfo[playerid][pLogged] || PlayerInfo[playerid][pID] != uid || gtPhoneQueryToken[playerid] != token) return 1;
    new rows=GTPhoneRowCount(), author[25], body[241], photo[501];
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:feedClear");
    for (new i=0; i<rows; i++)
    {
        cache_get_field_content(i, "author", author, connectionID, sizeof author);
        cache_get_field_content(i, "body", body, connectionID, sizeof body);
        cache_get_field_content(i, "photo_url", photo, connectionID, sizeof photo);
        CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:postItem", CEF_INT(cache_get_field_content_int(i, "id")), CEF_STR(author), CEF_STR(body), CEF_STR(photo), CEF_INT(cache_get_field_content_int(i, "likes")), CEF_INT(cache_get_field_content_int(i, "liked")));
    }
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:feedDone");
    return 1;
}
forward GTIPhonePost(playerid, const body[], const photo[]);
public GTIPhonePost(playerid, const body[], const photo[])
{
    if (!GTPhoneAction(playerid)) return 1;
    if ((strlen(body) == 0 && strlen(photo) == 0) || strlen(body) > 240 || strlen(photo) > 500)
        return GTPhoneError(playerid, "Noi dung hoac anh khong hop le.");
    if (strlen(photo) && strfind(photo, "https://", true) != 0)
        return GTPhoneError(playerid, "Anh phai su dung lien ket HTTPS.");
    new q[1600];
    mysql_format(connectionID, q, sizeof q, "INSERT INTO gt_iphone_posts(author_uid, author, body, photo_url) VALUES(%d,'%e','%e','%e')", PlayerInfo[playerid][pID], GetPlayerNameEx(playerid), body, photo);
    printf("[GT SOCIAL] POST request player=%d uid=%d", playerid, PlayerInfo[playerid][pID]);
    if (!mysql_tquery(connectionID, q, "GTIPhoneAfterPost", "iii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid]))
        return GTPhoneError(playerid, "Khong the gui bai viet.");
    return 1;
}
forward GTIPhoneAfterPost(playerid, uid, token);
public GTIPhoneAfterPost(playerid, uid, token)
{
    if (!IsPlayerConnected(playerid) || !PlayerInfo[playerid][pLogged] || PlayerInfo[playerid][pID] != uid || gtPhoneQueryToken[playerid] != token) return 1;
    new affected = cache_affected_rows();
    printf("[GT SOCIAL] POST result player=%d affected=%d", playerid, affected);
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:postResult", CEF_BOOL(affected > 0), CEF_STR(affected > 0 ? "Dang bai thanh cong!" : "Khong luu duoc bai viet. Kiem tra bang MySQL."));
    if (affected > 0) GTIPhoneFeed(playerid);
    return 1;
}
forward GTIPhoneTransfer(playerid, targetid, amount);
public GTIPhoneTransfer(playerid, targetid, amount)
{
    if (!GTPhoneAction(playerid)) return 1;
    if (targetid < 0 || targetid >= MAX_PLAYERS || amount < 1 || amount > PlayerInfo[playerid][pBank]) return GTPhoneError(playerid, "ID hoac so tien khong hop le.");
    if (targetid == playerid || !IsPlayerConnected(targetid) || !PlayerInfo[targetid][pLogged]) return GTPhoneError(playerid, "Nguoi nhan khong hop le hoac chua dang nhap.");
    // Reuse original command to enforce bank location, level, audit log and balance updates.
    new params[40]; format(params, sizeof params, "%d %d", targetid, amount);
    cmd_chuyenkhoan(playerid, params);
    GTPhoneState(playerid);
    return 1;
}

stock GTPhoneNotice(playerid, const message[])
{
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:notice", CEF_STR(message));
    return 1;
}

stock GTPhoneMarkLocation(playerid, Float:x, Float:y, Float:z)
{
    if (GetPlayerVirtualWorld(playerid) || GetPlayerInterior(playerid))
        return GTPhoneError(playerid, "Hay ra ngoai truoc khi bat GPS.");
    if (PlayerInfo[playerid][pCP] != CHECKPOINT_NONE)
        return GTPhoneError(playerid, "Dang co checkpoint. Hay hoan thanh hoac dung /cancelcp truoc.");
    SetPlayerCheckpoint(playerid, x, y, z, 4.0);
    PlayerInfo[playerid][pCP] = CHECKPOINT_MISC;
    SendClientMessage(playerid, -1, "[GPS] Da dat diem den.");
    GTPhoneClose(playerid);
    return 1;
}

forward GTPhoneProfile(playerid);
public GTPhoneProfile(playerid)
{
    if (!gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    GTPhoneState(playerid);
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:profileData",
        CEF_INT(PlayerInfo[playerid][pCash]), CEF_INT(PlayerInfo[playerid][pLevel]),
        CEF_INT(PlayerInfo[playerid][pHours]), CEF_INT(PlayerInfo[playerid][pCarLicense]));
    return 1;
}

forward GTPhoneJobs(playerid);
public GTPhoneJobs(playerid)
{
    if (!gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    new job[32], side[32];
    format(job, sizeof job, "%s", GetJobName(PlayerInfo[playerid][pJob]));
    format(side, sizeof side, "%s", GetJobName(PlayerInfo[playerid][pSecondJob]));
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:jobData", CEF_STR(job), CEF_STR(side),
        CEF_BOOL(PlayerHasJob(playerid, JOB_PIZZAMAN)), CEF_INT(PlayerInfo[playerid][pPizzaTime]),
        CEF_BOOL(PlayerInfo[playerid][pCP] == CHECKPOINT_PIZZA), CEF_INT(PlayerInfo[playerid][pPaycheck]));
    return 1;
}

forward GTPhonePizza(playerid, action);
public GTPhonePizza(playerid, action)
{
    if (!GTPhoneAction(playerid)) return 1;
    if (action == 0)
        return GTPhoneMarkLocation(playerid, jobLocations[JOB_PIZZAMAN][jobX],
            jobLocations[JOB_PIZZAMAN][jobY], jobLocations[JOB_PIZZAMAN][jobZ]);
    if (action != 1 || !PlayerHasJob(playerid, JOB_PIZZAMAN)) return 1;
    cmd_laybanh(playerid, "");
    if (PlayerInfo[playerid][pCP] == CHECKPOINT_PIZZA) GTPhoneClose(playerid);
    else GTPhoneJobs(playerid);
    return 1;
}

stock bool:GTPhoneOwnsVehicle(playerid, vehicleid, databaseID)
{
    return vehicleid > 0 && vehicleid < MAX_VEHICLES && IsValidVehicle(vehicleid) &&
        databaseID > 0 && VehicleInfo[vehicleid][vID] == databaseID &&
        PlayerInfo[playerid][pID] > 0 && VehicleInfo[vehicleid][vOwnerID] == PlayerInfo[playerid][pID];
}

forward GTPhoneVehicles(playerid);
public GTPhoneVehicles(playerid)
{
    if (!gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    new uid = PlayerInfo[playerid][pID], query[180];
    mysql_format(connectionID, query, sizeof query,
        "SELECT id,modelid,plate,impounded FROM vehicles WHERE ownerid=%d ORDER BY id LIMIT 100", uid);
    mysql_tquery(connectionID, query, "GTPhoneVehiclesLoaded", "iii", playerid, uid, gtPhoneQueryToken[playerid]);
    return 1;
}

forward GTPhoneVehiclesLoaded(playerid, uid, token);
public GTPhoneVehiclesLoaded(playerid, uid, token)
{
    if (!GTPhoneSession(playerid, uid, token) || !gtPhoneOpen[playerid]) return 1;
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:vehiclesClear");
    new count = GTPhoneRowCount(), plate[32];
    for (new row; row < count; row++)
    {
        new db = cache_get_field_content_int(row, "id");
        new model = cache_get_field_content_int(row, "modelid");
        if (model < 400 || model >= 400 + sizeof vehicleNames) continue;
        new impounded = cache_get_field_content_int(row, "impounded"), id = GetVehicleLinkedID(db);
        cache_get_field_content(row, "plate", plate, connectionID, sizeof plate);
        if (!GTPhoneOwnsVehicle(playerid, id, db)) id = 0;
        new fuel = -1;
        if (id > 0) fuel = vehicleFuel[id];
        CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:vehicleItem", CEF_INT(id), CEF_INT(db),
            CEF_STR(vehicleNames[model - 400]), CEF_STR(plate), CEF_INT(fuel),
            CEF_BOOL(id > 0 && GetPlayerVehicleID(playerid) == id && GetPlayerState(playerid) == PLAYER_STATE_DRIVER),
            CEF_INT(impounded));
    }
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:vehiclesDone");
    return 1;
}

forward GTPhoneVehicleStorage(playerid, db, retrieve);
public GTPhoneVehicleStorage(playerid, db, retrieve)
{
    if (!GTPhoneAction(playerid) || db < 1 || (retrieve != 0 && retrieve != 1)) return 1;
    new uid = PlayerInfo[playerid][pID], query[180];
    mysql_format(connectionID, query, sizeof query,
        "SELECT * FROM vehicles WHERE ownerid=%d AND id=%d LIMIT 1", uid, db);
    mysql_tquery(connectionID, query, "GTPhoneVehicleStorageLoaded", "iiii", playerid, uid, gtPhoneQueryToken[playerid], retrieve);
    return 1;
}

forward GTPhoneVehicleStorageLoaded(playerid, uid, token, retrieve);
public GTPhoneVehicleStorageLoaded(playerid, uid, token, retrieve)
{
    if (!GTPhoneSession(playerid, uid, token) || !gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    if (!GTPhoneRowCount() || cache_get_field_content_int(0, "impounded"))
        return GTPhoneError(playerid, "Xe khong kha dung hoac dang bi tam giu.");
    new db = cache_get_field_content_int(0, "id"), id = GetVehicleLinkedID(db);
    if (retrieve)
    {
        if (id != INVALID_VEHICLE_ID) return GTPhoneError(playerid, "Xe da duoc lay ra.");
        OnPlayerSpawnVehicle(playerid, false);
    }
    else
    {
        if (!GTPhoneOwnsVehicle(playerid, id, db)) return GTPhoneError(playerid, "Xe khong con kha dung.");
        OnPlayerUseCarStorage(playerid);
    }
    GTPhoneVehicles(playerid);
    return 1;
}

forward GTPhoneVehicleLocate(playerid, vehicleid, databaseID);
public GTPhoneVehicleLocate(playerid, vehicleid, databaseID)
{
    if (!GTPhoneAction(playerid)) return 1;
    if (!GTPhoneOwnsVehicle(playerid, vehicleid, databaseID)) return GTPhoneError(playerid, "Xe khong con kha dung.");
    if (VehicleInfo[vehicleid][vInterior] || GetVehicleVirtualWorld(vehicleid))
        return GTPhoneError(playerid, "Xe dang o noi that hoac the gioi rieng.");
    new Float:x, Float:y, Float:z;
    GetVehiclePos(vehicleid, x, y, z);
    return GTPhoneMarkLocation(playerid, x, y, z);
}

forward GTPhoneVehiclePark(playerid, vehicleid, databaseID);
public GTPhoneVehiclePark(playerid, vehicleid, databaseID)
{
    if (!GTPhoneAction(playerid)) return 1;
    if (!GTPhoneOwnsVehicle(playerid, vehicleid, databaseID) ||
        GetPlayerVehicleID(playerid) != vehicleid || GetPlayerState(playerid) != PLAYER_STATE_DRIVER)
        return GTPhoneError(playerid, "Ban can dang lai xe cua minh.");
    GTPhoneClose(playerid);
    return cmd_dauxe(playerid, "");
}

forward GTPhoneSendPosition(playerid, number);
public GTPhoneSendPosition(playerid, number)
{
    if (GetPlayerInterior(playerid) || GetPlayerVirtualWorld(playerid))
        return GTPhoneError(playerid, "Chi gui vi tri khi dang o ben ngoai.");
    return GTPhoneSendMessage(playerid, number, "", true);
}

stock GTPhoneSendMessage(playerid, number, const message[], bool:position)
{
    if (!GTPhoneAction(playerid)) return 1;
    new ownNumber = PlayerInfo[playerid][pPhone], uid = PlayerInfo[playerid][pID], query[1050];
    if (number <= 0 || number == ownNumber) return GTPhoneError(playerid, "So dien thoai khong hop le.");
    new Float:x, Float:y, Float:z;
    if (position) GetPlayerPos(playerid, x, y, z);
    mysql_format(connectionID, query, sizeof query,
        "INSERT INTO gt_phone_messages(sender_uid,recipient_uid,sender_number,recipient_number,body,has_position,x,y,z) SELECT %d,uid,%d,phone,'%e',%d,%f,%f,%f FROM users WHERE phone=%d AND uid<>%d AND COALESCE(togglephone,0)=0 AND COALESCE(jailtype,0)=0 ORDER BY uid LIMIT 1",
        uid, ownNumber, message, _:position, x, y, z, number, uid);
    if (!mysql_tquery(connectionID, query, "GTPhoneAfterMessage", "iiii",
        playerid, uid, gtPhoneQueryToken[playerid], number)) return GTPhoneError(playerid, "Khong the gui tin nhan.");
    return 1;
}

forward GTPhoneAfterMessage(playerid, uid, token, number);
public GTPhoneAfterMessage(playerid, uid, token, number)
{
    if (cache_affected_rows() != 1)
    {
        if (GTPhoneSession(playerid, uid, token)) GTPhoneError(playerid, "So nay khong nhan duoc tin nhan.");
        return 1;
    }
    if (GTPhoneSession(playerid, uid, token) && gtPhoneOpen[playerid])
    {
        GTPhoneNotice(playerid, "Da gui tin nhan.");
        GTPhoneHistory(playerid);
    }
    for (new target; target < MAX_PLAYERS; target++)
    {
        if (!IsPlayerConnected(target) || !PlayerInfo[target][pLogged] || PlayerInfo[target][pPhone] != number) continue;
        if (!PlayerInfo[target][pTogglePhone]) GTPhoneAlert(target, "Tin nhan moi", "Mo /dienthoai de xem.");
        if (gtPhoneOpen[target]) GTPhoneHistory(target);
        break;
    }
    return 1;
}

forward GTPhoneWaypoint(playerid, id);
public GTPhoneWaypoint(playerid, id)
{
    if (!GTPhoneAction(playerid) || id <= 0) return 1;
    new uid = PlayerInfo[playerid][pID], query[240];
    mysql_format(connectionID, query, sizeof query,
        "SELECT x,y,z FROM gt_phone_messages WHERE id=%d AND has_position=1 AND (sender_uid=%d OR recipient_uid=%d) LIMIT 1",
        id, uid, uid);
    mysql_tquery(connectionID, query, "GTPhoneWaypointLoaded", "iii", playerid, uid, gtPhoneQueryToken[playerid]);
    return 1;
}

forward GTPhoneWaypointLoaded(playerid, uid, token);
public GTPhoneWaypointLoaded(playerid, uid, token)
{
    if (!GTPhoneSession(playerid, uid, token) || !gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    if (!GTPhoneRowCount()) return GTPhoneError(playerid, "Khong tim thay vi tri.");
    return GTPhoneMarkLocation(playerid, cache_get_field_content_float(0, "x"),
        cache_get_field_content_float(0, "y"), cache_get_field_content_float(0, "z"));
}

forward GTPhoneCallState(playerid);
public GTPhoneCallState(playerid)
{
    if (!gtPhoneCreated[playerid] || !PlayerInfo[playerid][pLogged]) return 1;
    new peer = PlayerInfo[playerid][pCallLine], stage = PlayerInfo[playerid][pCallStage], number;
    if (peer >= 0 && peer < MAX_PLAYERS && IsPlayerConnected(peer)) number = PlayerInfo[peer][pPhone];
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:callState", CEF_INT(peer == INVALID_PLAYER_ID ? -1 : stage), CEF_INT(number));
    if (stage == 1 && number > 0 && !gtPhoneOpen[playerid]) GTPhoneAlert(playerid, "Cuoc goi den", "Dung /pickup de nghe hoac /hangup de tu choi.");
    return 1;
}

stock GTPhoneAlert(playerid, const title[], const body[])
{
    if (!gtPhoneCreated[playerid]) return SendClientMessage(playerid, -1, body);
    CEF_SetBrowserVisible(playerid, GT_PHONE_BROWSER, true);
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:alert", CEF_STR(title), CEF_STR(body));
    SetTimerEx("GTPhoneHideAlert", 6500, false, "ii", playerid, ++gtPhoneAlertToken[playerid]);
    return 1;
}

forward GTPhoneHideAlert(playerid, token);
public GTPhoneHideAlert(playerid, token)
{
    if (!IsPlayerConnected(playerid) || !gtPhoneCreated[playerid] || gtPhoneAlertToken[playerid] != token) return 1;
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "phone:alertClear");
    if (!gtPhoneOpen[playerid]) CEF_SetBrowserVisible(playerid, GT_PHONE_BROWSER, false);
    return 1;
}

forward GTPhoneLike(playerid, post);
public GTPhoneLike(playerid, post)
{
    if (!GTPhoneAction(playerid) || post <= 0) return 1;
    new query[240];
    mysql_format(connectionID, query, sizeof query,
        "INSERT IGNORE INTO gt_iphone_likes(post_id,user_uid) SELECT id,%d FROM gt_iphone_posts WHERE id=%d", PlayerInfo[playerid][pID], post);
    mysql_tquery(connectionID, query, "GTPhoneSocialChanged", "iiii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid], 0);
    return 1;
}

forward GTPhoneComments(playerid, post);
public GTPhoneComments(playerid, post)
{
    if (post <= 0 || !gtPhoneOpen[playerid] || !GTPhoneAllowed(playerid)) return 1;
    new query[220];
    mysql_format(connectionID, query, sizeof query,
        "SELECT author,body FROM gt_iphone_comments WHERE post_id=%d ORDER BY id DESC LIMIT 25", post);
    mysql_tquery(connectionID, query, "GTPhoneCommentsLoaded", "iiii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid], post);
    return 1;
}

forward GTPhoneCommentsLoaded(playerid, uid, token, post);
public GTPhoneCommentsLoaded(playerid, uid, token, post)
{
    if (!GTPhoneSession(playerid, uid, token) || !gtPhoneOpen[playerid]) return 1;
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:commentsClear", CEF_INT(post));
    new rows = GTPhoneRowCount(), author[25], body[241];
    for (new i = rows - 1; i >= 0; i--)
    {
        cache_get_field_content(i, "author", author, connectionID, sizeof author);
        cache_get_field_content(i, "body", body, connectionID, sizeof body);
        CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:commentItem", CEF_INT(post), CEF_STR(author), CEF_STR(body));
    }
    CEF_EmitEvent(playerid, GT_PHONE_BROWSER, "iphone:commentsDone", CEF_INT(post));
    return 1;
}

forward GTPhoneComment(playerid, post, const body[]);
public GTPhoneComment(playerid, post, const body[])
{
    if (!GTPhoneAction(playerid) || post <= 0) return 1;
    if (!strlen(body) || strlen(body) > 240) return GTPhoneError(playerid, "Binh luan tu 1 den 240 byte.");
    new query[800];
    mysql_format(connectionID, query, sizeof query,
        "INSERT INTO gt_iphone_comments(post_id,author_uid,author,body) SELECT id,%d,'%e','%e' FROM gt_iphone_posts WHERE id=%d",
        PlayerInfo[playerid][pID], GetPlayerNameEx(playerid), body, post);
    mysql_tquery(connectionID, query, "GTPhoneSocialChanged", "iiii", playerid, PlayerInfo[playerid][pID], gtPhoneQueryToken[playerid], post);
    return 1;
}

forward GTPhoneSocialChanged(playerid, uid, token, post);
public GTPhoneSocialChanged(playerid, uid, token, post)
{
    if (!GTPhoneSession(playerid, uid, token) || !gtPhoneOpen[playerid]) return 1;
    if (post > 0)
    {
        if (cache_affected_rows() != 1) return GTPhoneError(playerid, "Khong luu duoc binh luan.");
        return GTPhoneComments(playerid, post);
    }
    return GTIPhoneFeed(playerid);
}
