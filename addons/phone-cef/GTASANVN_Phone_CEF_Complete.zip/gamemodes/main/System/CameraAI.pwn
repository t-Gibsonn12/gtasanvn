#include <YSI\y_hooks>
#include <a_samp>
#include <a_mysql>
#include <foreach>
#include <ZCMD>

#define MAX_CAMERAS 5

new CameraObjects[MAX_CAMERAS];

stock CamerAIONOPEN(){
	CameraObjects[0] = CreateDynamicObject(1622, -94.516387, -1161.907470, 6.445199, 0.000000, 0.000000, -27.300003, -1, -1, -1, 300.00, 300.00); 
	CameraObjects[1] = CreateDynamicObject(2921, 1941.772460, -1779.657836, 16.853952, 0.000000, -19.800001, -99.999954, -1, -1, -1, 300.00, 300.00); 
	CameraObjects[2] = CreateDynamicObject(2921, 2104.731201, -1791.676757, 15.926755, 4.499987, 0.000000, 38.800025, -1, -1, -1, 300.00, 300.00); 
	CameraObjects[3] = CreateDynamicObject(2921, 2038.737182, -1407.301269, 21.308876, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00);  
	CameraObjects[4] = CreateDynamicObject(2921, 1555.171264, -1678.616577, 18.863283, -16.299997, 0.000000, -17.699998, -1, -1, -1, 300.00, 300.00); 

	return 1;
}

/*hook OnGameMI(playerid){
	ThuattoanPoint(playerid);
	return 1;
}*/
forward OnPlayerInCamera(playerid);
public OnPlayerInCamera(playerid)
{
    if(IsPlayerInRangeOfPoint(playerid, 10.0, -94.516387, -1161.907470, 6.445199) ||IsPlayerInRangeOfPoint(playerid, 10.0, 1941.772460, -1779.657836, 16.853952) ||IsPlayerInRangeOfPoint(playerid, 10.0, 2104.731201, -1791.676757, 15.926755) ||IsPlayerInRangeOfPoint(playerid, 10.0, 2038.737182, -1407.301269, 21.308876) || IsPlayerInRangeOfPoint(playerid, 10.0, 1555.171264, -1678.616577, 18.863283)){
    	/*new string[128];
        format(string, sizeof(string),"He Thong CameraAI:Da quyet duoc thong tin %s!", GetPlayerName(playerid));
        SendClientMessageToAll(COLOR_RED,string);*/
        SendClientMessageToAll(COLOR_RED, "He Thong CameraAI:Da quyet duoc thong tin !");
    }
    return 1;
}

