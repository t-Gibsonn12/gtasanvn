#include <YSI\y_hooks>
#include <a_samp>
#include <a_mysql>
#include <foreach>
#include <ZCMD>

new PlayerText:KeycarsTD[MAX_PLAYERS][15];

hook OnPlayerDisconnect(playerid){
	DeletePVar(playerid,"KeycarsOpen");
	DeletePVar(playerid,"KeycarsClose");
	return 1;
}

CMD:tatkeycars(playerid,params[]){
	if(GetPVarInt(playerid,"KeycarsClose") == 1){
		HideKeycarspart1TD(playerid);
		HideKeycarspart2TD(playerid);
		CancelSelectTextDraw(playerid);
	}
	return 1;
}

CMD:chiakhoaxe(playerid,params[]){
 	if(GetPVarInt(playerid,"KeycarsOpen") == 0){
		ShowKeycarspart1TD(playerid);
		SelectTextDraw(playerid, 0xFF4040AA);
		SetPVarInt(playerid, "KeycarsOpen", 1);
	}else{
 		SCM(playerid,COLOR_RED,"He Thong Loi: Ban dang su dung chia khoa xe roi!");
 	}
	return 1;
}

/*hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys){
	new chiecxegannhat = GetClosestCar(vehicleid);
	if(IsPlayerInAnyVehicle(playerid,chiecxegannhat,5.0)){
		if(newkeys == KEY_YES){
			if(GetPVarInt(playerid,"KeycarsOpen") == 0){
			ShowKeycarspart1TD(playerid);
			SelectTextDraw(playerid, 0xFF4040AA);
			SetPVarInt(playerid, "KeycarsOpen", 1);
		}else{
				SCM(playerid,COLOR_RED,"He Thong Loi: Ban dang su dung chia khoa xe roi!");
			}
		}
	}else{
		SCM(playerid,COLOR_RED,"He Thong Loi: ban khong dung gan chiec xe nao ca!");
	}
	return 1;
}*/

stock Keycars_OnPlayerClickPlayerTD(playerid,PlayerText:playertextid){
	if(playertextid == KeycarsTD[playerid][7]){
		HideKeycarspart1TD(playerid);
		ShowKeycarspart2TD(playerid);
	}
	return 1;
}

stock ShowKeycarspart1TD(playerid){
	KeycarsTD[playerid][0] = CreatePlayerTextDraw(playerid, 187.225494, 21.416664, "mdl-2032:main");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][0], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][0], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][0], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][0], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][0], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][0], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][0], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][0], 0);

	KeycarsTD[playerid][2] = CreatePlayerTextDraw(playerid, 107.939857, 101.033340, "mdl-2019:789s");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][2], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][2], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][2], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][2], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][2], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][2], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][2], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][2], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][2], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][2], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][2], true);


	KeycarsTD[playerid][4] = CreatePlayerTextDraw(playerid, 219.333084, 30.666696, "mdl-2020:azzz");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][4], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][4], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][4], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][4], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][4], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][4], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][4], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][4], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][4], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][4], true);

	KeycarsTD[playerid][5] = CreatePlayerTextDraw(playerid, 190.068099, 127.283370, "mdl-2023:dfbdfb");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][5], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][5], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][5], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][5], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][5], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][5], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][5], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][5], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][5], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][5], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][5], true);

	KeycarsTD[playerid][6] = CreatePlayerTextDraw(playerid, 128.417739, 125.533355, "mdl-2024:fsdfsd");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][6], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][6], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][6], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][6], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][6], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][6], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][6], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][6], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][6], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][6], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][6], true);

	KeycarsTD[playerid][7] = CreatePlayerTextDraw(playerid, 99.175010, 38.399993, "mdl-2026:mmhffgh");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][7], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][7], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][7], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][7], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][7], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][7], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][7], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][7], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][7], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][7], 0);

	KeycarsTD[playerid][9] = CreatePlayerTextDraw(playerid, 81.839721, 46.200042, "mdl-2028:oooi");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][9], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][9], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][9], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][9], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][9], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][9], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][9], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][9], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][9], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][9], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][9], true);

	KeycarsTD[playerid][10] = CreatePlayerTextDraw(playerid, 129.628890, 16.383365, "mdl-2029:sss");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][10], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][10], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][10], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][10], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][10], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][10], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][10], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][10], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][10], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][10], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][10], true);

	KeycarsTD[playerid][11] = CreatePlayerTextDraw(playerid, 202.307067, 89.583381, "mdl-2030:vvdsd");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][11], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][11], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][11], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][11], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][11], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][11], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][11], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][11], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][11], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][11], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][11], true);

	PlayerTextDrawShow(playerid, KeycarsTD[playerid][0]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][2]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][4]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][5]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][6]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][7]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][9]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][10]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][11]);
	return 1;
}

stock HideKeycarspart1TD(playerid){
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][0]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][2]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][4]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][5]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][6]);
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][7]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][9]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][10]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][11]);
	return 1;
}

stock ShowKeycarspart2TD(playerid){
	KeycarsTD[playerid][1] = CreatePlayerTextDraw(playerid, 103.713897, 13.099999, "mdl-2031:cc");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][1], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][1], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][1], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][1], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][1], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][1], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][1], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][1], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][1], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][1], 0);

	KeycarsTD[playerid][3] = CreatePlayerTextDraw(playerid, 59.682182, 147.700057, "mdl-2021:cccasas");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][3], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][3], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][3], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][3], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][3], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][3], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][3], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][3], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][3], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][3], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][3], true);

	KeycarsTD[playerid][8] = CreatePlayerTextDraw(playerid, 39.535774, 87.033401, "mdl-2021:cccasas");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][8], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][8], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][8], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][8], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][8], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][8], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][8], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][8], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][8], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][8], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][8], true);

	KeycarsTD[playerid][12] = CreatePlayerTextDraw(playerid, 128.902862, 70.066680, "mdl-2025:hhhh");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][12], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][12], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][12], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][12], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][12], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][12], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][12], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][12], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][12], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][12], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][12], true);

	KeycarsTD[playerid][13] = CreatePlayerTextDraw(playerid, 62.161819, 4.200056, "mdl-2027:nnn");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][13], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][13], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][13], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][13], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][13], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][13], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][13], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][13], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][13], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][13], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][13], true);

	KeycarsTD[playerid][14] = CreatePlayerTextDraw(playerid, 124.475128, 18.783388, "mdl-2018:112");
	PlayerTextDrawLetterSize(playerid, KeycarsTD[playerid][14], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, KeycarsTD[playerid][14], 311.000000, 334.000000);
	PlayerTextDrawAlignment(playerid, KeycarsTD[playerid][14], 1);
	PlayerTextDrawColor(playerid, KeycarsTD[playerid][14], -1);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][14], 0);
	PlayerTextDrawSetOutline(playerid, KeycarsTD[playerid][14], 0);
	PlayerTextDrawBackgroundColor(playerid, KeycarsTD[playerid][14], 255);
	PlayerTextDrawFont(playerid, KeycarsTD[playerid][14], 4);
	PlayerTextDrawSetProportional(playerid, KeycarsTD[playerid][14], 0);
	PlayerTextDrawSetShadow(playerid, KeycarsTD[playerid][14], 0);
	PlayerTextDrawSetSelectable(playerid, KeycarsTD[playerid][14], true);

	PlayerTextDrawShow(playerid, KeycarsTD[playerid][1]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][3]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][8]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][12]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][13]);
	PlayerTextDrawShow(playerid, KeycarsTD[playerid][14]);
	return 1;
}

stock HideKeycarspart2TD(playerid){
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][1]);
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][3]);
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][8]);
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][12]);
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][13]);
	PlayerTextDrawHide(playerid, KeycarsTD[playerid][14]);
	return 1;
}