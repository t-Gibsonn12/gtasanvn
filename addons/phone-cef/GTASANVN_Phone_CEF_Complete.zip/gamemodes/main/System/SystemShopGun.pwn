//-----------------Include-----------------//
#include <YSI\y_hooks>
//-----------------Define-----------------//
#define     DIALOG_M416  1
#define     DIALOG_AK47  2
#define     DIALOG_MP5  3
#define     DIALOG_DE  4
#define     DIALOG_  5

//-----------------Enum-----------------//

//-----------------New-----------------//
new NPCSHOP;
//-----------------Variables-----------------//
new PlayerText:ShopgunTD[MAX_PLAYERS][23];



//-----------------Hooks-----------------//
hook OnGameModeInit(playerid){
    NPCSHOP = CreateActor(28, -1980.8370,145.2401,27.6875,91.0850);
    CreateDynamic3DTextLabel("Hiep Den", COLOR_YELLOW, -1980.8370,145.2401,27.68750+1, 20.0);
    //ApplyActorAnimation(npcshop,"DEALER", "crossarms", 4.1, 0, 0, 0, 0, 0);
    return 1;
}

hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys) {
    if(newkeys ==  KEY_YES)
    {
        cmd_buygun(playerid, "\1");
    } 
    return 1;
}

hook OnPlayerConnect(playerid) 
{

    return 1;
}

hook OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]){
    if(dialogid == DIALOG_SHOPGUN)
    {
        if(response)
        {
            switch(listitem)
            {
                case 0:{
                    PlayerInfo[playerid][pCash] -= 2300000;
                    GivePlayerWeapon(playerid, 356, 1);
                    PlayerInfo[playerid][pGuns] = 356;
                }
                case 1:{
                    PlayerInfo[playerid][pCash] -= 2300000;
                    GivePlayerWeapon(playerid, 355, 1);
                    PlayerInfo[playerid][pGuns] = 355;
                }case 2:{
                    PlayerInfo[playerid][pCash] -= 1500000;
                    GivePlayerWeapon(playerid, 353, 1);
                    PlayerInfo[playerid][pGuns] = 353;
                }case 3:{
                    PlayerInfo[playerid][pCash] -= 1000000;
                    GivePlayerWeapon(playerid, 348, 1);
                    PlayerInfo[playerid][pGuns] = 348;
                }
                case 4:{
                    SendClientMessage(playerid, COLOR_RED,"He Thong: ShopGun dang nhap mat hang ve vui long cho!");
                }
            }
        }
        return 1;
    }
    return 0;
}
//-----------------Stocks-----------------//

stock ShowshopgunTD(playerid){
    ShopgunTD[playerid][0] = CreatePlayerTextDraw(playerid, 93.689697, 96.083351, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][0], 0.000000, 24.055635);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][0], 402.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][0], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][0], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][0], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][0], -2139062017);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][0], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][0], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][0], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][0], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][0], 0);

    ShopgunTD[playerid][1] = CreatePlayerTextDraw(playerid, 93.689697, 96.083351, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][1], 0.000000, 1.379212);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][1], 402.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][1], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][1], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][1], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][1], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][1], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][1], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][1], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][1], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][1], 0);

    ShopgunTD[playerid][2] = CreatePlayerTextDraw(playerid, 253.923828, 92.933357, "SHOP GUN");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][2], 0.400000, 1.600000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][2], 2);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][2], -65281);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][2], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][2], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][2], 2);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][2], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][2], 0);

    ShopgunTD[playerid][3] = CreatePlayerTextDraw(playerid, 96.500747, 115.966659, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][3], 0.000000, 9.484622);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][3], 163.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][3], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][3], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][3], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][3], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][3], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][3], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][3], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][3], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][3], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][3], true);

    ShopgunTD[playerid][4] = CreatePlayerTextDraw(playerid, 449.460662, -19.999969, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][4], 0.000000, 1.332360);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][4], 460.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][4], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][4], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][4], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][4], -16776961);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][4], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][4], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][4], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][4], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][4], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][4], true);

    ShopgunTD[playerid][5] = CreatePlayerTextDraw(playerid, 96.737800, 220.233200, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][5], 0.000000, 9.718887);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][5], 163.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][5], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][5], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][5], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][5], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][5], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][5], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][5], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][5], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][5], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][5], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][5], true);

    ShopgunTD[playerid][6] = CreatePlayerTextDraw(playerid, 96.737800, 220.233200, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][6], 0.000000, 9.718887);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][6], 163.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][6], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][6], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][6], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][6], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][6], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][6], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][6], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][6], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][6], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][6], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][6], true);

    ShopgunTD[playerid][7] = CreatePlayerTextDraw(playerid, 178.260482, 221.483154, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][7], 0.000000, 9.718887);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][7], 241.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][7], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][7], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][7], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][7], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][7], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][7], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][7], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][7], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][7], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][7], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][7], true);

    ShopgunTD[playerid][8] = CreatePlayerTextDraw(playerid, 177.791961, 115.316482, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][8], 0.000000, 9.765739);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][8], 241.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][8], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][8], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][8], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][8], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][8], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][8], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][8], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][8], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][8], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][8], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][8], true);

    ShopgunTD[playerid][9] = CreatePlayerTextDraw(playerid, 256.034973, 115.899833, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][9], 0.000000, 9.765739);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][9], 317.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][9], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][9], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][9], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][9], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][9], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][9], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][9], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][9], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][9], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][9], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][9], true);

    ShopgunTD[playerid][10] = CreatePlayerTextDraw(playerid, 256.503479, 220.899810, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][10], 0.000000, 9.765739);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][10], 318.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][10], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][10], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][10], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][10], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][10], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][10], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][10], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][10], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][10], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][10], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][10], true);

    ShopgunTD[playerid][11] = CreatePlayerTextDraw(playerid, 335.683593, 220.316482, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][11], 0.000000, 9.765739);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][11], 399.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][11], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][11], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][11], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][11], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][11], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][11], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][11], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][11], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][11], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][11], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][11], true);

    ShopgunTD[playerid][12] = CreatePlayerTextDraw(playerid, 336.620697, 115.899787, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][12], 0.000000, 9.765739);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][12], 398.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][12], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][12], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][12], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][12], 255);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][12], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][12], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][12], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][12], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][12], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][12], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][12], true);

    ShopgunTD[playerid][13] = CreatePlayerTextDraw(playerid, 393.895416, 96.083328, "box");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][13], 0.000000, 1.252653);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][13], 402.000000, 0.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][13], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][13], -1);
    PlayerTextDrawUseBox(playerid, ShopgunTD[playerid][13], 1);
    PlayerTextDrawBoxColor(playerid, ShopgunTD[playerid][13], -16776961);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][13], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][13], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][13], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][13], 1);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][13], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][13], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][13], true);

    ShopgunTD[playerid][14] = CreatePlayerTextDraw(playerid, 180.534713, 132.733413, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][14], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][14], 62.000000, 62.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][14], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][14], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][14], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][14], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][14], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][14], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][14], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][14], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][14], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][14], 355);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][14], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][15] = CreatePlayerTextDraw(playerid, 100.417602, 133.316726, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][15], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][15], 62.000000, 62.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][15], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][15], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][15], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][15], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][15], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][15], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][15], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][15], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][15], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][15], 356);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][15], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][16] = CreatePlayerTextDraw(playerid, 254.561065, 137.983459, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][16], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][16], 62.000000, 65.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][16], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][16], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][16], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][16], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][16], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][16], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][16], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][16], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][16], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][16], 353);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][16], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][17] = CreatePlayerTextDraw(playerid, 334.209686, 139.150100, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][17], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][17], 59.000000, 55.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][17], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][17], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][17], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][17], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][17], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][17], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][17], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][17], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][17], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][17], 348);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][17], 155.000000, 160.000000, 50.400001, 0.600000);

    ShopgunTD[playerid][18] = CreatePlayerTextDraw(playerid, 98.543518, 230.733413, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][18], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][18], 62.000000, 62.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][18], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][18], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][18], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][18], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][18], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][18], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][18], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][18], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][18], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][18], 357);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][18], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][19] = CreatePlayerTextDraw(playerid, 180.066192, 234.816772, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][19], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][19], 62.000000, 62.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][19], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][19], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][19], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][19], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][19], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][19], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][19], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][19], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][19], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][19], 358);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][19], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][20] = CreatePlayerTextDraw(playerid, 256.903686, 235.983428, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][20], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][20], 56.000000, 71.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][20], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][20], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][20], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][20], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][20], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][20], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][20], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][20], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][20], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][20], 372);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][20], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][21] = CreatePlayerTextDraw(playerid, 335.615173, 238.316787, "");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][21], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, ShopgunTD[playerid][21], 62.000000, 62.000000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][21], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][21], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][21], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][21], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][21], 255);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][21], 5);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][21], 0);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][21], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][21], true);
    PlayerTextDrawSetPreviewModel(playerid, ShopgunTD[playerid][21], 349);
    PlayerTextDrawSetPreviewRot(playerid, ShopgunTD[playerid][21], 155.000000, 160.000000, 50.400001, 1.000000);

    ShopgunTD[playerid][22] = CreatePlayerTextDraw(playerid, 392.666839, 93.516708, "X");
    PlayerTextDrawLetterSize(playerid, ShopgunTD[playerid][22], 0.400000, 1.600000);
    PlayerTextDrawAlignment(playerid, ShopgunTD[playerid][22], 1);
    PlayerTextDrawColor(playerid, ShopgunTD[playerid][22], -1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][22], 0);
    PlayerTextDrawSetOutline(playerid, ShopgunTD[playerid][22], 0);
    PlayerTextDrawBackgroundColor(playerid, ShopgunTD[playerid][22], -16776961);
    PlayerTextDrawFont(playerid, ShopgunTD[playerid][22], 2);
    PlayerTextDrawSetProportional(playerid, ShopgunTD[playerid][22], 1);
    PlayerTextDrawSetShadow(playerid, ShopgunTD[playerid][22], 0);
    PlayerTextDrawSetSelectable(playerid, ShopgunTD[playerid][22], true);

    PlayerTextDrawShow(playerid, ShopgunTD[playerid][0]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][1]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][2]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][3]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][4]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][5]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][6]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][7]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][8]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][9]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][10]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][11]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][12]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][13]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][14]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][15]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][16]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][17]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][18]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][19]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][20]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][21]);
    PlayerTextDrawShow(playerid, ShopgunTD[playerid][22]);
    return 1;
}

stock HideShopgunTD(playerid){
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][0]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][1]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][2]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][3]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][4]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][5]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][6]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][7]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][8]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][9]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][10]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][11]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][12]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][13]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][14]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][15]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][16]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][17]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][18]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][19]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][20]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][21]);
    PlayerTextDrawHide(playerid, ShopgunTD[playerid][22]);
    
    return 1;
}

stock DIALOG_M416(playerid){
    ShowPlayerDialog(playerid,DIALOG_SHOPGUN,DIALOG_STYLE_LIST,"SHOP GUN", "M416\t$2.300.000\nAK47\t2.300.000\nMP5\t1.500.000\nDE\t1.000.000\nUPDATE\tLoading..." , "Mua Hang" , "Huy" );
    ShowPlayerDialog(playerid, DIALOG_M416, DIALOG_STYLE_MSGBOX, ""SHOP GUN , "Ban da lua chon [M416]\nGia Tien: 2.300.000$\nDo Ben:{0x0000FFFF}Tot{0x0000FFFF}" , "Dong Y" , "Huy Bo" ) ;
    return 1;
}
//-----------------Command-----------------//
 CMD:buygun(playerid,params[]){
    if(IsPlayerInRangeOfActor(playerid, NPCSHOP, 5.0)){
        ShowshopgunTD(playerid);
        SelectTextDraw(playerid, 0xFF4040AA);
    }
    return 1;
}

hook OnPlayerClickPlayerTextDraw(playerid, PlayerText:playertextid){
    //OFF TEXTDRAW
    if(playertextid == ShopgunTD[playerid][20])
    {
        HideshopgunTD(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    if(playertextid == ShopgunTD[playerid][31])
    {
        HideshopgunTD(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    if(playertextid == ShopgunTD[playerid][22])
    {
        HideshopgunTD(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    return true;
}



