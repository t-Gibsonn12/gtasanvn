#include <YSI\y_hooks>


new PlayerText:giaynghiavuquansu[MAX_PLAYERS][5];

hook OnGameModeExit(playerid){
	DeletePVar(playerid,"Dangshowchungnhan");
	return 1;
}


stock Showgiaynghiavuquansu(playerid){
	new string[128];
	giaynghiavuquansu[playerid][0] = CreatePlayerTextDraw(playerid, 178.323593, 106.583366, "mdl-2025:giaychungnhan");
	PlayerTextDrawLetterSize(playerid, giaynghiavuquansu[playerid][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, giaynghiavuquansu[playerid][0], 283.000000, 164.000000);
	PlayerTextDrawAlignment(playerid, giaynghiavuquansu[playerid][0], 1);
	PlayerTextDrawColor(playerid, giaynghiavuquansu[playerid][0], -1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][0], 0);
	PlayerTextDrawSetOutline(playerid, giaynghiavuquansu[playerid][0], 0);
	PlayerTextDrawBackgroundColor(playerid, giaynghiavuquansu[playerid][0], 255);
	PlayerTextDrawFont(playerid, giaynghiavuquansu[playerid][0], 4);
	PlayerTextDrawSetProportional(playerid, giaynghiavuquansu[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][0], 0);

	giaynghiavuquansu[playerid][1] = CreatePlayerTextDraw(playerid, 286.820281, 142.633270, "Tyler Pylon");
	PlayerTextDrawLetterSize(playerid, giaynghiavuquansu[playerid][1], 0.223367, 1.460000);
	PlayerTextDrawAlignment(playerid, giaynghiavuquansu[playerid][1], 1);
	PlayerTextDrawColor(playerid, giaynghiavuquansu[playerid][1], -1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][1], 0);
	PlayerTextDrawSetOutline(playerid, giaynghiavuquansu[playerid][1], 0);
	PlayerTextDrawBackgroundColor(playerid, giaynghiavuquansu[playerid][1], 255);
	PlayerTextDrawFont(playerid, giaynghiavuquansu[playerid][1], 2);
	PlayerTextDrawSetProportional(playerid, giaynghiavuquansu[playerid][1], 1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][1], 0);

	giaynghiavuquansu[playerid][2] = CreatePlayerTextDraw(playerid, 341.857818, 160.133239, "20/5/2000");
	PlayerTextDrawLetterSize(playerid, giaynghiavuquansu[playerid][2], 0.223367, 1.460000);
	PlayerTextDrawAlignment(playerid, giaynghiavuquansu[playerid][2], 1);
	PlayerTextDrawColor(playerid, giaynghiavuquansu[playerid][2], -1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][2], 0);
	PlayerTextDrawSetOutline(playerid, giaynghiavuquansu[playerid][2], 0);
	PlayerTextDrawBackgroundColor(playerid, giaynghiavuquansu[playerid][2], 255);
	PlayerTextDrawFont(playerid, giaynghiavuquansu[playerid][2], 2);
	PlayerTextDrawSetProportional(playerid, giaynghiavuquansu[playerid][2], 1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][2], 0);

	giaynghiavuquansu[playerid][3] = CreatePlayerTextDraw(playerid, 342.057830, 179.983261, "Vo Cu");
	PlayerTextDrawLetterSize(playerid, giaynghiavuquansu[playerid][3], 0.223367, 1.460000);
	PlayerTextDrawAlignment(playerid, giaynghiavuquansu[playerid][3], 1);
	PlayerTextDrawColor(playerid, giaynghiavuquansu[playerid][3], -1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][3], 0);
	PlayerTextDrawSetOutline(playerid, giaynghiavuquansu[playerid][3], 0);
	PlayerTextDrawBackgroundColor(playerid, giaynghiavuquansu[playerid][3], 255);
	PlayerTextDrawFont(playerid, giaynghiavuquansu[playerid][3], 2);
	PlayerTextDrawSetProportional(playerid, giaynghiavuquansu[playerid][3], 1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][3], 0);

	giaynghiavuquansu[playerid][4] = CreatePlayerTextDraw(playerid, 313.946502, 198.349899, "22/10/2000");
	PlayerTextDrawLetterSize(playerid, giaynghiavuquansu[playerid][4], 0.223367, 1.460000);
	PlayerTextDrawAlignment(playerid, giaynghiavuquansu[playerid][4], 1);
	PlayerTextDrawColor(playerid, giaynghiavuquansu[playerid][4], -1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][4], 0);
	PlayerTextDrawSetOutline(playerid, giaynghiavuquansu[playerid][4], 0);
	PlayerTextDrawBackgroundColor(playerid, giaynghiavuquansu[playerid][4], 255);
	PlayerTextDrawFont(playerid, giaynghiavuquansu[playerid][4], 2);
	PlayerTextDrawSetProportional(playerid, giaynghiavuquansu[playerid][4], 1);
	PlayerTextDrawSetShadow(playerid, giaynghiavuquansu[playerid][4], 0);

	//Ten
	format(string, sizeof(string), "%s",GetRPName(playerid), string);
    PlayerTextDrawSetString(playerid, giaynghiavuquansu[playerid][1] , string);
    //Ngay thang nam sinh
    format(string, sizeof(string), "%i/%i/%i",PlayerInfo[playerid][pBirthYear], PlayerInfo[playerid][pBirthMonth], PlayerInfo[playerid][pBirthDay], string);
    PlayerTextDrawSetString(playerid, giaynghiavuquansu[playerid][2] , string);

	PlayerTextDrawShow(playerid, giaynghiavuquansu[playerid][0]);
	PlayerTextDrawShow(playerid, giaynghiavuquansu[playerid][1]);
	PlayerTextDrawShow(playerid, giaynghiavuquansu[playerid][2]);
	PlayerTextDrawShow(playerid, giaynghiavuquansu[playerid][3]);
	PlayerTextDrawShow(playerid, giaynghiavuquansu[playerid][4]);
	return 1;
}

stock Hidegiaynghiavuquansu(playerid){
	PlayerTextDrawHide(playerid, giaynghiavuquansu[playerid][0]);
	PlayerTextDrawHide(playerid, giaynghiavuquansu[playerid][1]);
	PlayerTextDrawHide(playerid, giaynghiavuquansu[playerid][2]);
	PlayerTextDrawHide(playerid, giaynghiavuquansu[playerid][3]);
	PlayerTextDrawHide(playerid, giaynghiavuquansu[playerid][4]);
	return 1;
}

CMD:chamcong(playerid,params[]){
	if(PlayerInfo[playerid][pChihuy] == 1){
		new targetid, amount;
		if(sscanf(params, "ui", targetid, amount))
		{
		    return SCM(playerid, COLOR_SYNTAX, "Su dung: /chamcong [playerid] [amount]");
		}
		if(!IsPlayerConnected(targetid))
		{
		    return SCM(playerid, COLOR_SYNTAX, "Khong the su dung lenh nay o thoi diem hien tai.");
		}
		if(amount > 0 || amount < 2)
		{
			PlayerInfo[targetid][pChamcong] += 1;
			SM(targetid, COLOR_AQUA, "He Thong: %s Da duoc cham cong boi %s", GetRPName(targetid), GetRPName(playerid));
			SAM(COLOR_LIGHTRED, "{FF0000}CanhBao Adm:{99FF66} %s da duoc cham cong nghia vu quan su boi %s .", GetRPName(targetid), GetRPName(playerid));
			Log_Write("log_admin", "%s (uid: %i) cham cong cho %s (uid: %i)", GetPlayerNameEx(playerid), PlayerInfo[playerid][pID], GetPlayerNameEx(targetid), PlayerInfo[targetid][pID]);
		}else{
		 SCM(playerid, COLOR_SYNTAX, "He Thong Loi: Ban khong the cham 2 cong trong 1 ngay.");
		}
	}else{
		SCM(playerid,COLOR_RED,"He Thong Loi: Ban khong the dung lenh nay!");
	}
	return 1;
}

/*CMD:traobangnghiavu(playerid){
	if(PlayerInfo[targetid][pChamcong] == 7){
		if(PlayerInfo[targetid][pBangnghiavuquansu] == 1){
			SCM(playerid,COLOR_RED,"He Thong Loi: Ban da co giay chung nhan nghia vu quan su roi!");
		}else{
			PlayerInfo[targetid][pBangnghiavuquansu] == 1;
			SCM(playerid,COLOR_SYNTAX,"He Thong: Ban da duoc cap giay chung nhan nghia vu quan su");
		}
		return 1;
	}
	return 1;
}*/

CMD:showgiaychungnhan(playerid,params[]){
	if(GetPVarInt(playerid,"Dangshowchungnhan") == 0){
		Showgiaynghiavuquansu(playerid);
		SetPVarInt(playerid,"Dangshowchungnhan",1);
	}else{
		SCM(playerid,COLOR_RED,"He Thong Loi: Ban dang xem giay chung nhan nghia vu roi!");
	}
	return 1;
}

CMD:thuhoigiaychungnhan(playerid,params[]){
	if(GetPVarInt(playerid,"Dangshowchungnhan") == 1){
		Hidegiaynghiavuquansu(playerid);
		SetPVarInt(playerid,"Dangshowchungnhan",0);
	}else{
		SCM(playerid,COLOR_RED,"He Thong Loi: Ban khong xem giay chung nhan nao ca!");
	}
	return 1;
}