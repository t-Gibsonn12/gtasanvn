//-------------INCLUDE-------------//
#include <YSI_Coding\y_hooks>
#include <a_samp>
#include <a_mysql>
#include <foreach>
#include <ZCMD>

//-------------DEFINE-------------//
#define MYSQL_IP                        "127.0.0.1"
#define MYSQL_USERNAME                  "root"
#define MYSQL_DATABASE                  "samp"
#define MYSQL_PASS                      "INSERT_PASSWORD_HERE"

#define MAX_FRIENDS 100

#define	THREAD_ACCOUNT_LOADDATA            	(1)
#define THREAD_SAVE_ACCOUNT_1         		(2)
#define THREAD_NO_RESULT			  		(3)

#define ADD_FRIEND_THREAD					(50)
#define FINAL_FRIEND_THREAD					(51)
#define REQUEST_FRIEND_THREAD				(52)

#define DIALOG_GOI	(1999)
#define DIALOG_KHANCAP	(2000)
#define DIALOG_GOITHUONG	(2001)
#define DIALOG_NGANHANG	(2002)
#define DIALOG_INPUTCHUYENTIENTAIKHOAN (2003)
#define DIALOG_INPUTCHUYENTIEN (2004)
#define DIALOG_NAPTIEN (2005)
#define DIALOG_RUTTIEN (2006)
#define DIALOG_SOiphonex (2007)
#define DIALOG_VANBAN (2008)
#define DIALOG_DANHBA (2009)
#define DIALOG_THONGTINDANHBA (2010)
//-------------NEW-------------//
new number;
new targetid;
new amount;
new tienduocchuyen;
new naptien;
new ruttien;
new soiphonex;
new vanban[2080]; 
//-------------ENUM-------------//
new PlayerText:iphonex[MAX_PLAYERS][128];
new PlayerText:banking[MAX_PLAYERS][128];
//-------------COMMAND-------------//
CMD:phone(playerid,params[]){
	if(!PlayerInfo[playerid][pPhone]) return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Ban khong co dien thoai va danh ba nen ban khong the su dung lenh nay");
	if(PlayerInfo[playerid][pTazedTime] > 0 || PlayerInfo[playerid][pInjured] > 0 || PlayerInfo[playerid][pHospital] > 0 || PlayerInfo[playerid][pCuffed] > 0 || PlayerInfo[playerid][pTied] > 0 || PlayerInfo[playerid][pJailTime] > 0){
			SendClientMessage(playerid, COLOR_RED,"He Thong: ban khong the mo dien thoai ngay luc nay!");
	}
	else{
		Showtime(playerid);
		Showphone(playerid);
		SelectTextDraw(playerid, 0xFF4040AA);
	}
	return 1;
}

CMD:hidephone(playerid,params[]){
	Hidetime(playerid);
	Hidephone(playerid);
	Hidephonetinnhan(playerid);
	CancelSelectTextDraw(playerid);
}
//-------------STOCK-------------//
stock Showtime(playerid){
	new
	    string[128],
		date[6];
	gettime(date[3], date[4], date[5]);

	iphonex[playerid][6] = CreatePlayerTextDraw(playerid, 546.944274, 198.250167, "00:00");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][6], 0.125440, 0.975835);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][6], 3);
	PlayerTextDrawColor(playerid, iphonex[playerid][6], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][6], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][6], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][6], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][6], 2);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][6], 1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][6], 0);

	PlayerTextDrawShow(playerid, iphonex[playerid][6]);

	format(string, sizeof(string), "%02d:%02d", string, date[3], date[4], date[5]);
    PlayerTextDrawSetString(playerid, iphonex[playerid][6] , string);
	return 1;
}

stock Hidetime(playerid){
	PlayerTextDrawHide(playerid, iphonex[playerid][6]);
	return 1;
}
stock Showphone(playerid){

	iphonex[playerid][0] = CreatePlayerTextDraw(playerid, 523.989929, 196.416671, "mdl-2019:backgroundphone");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][0], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][0], 105.000000, 237.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][0], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][0], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][0], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][0], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][0], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][0], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][0], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][0], 0);

	iphonex[playerid][1] = CreatePlayerTextDraw(playerid, 514.253234, 185.916641, "mdl-2018:iphone10");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][1], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][1], 125.000000, 262.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][1], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][1], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][1], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][1], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][1], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][1], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][1], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][1], 0);

	iphonex[playerid][2] = CreatePlayerTextDraw(playerid, 563.659545, 244.632995, "mdl-2021:mess");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][2], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][2], 25.000000, 26.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][2], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][2], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][2], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][2], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][2], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][2], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][2], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][2], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][2], true);

	iphonex[playerid][3] = CreatePlayerTextDraw(playerid, 594.566650, 244.682952, "mdl-2022:number");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][3], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][3], 29.000000, 26.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][3], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][3], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][3], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][3], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][3], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][3], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][3], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][3], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][3], true);

	iphonex[playerid][4] = CreatePlayerTextDraw(playerid, 547.407348, 420.466308, "mdl-2024:thanhngang");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][4], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][4], 61.629993, 4.819999);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][4], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][4], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][4], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][4], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][4], true);

	iphonex[playerid][5] = CreatePlayerTextDraw(playerid, 532.388549, 244.600173, "mdl-2020:call");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][5], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][5], 25.000000, 26.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][5], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][5], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][5], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][5], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][5], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][5], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][5], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][5], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][5], true);

	iphonex[playerid][7] = CreatePlayerTextDraw(playerid, 531.830688, 274.233489, "mdl-2023:banking");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][7], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][7], 26.600013, 25.100002);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][7], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][7], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][7], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][7], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][7], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][7], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][7], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][7], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][7], true);


	PlayerTextDrawShow(playerid, iphonex[playerid][0]);
	PlayerTextDrawShow(playerid, iphonex[playerid][1]);
	PlayerTextDrawShow(playerid, iphonex[playerid][2]);
	PlayerTextDrawShow(playerid, iphonex[playerid][3]);
	PlayerTextDrawShow(playerid, iphonex[playerid][4]);
	PlayerTextDrawShow(playerid, iphonex[playerid][5]);
	PlayerTextDrawShow(playerid, iphonex[playerid][7]);

	return 1;
}

stock Hidephone(playerid){
	PlayerTextDrawHide(playerid, iphonex[playerid][0]);
	PlayerTextDrawHide(playerid, iphonex[playerid][1]);
	PlayerTextDrawHide(playerid, iphonex[playerid][2]);
	PlayerTextDrawHide(playerid, iphonex[playerid][3]);
	PlayerTextDrawHide(playerid, iphonex[playerid][4]);
	PlayerTextDrawHide(playerid, iphonex[playerid][5]);
	PlayerTextDrawHide(playerid, iphonex[playerid][7]);
	return 1;
}

stock Showphonetinnhan(playerid){

	iphonex[playerid][8] = CreatePlayerTextDraw(playerid, 514.590637, 186.100006, "mdl-2025:tinnhan");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][8], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][8], 125.000000, 262.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][8], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][8], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][8], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][8], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][8], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][8], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][8], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][8], 0);

	iphonex[playerid][9] = CreatePlayerTextDraw(playerid, 529.720336, 216.133331, "SDT:");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][9], 0.224772, 1.909167);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][9], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][9], 255);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][9], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][9], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][9], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][9], 2);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][9], 1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][9], 0);

	iphonex[playerid][10] = CreatePlayerTextDraw(playerid, 527.865905, 269.333312, "TYLER PYLON:");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][10], 0.189802, 1.687500);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][10], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][10], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][10], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][10], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][10], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][10], 2);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][10], 1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][10], 0);

	iphonex[playerid][11] = CreatePlayerTextDraw(playerid, 536.240478, 239.350082, "OMP: 500D/Tin Nhan");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][11], 0.227584, 1.174165);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][11], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][11], 255);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][11], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][11], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][11], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][11], 1);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][11], 1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][11], 0);

	iphonex[playerid][12] = CreatePlayerTextDraw(playerid, 567.715393, 286.066772, "nhap van ban vao day!");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][12], 0.155092, 0.719165);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][12], 2);
	PlayerTextDrawColor(playerid, iphonex[playerid][12], -1061109505);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][12], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][12], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][12], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][12], 2);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][12], 1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][12], 0);

	iphonex[playerid][13] = CreatePlayerTextDraw(playerid, 555.145507, 215.916610, "0911776022");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][13], 0.224772, 1.909167);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][13], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][13], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][13], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][13], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][13], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][13], 2);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][13], 1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][13], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][13], true);

	iphonex[playerid][14] = CreatePlayerTextDraw(playerid, 608.157653, 387.716552, "mdl-2026:tich");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][14], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][14], 17.000000, 17.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][14], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][14], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][14], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][14], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][14], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][14], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][14], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][14], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][14], true);

	iphonex[playerid][4] = CreatePlayerTextDraw(playerid, 547.407348, 420.466308, "mdl-2024:thanhngang");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][4], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][4], 61.629993, 4.819999);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][4], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][4], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][4], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][4], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][4], true);

	PlayerTextDrawShow(playerid, iphonex[playerid][8]);
	PlayerTextDrawShow(playerid, iphonex[playerid][9]);
	PlayerTextDrawShow(playerid, iphonex[playerid][10]);
	PlayerTextDrawShow(playerid, iphonex[playerid][11]);
	PlayerTextDrawShow(playerid, iphonex[playerid][12]);
	PlayerTextDrawShow(playerid, iphonex[playerid][13]);
	PlayerTextDrawShow(playerid, iphonex[playerid][14]);
	PlayerTextDrawShow(playerid, iphonex[playerid][4]);
}

stock Hidephonetinnhan(playerid){
	PlayerTextDrawHide(playerid, iphonex[playerid][8]);
	PlayerTextDrawHide(playerid, iphonex[playerid][4]);
	PlayerTextDrawHide(playerid, iphonex[playerid][9]);
	PlayerTextDrawHide(playerid, iphonex[playerid][10]);
	PlayerTextDrawHide(playerid, iphonex[playerid][11]);
	PlayerTextDrawHide(playerid, iphonex[playerid][12]);
	PlayerTextDrawHide(playerid, iphonex[playerid][13]);
	PlayerTextDrawHide(playerid, iphonex[playerid][14]);
	return 1;
}


stock Showapploading(playerid){
	iphonex[playerid][15] = CreatePlayerTextDraw(playerid, 513.453430, 186.116653, "mdl-2027:loadingall");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][15], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][15], 125.000000, 262.000000);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][15], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][15], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][15], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][15], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][15], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][15], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][15], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][15], 0);

	PlayerTextDrawShow(playerid, iphonex[playerid][15]);
	return 1;
}

stock Hideapploading(playerid){
	PlayerTextDrawHide(playerid, iphonex[playerid][15]);
	return 1;
}

stock Loadingbanking(playerid){
	banking[playerid][17] = CreatePlayerTextDraw(playerid, 512.884948, 186.499969, "mdl-2029:loadingbanking");
	PlayerTextDrawLetterSize(playerid, banking[playerid][17], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][17], 125.000000, 262.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][17], 1);
	PlayerTextDrawColor(playerid, banking[playerid][17], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][17], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][17], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][17], 255);
	PlayerTextDrawFont(playerid, banking[playerid][17], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][17], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][17], 0);


	PlayerTextDrawShow(playerid, banking[playerid][17]);

	return 1;
}

stock HideLoadingbanking(playerid){
	PlayerTextDrawHide(playerid, banking[playerid][17]);
	return 1;
}

stock Showmainappbanking(playerid){
	new string[128];


	banking[playerid][8] = CreatePlayerTextDraw(playerid, 512.884948, 186.499969, "mdl-2028:mainbanking");
	PlayerTextDrawLetterSize(playerid, banking[playerid][8], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][8], 125.000000, 262.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][8], 1);
	PlayerTextDrawColor(playerid, banking[playerid][8], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][8], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][8], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][8], 255);
	PlayerTextDrawFont(playerid, banking[playerid][8], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][8], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][8], 0);

	iphonex[playerid][4] = CreatePlayerTextDraw(playerid, 547.407348, 420.466308, "mdl-2024:thanhngang");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][4], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][4], 61.629993, 4.819999);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][4], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][4], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][4], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][4], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][4], true);

	banking[playerid][9] = CreatePlayerTextDraw(playerid, 527.372131, 217.416671, "mdl-2030:naptien");
	PlayerTextDrawLetterSize(playerid, banking[playerid][9], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][9], 20.000000, 19.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][9], 1);
	PlayerTextDrawColor(playerid, banking[playerid][9], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][9], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][9], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][9], 255);
	PlayerTextDrawFont(playerid, banking[playerid][9], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][9], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][9], 0);
	PlayerTextDrawSetSelectable(playerid, banking[playerid][9], true);

	banking[playerid][10] = CreatePlayerTextDraw(playerid, 574.587158, 217.233184, "mdl-2031:qrnhantien");
	PlayerTextDrawLetterSize(playerid, banking[playerid][10], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][10], 20.460033, 20.899997);
	PlayerTextDrawAlignment(playerid, banking[playerid][10], 1);
	PlayerTextDrawColor(playerid, banking[playerid][10], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][10], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][10], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][10], 255);
	PlayerTextDrawFont(playerid, banking[playerid][10], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][10], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][10], 0);
	PlayerTextDrawSetSelectable(playerid, banking[playerid][10], true);

	banking[playerid][11] = CreatePlayerTextDraw(playerid, 602.166870, 217.216674, "mdl-2033:quetma");
	PlayerTextDrawLetterSize(playerid, banking[playerid][11], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][11], 20.000000, 19.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][11], 1);
	PlayerTextDrawColor(playerid, banking[playerid][11], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][11], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][11], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][11], 255);
	PlayerTextDrawFont(playerid, banking[playerid][11], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][11], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][11], 0);
	PlayerTextDrawSetSelectable(playerid, banking[playerid][11], true);

	banking[playerid][12] = CreatePlayerTextDraw(playerid, 529.645935, 249.266540, "mdl-2034:eye");
	PlayerTextDrawLetterSize(playerid, banking[playerid][12], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][12], 8.000000, 6.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][12], 1);
	PlayerTextDrawColor(playerid, banking[playerid][12], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][12], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][12], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][12], 255);
	PlayerTextDrawFont(playerid, banking[playerid][12], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][12], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][12], 0);

	banking[playerid][13] = CreatePlayerTextDraw(playerid, 525.829223, 262.933410, "mdl-2035:chuyentien");
	PlayerTextDrawLetterSize(playerid, banking[playerid][13], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][13], 35.000000, 25.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][13], 1);
	PlayerTextDrawColor(playerid, banking[playerid][13], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][13], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][13], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][13], 255);
	PlayerTextDrawFont(playerid, banking[playerid][13], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][13], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][13], 0);
	PlayerTextDrawSetSelectable(playerid, banking[playerid][13], true);

	banking[playerid][14] = CreatePlayerTextDraw(playerid, 562.742248, 263.533447, "mdl-2036:thanhtoan");
	PlayerTextDrawLetterSize(playerid, banking[playerid][14], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][14], 35.000000, 25.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][14], 1);
	PlayerTextDrawColor(playerid, banking[playerid][14], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][14], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][14], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][14], 255);
	PlayerTextDrawFont(playerid, banking[playerid][14], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][14], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][14], 0);
	PlayerTextDrawSetSelectable(playerid, banking[playerid][14], true);

	banking[playerid][15] = CreatePlayerTextDraw(playerid, 551.591796, 217.033416, "mdl-2032:rutien");
	PlayerTextDrawLetterSize(playerid, banking[playerid][15], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][15], 18.759994, 18.929998);
	PlayerTextDrawAlignment(playerid, banking[playerid][15], 1);
	PlayerTextDrawColor(playerid, banking[playerid][15], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][15], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][15], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][15], 255);
	PlayerTextDrawFont(playerid, banking[playerid][15], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][15], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][15], 0);
	PlayerTextDrawSetSelectable(playerid, banking[playerid][15], true);

	banking[playerid][16] = CreatePlayerTextDraw(playerid, 543.495605, 243.683364, "1000000");
	PlayerTextDrawLetterSize(playerid, banking[playerid][16], 0.213060, 1.559165);
	PlayerTextDrawAlignment(playerid, banking[playerid][16], 1);
	PlayerTextDrawColor(playerid, banking[playerid][16], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][16], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][16], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][16], 255);
	PlayerTextDrawFont(playerid, banking[playerid][16], 2);
	PlayerTextDrawSetProportional(playerid, banking[playerid][16], 1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][16], 0);

	PlayerTextDrawShow(playerid, banking[playerid][8]);
	PlayerTextDrawShow(playerid, iphonex[playerid][4]);
	PlayerTextDrawShow(playerid, banking[playerid][9]);
	PlayerTextDrawShow(playerid, banking[playerid][10]);
	PlayerTextDrawShow(playerid, banking[playerid][11]);
	PlayerTextDrawShow(playerid, banking[playerid][12]);
	PlayerTextDrawShow(playerid, banking[playerid][13]);
	PlayerTextDrawShow(playerid, banking[playerid][14]);
	PlayerTextDrawShow(playerid, banking[playerid][15]);
	PlayerTextDrawShow(playerid, banking[playerid][16]);

	format(string, sizeof(string), "%i$",PlayerInfo[playerid][pBank], string);
    PlayerTextDrawSetString(playerid, banking[playerid][16] , string);
	return 1;
}

stock Hidemainappbanking(playerid){
	PlayerTextDrawHide(playerid, banking[playerid][8]);
	PlayerTextDrawHide(playerid, iphonex[playerid][4]);
	PlayerTextDrawHide(playerid, banking[playerid][9]);
	PlayerTextDrawHide(playerid, banking[playerid][10]);
	PlayerTextDrawHide(playerid, banking[playerid][11]);
	PlayerTextDrawHide(playerid, banking[playerid][12]);
	PlayerTextDrawHide(playerid, banking[playerid][13]);
	PlayerTextDrawHide(playerid, banking[playerid][14]);
	PlayerTextDrawHide(playerid, banking[playerid][15]);
	PlayerTextDrawHide(playerid, banking[playerid][16]);
	return 1;
}

stock Showgiaodichthanhcong(playerid){
	new string[128];
	new magiaodich = random(9999999);

	banking[playerid][17] = CreatePlayerTextDraw(playerid, 514.253234, 185.916641, "mdl-2037:giaodichthanhcong");
	PlayerTextDrawLetterSize(playerid, banking[playerid][17], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, banking[playerid][17], 125.000000, 262.000000);
	PlayerTextDrawAlignment(playerid, banking[playerid][17], 1);
	PlayerTextDrawColor(playerid, banking[playerid][17], -1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][17], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][17], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][17], 255);
	PlayerTextDrawFont(playerid, banking[playerid][17], 4);
	PlayerTextDrawSetProportional(playerid, banking[playerid][17], 0);
	PlayerTextDrawSetShadow(playerid, banking[playerid][17], 0);

	iphonex[playerid][4] = CreatePlayerTextDraw(playerid, 547.407348, 420.466308, "mdl-2024:thanhngang");
	PlayerTextDrawLetterSize(playerid, iphonex[playerid][4], 0.000000, 0.000000);
	PlayerTextDrawTextSize(playerid, iphonex[playerid][4], 61.629993, 4.819999);
	PlayerTextDrawAlignment(playerid, iphonex[playerid][4], 1);
	PlayerTextDrawColor(playerid, iphonex[playerid][4], -1);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetOutline(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][4], 255);
	PlayerTextDrawFont(playerid, iphonex[playerid][4], 4);
	PlayerTextDrawSetProportional(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetShadow(playerid, iphonex[playerid][4], 0);
	PlayerTextDrawSetSelectable(playerid, iphonex[playerid][4], true);

	banking[playerid][18] = CreatePlayerTextDraw(playerid, 597.274353, 327.953338, "0123456");
	PlayerTextDrawLetterSize(playerid, banking[playerid][18], 0.131537, 0.695832);
	PlayerTextDrawAlignment(playerid, banking[playerid][18], 1);
	PlayerTextDrawColor(playerid, banking[playerid][18], 255);
	PlayerTextDrawSetShadow(playerid, banking[playerid][18], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][18], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][18], 255);
	PlayerTextDrawFont(playerid, banking[playerid][18], 2);
	PlayerTextDrawSetProportional(playerid, banking[playerid][18], 1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][18], 0);

	banking[playerid][19] = CreatePlayerTextDraw(playerid, 584.920593, 302.618591, "Tyler Pylon");
	PlayerTextDrawLetterSize(playerid, banking[playerid][19], 0.131537, 0.695832);
	PlayerTextDrawAlignment(playerid, banking[playerid][19], 1);
	PlayerTextDrawColor(playerid, banking[playerid][19], 255);
	PlayerTextDrawSetShadow(playerid, banking[playerid][19], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][19], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][19], 255);
	PlayerTextDrawFont(playerid, banking[playerid][19], 2);
	PlayerTextDrawSetProportional(playerid, banking[playerid][19], 1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][19], 0);

	banking[playerid][20] = CreatePlayerTextDraw(playerid, 597.280273, 315.719390, "0123456");
	PlayerTextDrawLetterSize(playerid, banking[playerid][20], 0.131537, 0.695832);
	PlayerTextDrawAlignment(playerid, banking[playerid][20], 1);
	PlayerTextDrawColor(playerid, banking[playerid][20], 255);
	PlayerTextDrawSetShadow(playerid, banking[playerid][20], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][20], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][20], 255);
	PlayerTextDrawFont(playerid, banking[playerid][20], 2);
	PlayerTextDrawSetProportional(playerid, banking[playerid][20], 1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][20], 0);

	banking[playerid][21] = CreatePlayerTextDraw(playerid, 585.557678, 290.417846, "Tyler Pylon");
	PlayerTextDrawLetterSize(playerid, banking[playerid][21], 0.131537, 0.695832);
	PlayerTextDrawAlignment(playerid, banking[playerid][21], 1);
	PlayerTextDrawColor(playerid, banking[playerid][21], 255);
	PlayerTextDrawSetShadow(playerid, banking[playerid][21], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][21], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][21], 255);
	PlayerTextDrawFont(playerid, banking[playerid][21], 2);
	PlayerTextDrawSetProportional(playerid, banking[playerid][21], 1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][21], 0);

	banking[playerid][22] = CreatePlayerTextDraw(playerid, 577.196594, 264.102752, "1000");
	PlayerTextDrawLetterSize(playerid, banking[playerid][22], 0.299736, 1.413332);
	PlayerTextDrawAlignment(playerid, banking[playerid][22], 2);
	PlayerTextDrawColor(playerid, banking[playerid][22], 255);
	PlayerTextDrawSetShadow(playerid, banking[playerid][22], 0);
	PlayerTextDrawSetOutline(playerid, banking[playerid][22], 0);
	PlayerTextDrawBackgroundColor(playerid, banking[playerid][22], 255);
	PlayerTextDrawFont(playerid, banking[playerid][22], 2);
	PlayerTextDrawSetProportional(playerid, banking[playerid][22], 1);
	PlayerTextDrawSetShadow(playerid, banking[playerid][22], 0);

	PlayerTextDrawShow(playerid, banking[playerid][17]);
	PlayerTextDrawShow(playerid, iphonex[playerid][4]);
	PlayerTextDrawShow(playerid, banking[playerid][18]);
	PlayerTextDrawShow(playerid, banking[playerid][19]);
	PlayerTextDrawShow(playerid, banking[playerid][20]);
	PlayerTextDrawShow(playerid, banking[playerid][21]);
	PlayerTextDrawShow(playerid, banking[playerid][22]);


	// Ma giao dich
	format(string, sizeof(string), "%d",magiaodich, string);
    PlayerTextDrawSetString(playerid, banking[playerid][18] , string);

    // Nguoi nhan
    format(string, sizeof(string), "%s",GetRPName(targetid), string);
    PlayerTextDrawSetString(playerid, banking[playerid][19] , string);

    // Nguoi gui
    format(string, sizeof(string), "%s",GetRPName(playerid), string);
    PlayerTextDrawSetString(playerid, banking[playerid][21] , string);

    // So dien thoai
    format(string, sizeof(string), "%i",PlayerInfo[targetid][pPhone], string);
    PlayerTextDrawSetString(playerid, banking[playerid][20] , string);

    // So Tien Chuyen
    format(string, sizeof(string), "%i$",tienduocchuyen, string);
    PlayerTextDrawSetString(playerid, banking[playerid][22] , string);
	return 1;
}

stock Hidegiaodichthanhcong(playerid){
	PlayerTextDrawHide(playerid, banking[playerid][17]);
	PlayerTextDrawHide(playerid, iphonex[playerid][4]);
	PlayerTextDrawHide(playerid, banking[playerid][18]);
	PlayerTextDrawHide(playerid, banking[playerid][19]);
	PlayerTextDrawHide(playerid, banking[playerid][20]);
	PlayerTextDrawHide(playerid, banking[playerid][21]);
	PlayerTextDrawHide(playerid, banking[playerid][22]);
	return 1;
}

stock onplayerclickphone(playerid, PlayerText:playertextid){
	if(playertextid == iphonex[playerid][2])
    {
    	Hidephone(playerid);
   		Showapploading(playerid);
   		SetTimer("opentinnhan", 3000, false);
        return 1;
    }
    if(playertextid == iphonex[playerid][3])
    {
    	if(!PlayerInfo[playerid][pPhonebook])
		{
		    return SCM(playerid, COLOR_SYNTAX, "Ban khong the su dung lenh nay vi, Ban khong co phonebook.");
		}
		else{
			danhba(playerid);
		}
        return 1;
    }
    if(playertextid == iphonex[playerid][4])
    {
    	Hidephone(playerid);
    	Hidetime(playerid);
    	Hidemainappbanking(playerid);
    	Hidephonetinnhan(playerid);
        CancelSelectTextDraw(playerid);
        Hidegiaodichthanhcong(playerid);
        PlayerTextDrawHide(playerid, iphonex[playerid][12]);
        return 1;
    }
    if(playertextid == iphonex[playerid][5])
    {
        dialoggoi(playerid);
        return 1;
    }
    if(playertextid == iphonex[playerid][7])
    {
    	if(PlayerInfo[playerid][pLevel] < 3)
		{
			SendClientMessageEx(playerid, COLOR_GRAD1, "He Thong: Ban phai tren level 3 moi duoc tham gia banking!");
			return 1;
		}
		else{
			Hidephone(playerid);
	    	SetTimer("openbanking", 3000, false);
	    	Loadingbanking(playerid);
		}
    	
        return 1;
    }
    if(playertextid == iphonex[playerid][13])
    {
    	nhapthongtinsoiphonex(playerid);
    	return 1;
    }
    if(playertextid == iphonex[playerid][14])
    {
    	Hidephonetinnhan(playerid);
    	Showphone(playerid);
    	guiclicktinnhan(playerid);
    	SendClientMessage(playerid,COLOR_RED,"Tong Dai: Gui Tin Nhan Thanh Cong");
    	return 1;
    }
    if(playertextid == banking[playerid][9]){
    	ShowPlayerDialog(playerid, DIALOG_NAPTIEN, DIALOG_STYLE_INPUT, "OMPBANK-[NAPTIEN]", "Nhap So Tien Can Nap:", "Dong y", "Huy bo");
    	return 1;
    }
    if(playertextid == banking[playerid][10]){
    	SendClientMessage(playerid,COLOR_RED,"He Thong: Dang trong qua trinh phat trien!");
    	return 1;
    }
    if(playertextid == banking[playerid][11]){
    	SendClientMessage(playerid,COLOR_RED,"He Thong: Dang trong qua trinh phat trien!");
    	return 1;
    }
    if(playertextid == banking[playerid][13]){
    	dialogchuyentien(playerid);
    	return 1;
    }
    if(playertextid == banking[playerid][14]){
    	SendClientMessage(playerid,COLOR_RED,"Thanh toan Thanh Cong");
    	return 1;
    }
    if(playertextid == banking[playerid][15]){
    	ShowPlayerDialog(playerid, DIALOG_RUTTIEN, DIALOG_STYLE_INPUT, "OMPBANK-[RUTTIEN]", "Nhap So Tien Can Rut:", "Dong y", "Huy bo");
    	return 1;
    }
    return true;
}

stock goithuong(playerid){
	if(PlayerInfo[playerid][pTogglePhone])
	{
	    return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Ban khong the su dung Dien thoai di dong ngay bay gio khi ban co no");
	}
	if(PlayerInfo[playerid][pCallLine] != INVALID_PLAYER_ID)
	{
	    return SCM(playerid, COLOR_SYNTAX, "{00FF00}IPhone{00FF00}: Ban da co mot cuoc goi. /(h)angup de ket thuc cuoc goi.");
	}
	if(PlayerInfo[playerid][pTazedTime] > 0 || PlayerInfo[playerid][pHospital] > 0 || PlayerInfo[playerid][pTied] > 0 || PlayerInfo[playerid][pCuffed] > 0 || PlayerInfo[playerid][pJailTime] > 0)
	{
	    return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Ban khong the su dung dien thoai vao luc nay.");
	}
	ShowPlayerDialog(playerid, DIALOG_GOITHUONG, DIALOG_STYLE_INPUT, "IPhone X - Goi[Thuong]", "Nhap So Dien Thoai:", "Goi", "Huy");
	return 1;
}

stock goithuong2(playerid){
	foreach(new i : Player)
	{
	    if(PlayerInfo[i][pPhone] == number)
	    {
	        if(PlayerInfo[i][pJailType] > 0)
	        {
	            return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Nguoi choi nay hien tai dang o tu ban khong the lien lac voi ho");
	        }
	        if(PlayerInfo[i][pCallLine] != INVALID_PLAYER_ID)
	        {
	            return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Nguoi choi nay hien tai dang co mot cuoc goi. Hay doi cuoc goi cua ho ket thuc");
	        }
	        if(PlayerInfo[i][pTogglePhone])
	        {
	            return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Nguoi choi nay Dien thoai di dong dang o che do May Bay");
			}
			if(PlayerInfo[i][pLiveBroadcast] != INVALID_PLAYER_ID)
			{
			    return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: Nguoi choi hien dang phong van khong the su dung dien thoai");
	        }

	        SetPlayerSpecialAction(playerid, SPECIAL_ACTION_USECELLPHONE);

			PlayerInfo[playerid][pCallLine] = i;
			PlayerInfo[playerid][pCallStage] = 0;

			PlayerInfo[i][pCallLine] = playerid;
			PlayerInfo[i][pCallStage] = 1;

			SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da lay dien thoai di dong ra va goi cho ai do.", GetRPName(playerid));
			SendProximityMessage(i, 20.0, SERVER_COLOR, "**{C2A2DA} %s's Dien thoai di dong dang do chuong.", GetRPName(i));

	        SM(playerid, COLOR_YELLOW, "** Ban da thuc hien cuoc goi den so: %i. Vui long cho cho den khi cuoc goi cua ban duoc tra loi.", number);
	        SM(i, COLOR_YELLOW, "** Cuoc goi den tu #%i. Su dung /pickup de nhan cuoc goi.", PlayerInfo[playerid][pPhone]);
	        return 1;
		}
	}
	SCM(playerid, COLOR_SYNTAX, "Tong Dai: So dien thoai nay khong co hoac dang ngoai tuyen.");
	return 1;
}

stock goikhancap(playerid){
	ShowPlayerDialog(playerid, DIALOG_KHANCAP, DIALOG_STYLE_LIST, "Iphone X - Goi[Khan Cap]", "Hotline khan cap\nNha bao\nTho Sua Xe\nTaxi", "Goi", "Huy Bo");
	return 1;
}

stock dialoggoi(playerid){
	ShowPlayerDialog(playerid, DIALOG_GOI, DIALOG_STYLE_LIST, "IPhone X - Goi", "{00FF00}Thuong{00FF00}\n{FF0000}Khan Cap{FF0000}", "Goi", "Huy Bo");
	return 1;
}

stock hotlinekhancap(playerid){
	PlayerInfo[playerid][pCallLine] = playerid;
	PlayerInfo[playerid][pCallStage] = 911;
	SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da nhap so dien thoai, va bat dau mot cuoc goi.", GetRPName(playerid));
	SCM(playerid, COLOR_DISPATCH, "Tong Dai[911]: So dien thoai ban goi den la gi? [Nhap'police' or 'medic]");
	return 1;
}
stock nhabao(playerid){
	PlayerInfo[playerid][pCallLine] = playerid;
	PlayerInfo[playerid][pCallStage] = 6397;
	SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da nhap so dien thoai, va bat dau mot cuoc goi.", GetRPName(playerid));
	SCM(playerid, COLOR_DISPATCH, "Sannew: Hay de lai tin nhan chung toi se lien lac lai voi ban! *BEEP*");
	return 1;
}

stock thosuaxe(playerid){
	PlayerInfo[playerid][pCallLine] = playerid;
	PlayerInfo[playerid][pCallStage] = 6324;
	SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da nhap so dien thoai, va bat dau mot cuoc goi.", GetRPName(playerid));
	SCM(playerid, COLOR_DISPATCH, "Mechanic Hotline: Vui long trinh bay tinh huong cua ban voi chung toi.");
	return 1;
}

stock taxi(playerid){
	PlayerInfo[playerid][pCallLine] = playerid;
	PlayerInfo[playerid][pCallStage] = 8294;
	SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da lay dien thoai di dong ra va goi cho ai do.", GetRPName(playerid));
	SCM(playerid, COLOR_DISPATCH, "Cab Company: Vui long chon vi tri diem den cua ban.");
	return 1;
}

stock nhapthongtinsoiphonex(playerid){
	ShowPlayerDialog(playerid, DIALOG_SOiphonex, DIALOG_STYLE_INPUT, "Tin Nhan-[So Dien Thoai]", "Nhap so dien thoai:", "Dong y", "Huy bo");
	return 1;
}

stock nhapthongtinvanban(playerid){
	ShowPlayerDialog(playerid, DIALOG_VANBAN, DIALOG_STYLE_INPUT, "Tin Nhan-[Van Ban]", "Nhap van ban vao day:", "Dong y", "Huy bo");
	return 1;
}

stock guiclicktinnhan(playerid){
	foreach(new i : Player)
	{
	    if(PlayerInfo[i][pPhone] == soiphonex)
	    {
	        if(PlayerInfo[i][pJailType] > 0)
	        {
	            return SCM(playerid, COLOR_SYNTAX, "Tong Dai: Nguoi choi nay hien tai dang o tu ban khong the lien lac voi ho.");
	        }
	        if(PlayerInfo[i][pTogglePhone])
	        {
	            return SCM(playerid, COLOR_SYNTAX, "Tong Dai: Nguoi choi nay Dien thoai di dong dang o che do May Bay.");
			}

			SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s lay dien thoai ra va gui tin nhan", GetRPName(playerid));

			if(strlen(vanban[127]) > MAX_SPLIT_LENGTH)
			{
			    SM(i, COLOR_YELLOW, "** SMS from %s (%i): %.*s... **", GetRPName(playerid), PlayerInfo[playerid][pPhone], MAX_SPLIT_LENGTH, vanban);
			    SM(i, COLOR_YELLOW, "** SMS from %s (%i): ...%s **", GetRPName(playerid), PlayerInfo[playerid][pPhone], vanban[MAX_SPLIT_LENGTH]);

			    SM(playerid, COLOR_YELLOW, "** SMS boi %s  (%i): %.*s... **", GetRPName(i), PlayerInfo[i][pPhone], MAX_SPLIT_LENGTH, vanban);
			    SM(playerid, COLOR_YELLOW, "** SMS boi %s  (%i): ...%s **", GetRPName(i), PlayerInfo[i][pPhone], vanban[MAX_SPLIT_LENGTH]);
			}
			else
			{
		        SM(i, COLOR_YELLOW, "** SMS from %s (%i): %s **", GetRPName(playerid), PlayerInfo[playerid][pPhone], vanban[127]);
		        SM(playerid, COLOR_YELLOW, "** SMS boi %s  (%i): %s **", GetRPName(i), PlayerInfo[i][pPhone], vanban[127]);
			}

			PlayerInfo[playerid][pCash] -=500;
			SendClientMessage(playerid, COLOR_WHITE, "Tong Dai: ban da bi tru thue la 500 dong cho moi tin nhan!");
	        return 1;
		}
	}

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "SELECT username, jailtype, togglephone FROM users WHERE phone = %i", number);
	mysql_tquery(connectionID, queryBuffer, "OnPlayerSendTextMessage", "iis", playerid, number, vanban);
	return 1;
}


stock dialogchuyentien(playerid){
	ShowPlayerDialog(playerid, DIALOG_NGANHANG, DIALOG_STYLE_LIST, "OMPBANK-[Chuyen Tien]", "Chuyen Tien\nCham Soc Khach Hang", "Dong y", "Huy bo");
	return 1;
}

stock inputchuyentientaikhoan(playerid){
	ShowPlayerDialog(playerid, DIALOG_INPUTCHUYENTIENTAIKHOAN, DIALOG_STYLE_INPUT, "OMPBANK-[Chuyen Tien]", "Nhap So Tai Khoan [ID]:", "Dong y", "Huy bo");
	return 1;
}

stock inputchuyentien(playerid){
	ShowPlayerDialog(playerid, DIALOG_INPUTCHUYENTIEN, DIALOG_STYLE_INPUT, "OMPBANK-[Chuyen Tien]", "Nhap So Tien [Thue 500$]:", "Giao dich", "Huy bo");
	return 1;
}

stock chuyentien(playerid){
	if(amount < 1 || amount > PlayerInfo[playerid][pBank])
	{
	    return SCM(playerid, COLOR_SYNTAX, "Banking: So tien trong ngan hang khong du");
	}
	if(targetid == playerid)
	{
	    return SCM(playerid, COLOR_SYNTAX, "Banking: Ban khong the chuyen tien cho chinh minh");
	}

	PlayerInfo[targetid][pBank] += amount;
	PlayerInfo[playerid][pBank] -= amount;

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET bank = %i WHERE uid = %i", PlayerInfo[playerid][pBank], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);

    mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET bank = %i WHERE uid = %i", PlayerInfo[targetid][pBank], PlayerInfo[targetid][pID]);
	mysql_tquery(connectionID, queryBuffer);

	//SM(playerid, COLOR_AQUA, "** Ban da chuyen $%i cho %s. So du moi cua ban la $%i.", amount, GetRPName(targetid), PlayerInfo[playerid][pBank]);
	//SM(targetid, COLOR_AQUA, "** %s da chuyen $%i vao tai khoan ngan hang cua ban.", GetRPName(playerid), amount);
	Log_Write("log_give", "%s (uid: %i) (IP: %s) chuyen $%i cho %s (uid: %i) (IP: %s)", GetRPName(playerid), PlayerInfo[playerid][pID], GetPlayerIP(playerid), amount, GetRPName(targetid), PlayerInfo[targetid][pID], GetPlayerIP(targetid));

    if(!strcmp(GetPlayerIP(playerid), GetPlayerIP(targetid)))
	{
	    SAM(COLOR_YELLOW, "AdmCanhBao: %s (IP: %s) da chuyen $%i cho %s (IP: %s).", GetRPName(playerid), GetPlayerIP(playerid), amount, GetRPName(targetid), GetPlayerIP(targetid));
	}
	return 1;
}

stock danhba(playerid){
	if(!IsPlayerConnected(targetid))
	{
	    return SCM(playerid, COLOR_SYNTAX, "Khong the su dung lenh nay o thoi diem hien tai.");
	}
	ShowPlayerDialog(playerid, DIALOG_DANHBA, DIALOG_STYLE_INPUT, "Danh Ba", "Nhap thong tin [ID]:", "Dong y", "Huy bo");
	return 1;
}

stock thongtindanhba(playerid){
	new resultline[1024], header[65];
	format(header, sizeof(header), "Danh Ba Cua %s", GetPlayerNameEx(targetid));
	format(resultline, sizeof(resultline),"\n\
	Cap do: %s\n\
	So Dien Thoai: %i",
	number_format(PlayerInfo[targetid][pLevel]),
	PlayerInfo[targetid][pPhone]),
	ShowPlayerDialogEx(playerid, DIALOG_THONGTINDANHBA, DIALOG_STYLE_MSGBOX, header, resultline, "Dong y", "Huy bo");
	return 1;
}
//-------------PUBLIC/FORWARD-------------//
forward openbanking(playerid);
public openbanking(playerid){
	HideLoadingbanking(playerid);
	Showmainappbanking(playerid);
	return true;
}

forward opentinnhan(playerid);
public opentinnhan(playerid){
	Hideapploading(playerid);
	Showphonetinnhan(playerid);
	return true;
}
//-------------HOOK-------------//
hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys)
{
	if(newkeys == KEY_YES)
	{
		cmd_phone(playerid, "\1");
	}
	return 1;
}

hook OnPlayerConnect(playerid) 
{

    return 1;
}

hook OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]){
	if(dialogid == DIALOG_GOI)
    {
    	if(response)
        {
	        switch(listitem)
	        {
	            //Thuong
	            case 0:{
	                goithuong(playerid);
	            }
	            //KhanCap
	            case 1:{
	                goikhancap(playerid);
	            }
	        }
	    }
        return 1;
    }
    if(dialogid == DIALOG_KHANCAP)
    {
    	if(response)
        {
	        switch(listitem)
	        {
	            //Hotline Khan cap
	            case 0:{
	               	hotlinekhancap(playerid);
	            }
	            //Nha Bao
	            case 1:{
	                nhabao(playerid);
	            }
	            //Tho Sua Xe
	            case 2:{
	                thosuaxe(playerid);
	            }
	            //Taxi
	            case 3:{
	                taxi(playerid);
	            }
	        }
	    }
        return 1;
    }
    if(dialogid == DIALOG_GOITHUONG){
    	number = strval(inputtext);
    	if(number == 0 || number == PlayerInfo[playerid][pPhone])
		{
		    return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: So dien thoai khong hop le");
		}
		if(number < 0 && number > 6){
			return SCM(playerid, COLOR_SYNTAX, "{FF0000}IPhone{FF0000}: So dien thoai toi thieu 6 so");
		}
		else{
			goithuong2(playerid);
		}
    }
    if(dialogid == DIALOG_NGANHANG){
    	if(response)
        {
	        switch(listitem)
	        {
	            //chuyentien
	            case 0:{
	               	inputchuyentientaikhoan(playerid);
	            }
	            //chamsockhachhang
	            case 1:{
	                SendClientMessage(playerid, COLOR_WHITE, "Cham soc khach hang: ban can ho tro gi?");
	            }
	        }
	    }
    	return true;
    }
    if(dialogid == DIALOG_INPUTCHUYENTIENTAIKHOAN){
    	if(response)
        {
			targetid = strval(inputtext);
			inputchuyentien(playerid);
        }
    	return true;
    }
    if(dialogid == DIALOG_INPUTCHUYENTIEN){
    	if(response)
        {
	    	tienduocchuyen = strval(inputtext);
	    	chuyentien(playerid);
	    }
    	return 1;
    }
    if(dialogid == DIALOG_NAPTIEN){
    	if(response)
        {
	    	naptien = strval(inputtext);
	    	PlayerInfo[playerid][pBank] += naptien;
			PlayerInfo[playerid][pCash] -= naptien;
			SM(playerid, COLOR_YELLOW, "Banking: ban da nap so tien [%d$] vao tai khoan ngan hang", naptien);
	    }
    	return 1;
    }
    if(dialogid == DIALOG_RUTTIEN){
    	if(response)
        {
	    	ruttien = strval(inputtext);
	    	PlayerInfo[playerid][pBank] -= ruttien;
			PlayerInfo[playerid][pCash] += ruttien;
			SM(playerid, COLOR_YELLOW, "Banking: ban da rut so tien [%d$] ra khoi tai khoan ngan hang", ruttien);
	    }
    	return 1;
    }
    if(dialogid == DIALOG_SOiphonex){
    	if(response){
    		soiphonex = strval(inputtext);
    		nhapthongtinvanban(playerid);
    	}
    }
    if(dialogid == DIALOG_VANBAN){
    	if(response){
    		new string[128];
    		vanban[127] = strlen(inputtext);
    		//Soiphonex
    		format(string, sizeof(string), "%i",soiphonex, string);
    		PlayerTextDrawSetString(playerid, iphonex[playerid][13] , string);

    		//Hide tin nhan van ban
    		PlayerTextDrawHide(playerid, iphonex[playerid][12]);

    		iphonex[playerid][12] = CreatePlayerTextDraw(playerid, 575.715393, 286.066772, "Van ban bao mat (Security)");
			PlayerTextDrawLetterSize(playerid, iphonex[playerid][12], 0.155092, 0.719165);
			PlayerTextDrawAlignment(playerid, iphonex[playerid][12], 2);
			PlayerTextDrawColor(playerid, iphonex[playerid][12], -1061109505);
			PlayerTextDrawSetShadow(playerid, iphonex[playerid][12], 0);
			PlayerTextDrawSetOutline(playerid, iphonex[playerid][12], 0);
			PlayerTextDrawBackgroundColor(playerid, iphonex[playerid][12], 255);
			PlayerTextDrawFont(playerid, iphonex[playerid][12], 2);
			PlayerTextDrawSetProportional(playerid, iphonex[playerid][12], 1);
			PlayerTextDrawSetShadow(playerid, iphonex[playerid][12], 0);
			PlayerTextDrawShow(playerid, iphonex[playerid][12]);

    		//ten
    		format(string, sizeof(string), "%s",GetRPName(playerid), string);
    		PlayerTextDrawSetString(playerid, iphonex[playerid][10] , string);
    		return 1;
    	}
    }
    if(dialogid == DIALOG_DANHBA){
    	if(response){
			targetid = strval(inputtext);
	    	thongtindanhba(playerid);
	    	return 1;
    	}
    }
	return 1;
}

