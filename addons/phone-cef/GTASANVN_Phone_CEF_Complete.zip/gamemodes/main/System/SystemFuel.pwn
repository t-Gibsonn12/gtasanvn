#include <YSI\y_hooks>

new PlayerText:MenuFuel[MAX_PLAYERS][5];

stock ShowMenuFuel(playerid){
    MenuFuel[playerid][0] = CreatePlayerTextDraw(playerid, 184.414352, 139.833282, "mdl-2019:menufuel");
    PlayerTextDrawLetterSize(playerid, MenuFuel[playerid][0], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, MenuFuel[playerid][0], 262.000000, 289.000000);
    PlayerTextDrawAlignment(playerid, MenuFuel[playerid][0], 1);
    PlayerTextDrawColor(playerid, MenuFuel[playerid][0], -1);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][0], 0);
    PlayerTextDrawSetOutline(playerid, MenuFuel[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, MenuFuel[playerid][0], 255);
    PlayerTextDrawFont(playerid, MenuFuel[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, MenuFuel[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][0], 0);

    MenuFuel[playerid][1] = CreatePlayerTextDraw(playerid, 118.921394, 81.400047, "mdl-2020:doxang");
    PlayerTextDrawLetterSize(playerid, MenuFuel[playerid][1], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, MenuFuel[playerid][1], 264.000000, 283.000000);
    PlayerTextDrawAlignment(playerid, MenuFuel[playerid][1], 1);
    PlayerTextDrawColor(playerid, MenuFuel[playerid][1], -1);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][1], 0);
    PlayerTextDrawSetOutline(playerid, MenuFuel[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, MenuFuel[playerid][1], 255);
    PlayerTextDrawFont(playerid, MenuFuel[playerid][1], 4);
    PlayerTextDrawSetProportional(playerid, MenuFuel[playerid][1], 0);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][1], 0);
    PlayerTextDrawSetSelectable(playerid, MenuFuel[playerid][1], true);

    MenuFuel[playerid][2] = CreatePlayerTextDraw(playerid, 258.709045, 75.716697, "mdl-2021:muaxang");
    PlayerTextDrawLetterSize(playerid, MenuFuel[playerid][2], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, MenuFuel[playerid][2], 263.000000, 285.000000);
    PlayerTextDrawAlignment(playerid, MenuFuel[playerid][2], 1);
    PlayerTextDrawColor(playerid, MenuFuel[playerid][2], -1);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][2], 0);
    PlayerTextDrawSetOutline(playerid, MenuFuel[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, MenuFuel[playerid][2], 255);
    PlayerTextDrawFont(playerid, MenuFuel[playerid][2], 4);
    PlayerTextDrawSetProportional(playerid, MenuFuel[playerid][2], 0);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][2], 0);
    PlayerTextDrawSetSelectable(playerid, MenuFuel[playerid][2], true);

    MenuFuel[playerid][3] = CreatePlayerTextDraw(playerid, 241.168228, 128.616348, "mdl-2022:huybo");
    PlayerTextDrawLetterSize(playerid, MenuFuel[playerid][3], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, MenuFuel[playerid][3], 265.000000, 280.000000);
    PlayerTextDrawAlignment(playerid, MenuFuel[playerid][3], 1);
    PlayerTextDrawColor(playerid, MenuFuel[playerid][3], -1);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][3], 0);
    PlayerTextDrawSetOutline(playerid, MenuFuel[playerid][3], 0);
    PlayerTextDrawBackgroundColor(playerid, MenuFuel[playerid][3], 255);
    PlayerTextDrawFont(playerid, MenuFuel[playerid][3], 4);
    PlayerTextDrawSetProportional(playerid, MenuFuel[playerid][3], 0);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][3], 0);
    PlayerTextDrawSetSelectable(playerid, MenuFuel[playerid][3], true);

    MenuFuel[playerid][4] = CreatePlayerTextDraw(playerid, 137.462219, 126.366706, "mdl-2023:muahang");
    PlayerTextDrawLetterSize(playerid, MenuFuel[playerid][4], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, MenuFuel[playerid][4], 262.000000, 287.000000);
    PlayerTextDrawAlignment(playerid, MenuFuel[playerid][4], 1);
    PlayerTextDrawColor(playerid, MenuFuel[playerid][4], -1);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][4], 0);
    PlayerTextDrawSetOutline(playerid, MenuFuel[playerid][4], 0);
    PlayerTextDrawBackgroundColor(playerid, MenuFuel[playerid][4], 255);
    PlayerTextDrawFont(playerid, MenuFuel[playerid][4], 4);
    PlayerTextDrawSetProportional(playerid, MenuFuel[playerid][4], 0);
    PlayerTextDrawSetShadow(playerid, MenuFuel[playerid][4], 0);
    PlayerTextDrawSetSelectable(playerid, MenuFuel[playerid][4], true);

    PlayerTextDrawShow(playerid, MenuFuel[playerid][0]);
    PlayerTextDrawShow(playerid, MenuFuel[playerid][1]);
    PlayerTextDrawShow(playerid, MenuFuel[playerid][2]);
    PlayerTextDrawShow(playerid, MenuFuel[playerid][3]);
    PlayerTextDrawShow(playerid, MenuFuel[playerid][4]);
    return 1;
}

stock HideMenuFuel(playerid){
    PlayerTextDrawHide(playerid, MenuFuel[playerid][0]);
    PlayerTextDrawHide(playerid, MenuFuel[playerid][1]);
    PlayerTextDrawHide(playerid, MenuFuel[playerid][2]);
    PlayerTextDrawHide(playerid, MenuFuel[playerid][3]);
    PlayerTextDrawHide(playerid, MenuFuel[playerid][4]);
    return 1;
}


CMD:menufuel(playerid, params[]){
    ShowMenuFuel(playerid);
    return 1;
}

CMD:hidemenufuel(playerid,params[]){
    HideMenuFuel(playerid);
    return 1;
}


hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys) {
    if(newkeys == KEY_YES)
    {
        cmd_hidemenufuel(playerid, "\1");
    } 
    return 1;
}