#include <YSI\y_hooks>
#include <a_samp>
#include <streamer>

#define TR_POS1	1148.2944,-1383.0095,13.8190
#define TR_POS2	1146.8461,-1344.3054,13.6183
#define TR_POS3 1231.3176,-1414.6760,13.3332
#define TR_POS4	1537.4865,-1649.2277,13.5469
#define TR_POS5	1816.5455,-1625.9133,13.5469
#define TR_POS6	1927.1519,-1764.9828,13.5391
#define TR_POS7	2151.0632,-1728.1313,13.5406
#define TR_POS8	2153.2620,-1728.0162,13.5406


hook OnGameModeInit(){
	CreateDynamicObject(1331, 1149.268432, -1383.037231, 13.463535, 0.000000, 0.000000, -89.200019, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1331, 1146.763427, -1343.058959, 13.230649, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1337, 1231.520751, -1415.385864, 12.992623, 0.000000, 0.000000, -167.399978, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1264, 1232.302246, -1415.358764, 12.567749, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1331, 1538.528564, -1649.144897, 13.206879, 0.000000, 0.000000, -89.900016, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1337, 1538.481811, -1650.492919, 13.166871, 0.000000, 0.000000, -79.900001, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1337, 1815.787597, -1626.000366, 13.172813, 0.000000, 0.000000, 95.299957, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1264, 1815.682617, -1626.750244, 12.892810, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1372, 1927.167114, -1765.735595, 12.673506, 0.000000, 0.000000, 179.200042, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1265, 1925.843627, -1765.820556, 12.979076, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(3035, 2153.239990, -1729.057983, 13.188096, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1227, 2151.009277, -1729.160400, 13.009754, 0.000000, 0.000000, 178.899993, -1, -1, -1, 300.00, 300.00); 
	CreateDynamicObject(1264, 2154.692871, -1729.150268, 12.879978, 0.000000, 0.000000, 0.000000, -1, -1, -1, 300.00, 300.00); 
	
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1149.268432, -1383.037231, 13.463535+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1146.763427, -1343.058959, 13.230649+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1231.520751, -1415.385864, 12.992623+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1538.528564, -1649.144897, 13.206879+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1538.481811, -1650.492919, 13.166871+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1815.787597, -1626.000366, 13.172813+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 1927.167114, -1765.735595, 12.673506+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 2153.239990, -1729.057983, 13.188096+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 2151.009277, -1729.160400, 13.009754+0.5,100);
	CreateDynamic3DTextLabel("[/lucthungrac] de luc luc rac",-1, 2154.692871, -1729.150268, 12.879978+0.5,100);
	return 1;
}

CMD:lucthungrac(playerid,params[]){
	if(IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS1) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS2) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS3) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS4) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS5) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS6) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS7) || IsPlayerInRangeOfPoint(playerid, 4.0, TR_POS8)){
		if(IsPlayerInAnyVehicle(playerid)){
			SendClientMessageEx(playerid, COLOR_RED, "{FF0000}He Thong{FF0000}: Ban khong the luc thung rac khi dang ngoi tren xe.");
		}
		else{
			lucthungrac(playerid);
			GameTextForPlayer(playerid, "Dang Luc Rac..", 10000, 1);
		}
	}	
	return 1;
}

stock lucthungrac(playerid){
	ApplyAnimation(playerid,  "BD_FIRE", "wash_up", 4.1, 1, 1, 1, 1, 1, 1);
	TogglePlayerControllable(playerid, 0);
	SetTimer("thoigianlucrac", 10000, false);
	return 1;
}

/*
stock randomdovat(playerid){
	new string[1000];
	new rddv = random(200);
	switch(rddv){
		case 0..50:{
			new rdbichnilong = random(5);
			PlayerInfo[playerid][pBichnilong] += rdbichnilong;
			format(string, 1000, "He Thong: Ban da luc thung rac duoc %d bich ni long", rdbichnilong);
		}
		case 51..100:{
			new rdbichrac = random(3);
			PlayerInfo[playerid][pBichrac] += rdbichrac;
			format(string, 1000, "He Thong: Ban da luc thung rac duoc %d bich rac", rdbichrac);
		}
		case 101..121:{
			new rdtien = random(100000);
			PlayerInfo[playerid][pCash] += rdtien;
			format(string, 1000, "He Thong: Ban da luc thung rac duoc %d tien le", rdtien);
		}
		case 122..142:{
			new rdpot = random(30);
			PlayerInfo[playerid][pPot] += rdpot;
			format(string,1000,"He Thong: Ban da luc thung rac duoc %d bich ma tuy", rdpot);
		}
		case 143..200:{
			SendClientMessage(playerid, COLOR_WHITE,"He Thong: Ban khong luc duoc vat pham gi ca.");
		}
	}
	return 1;
}*/

CMD:kiemtrabichrac(playerid,params[]){
	new string[128];
	format(string, 128,"Bich Nilong: %d", PlayerInfo[playerid][pBichnilong]);
	SendClientMessage(playerid, -1, string);
	format(string, 128,"Bich Rac: %d", PlayerInfo[playerid][pBichrac]);
	SendClientMessage(playerid, -1, string);
	format(string, 128,"Ma Tuy: %d", PlayerInfo[playerid][pPot]);
	SendClientMessage(playerid, -1, string);
	return 1;
}

forward thoigianlucrac(playerid);
public thoigianlucrac(playerid){
	ClearAnimations(playerid);
	TogglePlayerControllable(playerid, 1);
	new string[1000];
	new rddv = random(200);
	switch(rddv){
		case 0..50:{
			new rdbichnilong = random(5);
			if(rdbichnilong == 0){
				SendClientMessage(playerid, COLOR_WHITE,"He Thong: Ban khong luc duoc vat pham gi ca.");
			}
			else{
				PlayerInfo[playerid][pBichnilong] += rdbichnilong;
				format(string, 1000, "He Thong: Ban da luc thung rac duoc %d bich ni long", rdbichnilong);
				SendClientMessage(playerid, -1, string);
			}
			
		}
		case 51..100:{
			new rdbichrac = random(3);
			if(rdbichrac == 0){
				SendClientMessage(playerid, COLOR_WHITE,"He Thong: Ban khong luc duoc vat pham gi ca.");
			}else{
				PlayerInfo[playerid][pBichrac] += rdbichrac;
				format(string, 1000, "He Thong: Ban da luc thung rac duoc %d bich rac", rdbichrac);
				SendClientMessage(playerid, -1, string);
			}
		}
		case 101..121:{
			new rdtien = random(100000);
			if(rdtien == 0){
				SendClientMessage(playerid, COLOR_WHITE,"He Thong: Ban khong luc duoc vat pham gi ca.");
			}else{
				PlayerInfo[playerid][pCash] += rdtien;
				format(string, 1000, "He Thong: Ban da luc thung rac duoc %d tien le", rdtien);
				SendClientMessage(playerid, -1, string);
			}
		}
		case 122..142:{
			new rdpot = random(30);
			if(rdpot == 0){
				SendClientMessage(playerid, COLOR_WHITE,"He Thong: Ban khong luc duoc vat pham gi ca.");
			}else{
				PlayerInfo[playerid][pPot] += rdpot;
				format(string,1000,"He Thong: Ban da luc thung rac duoc %d bich ma tuy", rdpot);
				SendClientMessage(playerid, -1, string);
			}
		}
		case 143..200:{
			SendClientMessage(playerid, COLOR_WHITE,"He Thong: Ban khong luc duoc vat pham gi ca.");
		}
	}
	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET pot = %i WHERE uid = %i", PlayerInfo[playerid][pPot], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Bichnilong = %i WHERE uid = %i", PlayerInfo[playerid][pBichnilong], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Bichrac = %i WHERE uid = %i", PlayerInfo[playerid][pBichrac], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);

	mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET cash = %i WHERE uid = %i", PlayerInfo[playerid][pCash], PlayerInfo[playerid][pID]);
	mysql_tquery(connectionID, queryBuffer);
	return 1;
}