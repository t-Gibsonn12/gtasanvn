#include <YSI\y_hooks>
#include <a_samp>
#include <a_mysql>
#include <foreach>
#include <ZCMD>

//----------------------NEW----------------------//
new npcbitcoin;
new mayao;
new Text3D:mayao3DText;
new PlayerText:bitcoin[MAX_PLAYERS][15];

new 
    Float: x,
    Float: y,
    Float: z,
    Float: a,
    string[128];
            
//----------------------DEFINE----------------------//
#define DIALOG_MAYAO (19995)
#define DIALOG_CHECKHOADONG1 (19996)
#define DIALOG_LUACHONMAYAO (19997)
#define DIALOG_BUY (19998)
#define DIALOG_SELL (19999)

//----------------------CMD----------------------//
CMD:buyblockchain(playerid, params[])
{
    if(PlayerInfo[playerid][pMayao] != 1){
        SendClientMessage(playerid, COLOR_RED,"He Thong Blockchain: So luong may ao khong san xuat kip va co gioi han");
        SendClientMessage(playerid, COLOR_RED,"He Thong Blockchain: toi da moi nguoi 1 may ao, cam on!");
    }else{
        if(IsPlayerInRangeOfActor(playerid,npcbitcoin,5.0)){
        ShowPlayerDialog(playerid, DIALOG_MAYAO, DIALOG_STYLE_TABLIST, "PC BlockChain","Blockchain OMP\t$5.000.000\t[1000 Hz/h]\t{FF4E28}[Loai: Binh Thuong]{FF4E28}","Don Hang", "Huy Don");
        }
    }
    
    return 1;
}

CMD:catmayao(playerid, params[]){
    xulycatmayao(playerid);
}

CMD:datmayao(playerid,params){
    if(PlayerInfo[playerid][pTazedTime] > 0 || PlayerInfo[playerid][pInjured] > 0 || PlayerInfo[playerid][pHospital] > 0 || PlayerInfo[playerid][pTied] > 0 || PlayerInfo[playerid][pCuffed] > 0 || PlayerInfo[playerid][pJailTime] > 0)
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong Blockchain: Ban khong the su dung lenh nay vao luc nay.");
    }
    ShowPlayerDialog(playerid,DIALOG_LUACHONMAYAO,DIALOG_STYLE_LIST,"LUA CHON PC BlockChain","Blockchain OMP\tBinh Thuong","Dong y","Huy bo");
    return 1;
}

CMD:tatmayao(playerid, params[]){
    tatmayao(playerid);
    tatbangthongtinbitcoin(playerid);
    CancelSelectTextDraw(playerid);
    return 1;
}
CMD:khoidongmayao(playerid,params[]){
    if(PlayerInfo[playerid][pMayaodatroi] == 1){
        khoidongmayao(playerid);
        batbangthongtinbitcoin(playerid);
        SelectTextDraw(playerid, 0xFF4040AA);
    }else{
        SendClientMessage(playerid, COLOR_RED, "He Thong BlockChain: Ban can dat may ao xuong de khoi dong may ao.");
    }
    return 1;
}

CMD:kiemtramayao(playerid,params[]){
    new string[128];
    format(string,128,"So Luong May Ao: %d", PlayerInfo[playerid][pMayao]);
    SendClientMessage(playerid, -1,string);
    format(string,128,"So BitCoin: %d", PlayerInfo[playerid][pBitcoin]);
    SendClientMessage(playerid, -1,string);
    return 1;
}

CMD:vutmayao(playerid,params[]){
    new option[10],
        param[128];
    if(sscanf(params, "s[10]S()[128]", option, param))
    {
        return SCM(playerid, COLOR_SYNTAX, "Su dung: /vutmayao [mayao]");
    }

    if(!strcmp(option, "mayao", true))
    {
        PlayerInfo[playerid][pMayao] -= 1;
        return 1;
    }
    mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Bitcoin = %i WHERE uid = %i", PlayerInfo[playerid][pBitcoin], PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, queryBuffer);
    mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Mayao = %i WHERE uid = %i", PlayerInfo[playerid][pMayao], PlayerInfo[playerid][pID]);
    mysql_tquery(connectionID, queryBuffer);
    return 1;
}

//----------------------HOOK----------------------//
/*hook OnGameModeInit(){
    npcbitcoin = CreateActor(290,2224.7556,1830.6688,10.8203,87.4875);
    CreateDynamic3DTextLabel("Denny John", -1 , 2224.7556,1830.6688,10.8203+1, 20.0);
    ApplyActorAnimation(npcbitcoin, "DEALER", "shop_pay", 4.1,0,0,0,0,0);
    return 1;
}*/

hook OnGameModeExit()
{
    print("He Thong Blockchain: Tam dung qua trinh dao bitcoin");
    DestroyDynamicObject(mayao);
    DestroyDynamic3DTextLabel( Text3D:mayao3DText );
    return 1;
}

hook OnPlayerKeyStateChange(playerid, newkeys, oldkeys){
    if(newkeys == KEY_YES){
        cmd_buyblockchain(playerid, "\1");
    }
    return 1;
}

hook OnDialogResponse(playerid, dialogid, response, listitem, inputtext[]){
    if(dialogid == DIALOG_LUACHONMAYAO){
        if(response){
            if(listitem == 0){
                khoitaomayao(playerid);
            }
        }
        return 1;
    }
    if(dialogid == DIALOG_MAYAO)
    {
        if(response)
        {
            if(listitem == 0)
            {
                ShowPlayerDialog(playerid, DIALOG_CHECKHOADONG1, DIALOG_STYLE_MSGBOX, "Hoa Don", "Ten May Ao: Blockchain OMP\n\
                Gia Tien: 5.000.000$\n\
                Loai: Yeu\n\
                Cong Suat: 1000 Hz/h\n ", "Mua Hang", "Huy Don");
            }
        }
        mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Bitcoin = %i WHERE uid = %i", PlayerInfo[playerid][pBitcoin], PlayerInfo[playerid][pID]);
        mysql_tquery(connectionID, queryBuffer);
        mysql_format(connectionID, queryBuffer, sizeof(queryBuffer), "UPDATE users SET Mayao = %i WHERE uid = %i", PlayerInfo[playerid][pMayao], PlayerInfo[playerid][pID]);
        mysql_tquery(connectionID, queryBuffer);
    }
    if(dialogid == DIALOG_CHECKHOADONG1){
        if(response){
            PlayerInfo[playerid][pMayao] += 1;
            PlayerInfo[playerid][pCash] -= 500000;
            SendClientMessage(playerid,-1, "{3dcc3f}{3dcc3f}He Thong Blockchain{3dcc3f}{3dcc3f}: Ban da mua 1 may dao [Bitcoin]!");
            SendClientMessage(playerid,-1, "{3dcc3f}{3dcc3f}He Thong Blockchain{3dcc3f}{3dcc3f}: Hay co gang dao de co cuoc song giau sang!");
        }
    }
    if(dialogid == DIALOG_BUY){
        if(response){
            new string[128];
            new buy = strval(inputtext);
            PlayerInfo[playerid][pCash] -= buy;
            PlayerInfo[playerid][pBitcoin] += buy/24.3;
            format(string,128,"He Thong Bitcoin: Ban da mua %d BTC",buy/24.3);
            SendClientMessage(playerid, -1,string);
        }
    }
    if(dialogid == DIALOG_SELL){
        if(response){
            new string[128];
            new sell = strval(inputtext);
            PlayerInfo[playerid][pBitcoin] -= sell;
            PlayerInfo[playerid][pCash] += sell * 500000.3;
            format(string,128,"He Thong Bitcoin: Ban da ban %d BTC",sell);
            SendClientMessage(playerid, -1,string);
        }
    }
    return 1;
}

//----------------------STOCK----------------------//
stock IsPlayerInRangeOfActor(playerid, actorid, Float:radius = 5.0)
{
        new Float:x,
            Float:y,
            Float:z;

        if (GetActorPos(actorid, x, y, z))
        {
            return IsPlayerInRangeOfPoint(playerid, radius, x, y, z);
        }
        return 0;
}

stock xulycatmayao(playerid){
    if(!PlayerInfo[playerid][pMayaodatroi])
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong Blockchain: Ban khong dat may ao.");
    }
    if(!IsPlayerInRangeOfDynamicObject(playerid, mayao, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong Blockchain: Ban khong nam trong pham vi cua may ao.");
    }
    GetDynamicObjectPos(mayao, x,y,z);
    SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s dat cat may ao cua minh va cat no di.", GetRPName(playerid));
    DestroyDynamicObject(mayao);
    DestroyDynamic3DTextLabel( Text3D:mayao3DText );
    ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
    PlayerInfo[playerid][pMayao] += 1;
    PlayerInfo[playerid][pMayaodatroi] = 0;
    return 1;
}

stock khoidongmayao(playerid){
    if(!IsPlayerInRangeOfDynamicObject(playerid, mayao, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong Blockchain: Ban khong nam trong pham vi cua may ao.");
    }
    DestroyDynamic3DTextLabel( Text3D:mayao3DText );
    format(string, sizeof(string), "May ao cua:%s\nCong Suat: 1000HZ/h\n[/khoidongmayao] de khoi dong\nKhoi Dong:{3dcc3f}ON{3dcc3f}", GetPlayerNameEx(playerid));
    mayao3DText = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
    PlayerInfo[playerid][pMayaobat] = 1;
    return 1;
}

stock khoitaomayao(playerid){
    if(PlayerInfo[playerid][pMayao] >= 1){
        GetPlayerPos(playerid, x, y, z);
        GetPlayerFacingAngle(playerid, a);
        format(string, sizeof(string), "May ao cua:%s\nCong Suat: 1000HZ/h\n[/khoidongmayao] de khoi dong\nKhoi Dong:{FF0000}OFF{FF0000}", GetPlayerNameEx(playerid));
        PlayerInfo[playerid][pMayao] -= 1;
        PlayerInfo[playerid][pMayaodatroi] = 1;
        PlayerInfo[playerid][pMayaotat] = 0;
        mayao = CreateDynamicObject(1650, x, y, z - 1.0, 0.0, 0.0, a, GetPlayerVirtualWorld(playerid), GetPlayerInterior(playerid));
        mayao3DText = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
        ApplyAnimation(playerid, "BOMBER", "BOM_Plant", 4.1, 0, 0, 0, 0, 0);
        SendProximityMessage(playerid, 20.0, SERVER_COLOR, "**{C2A2DA} %s da dat mot may ao xuong dat.", GetRPName(playerid));
    }else{
        SendClientMessage(playerid,-1,"He Thong Blockchain: Ban khong co may ao de dat.");
    }
    return 1;
}

stock tatmayao(playerid){
    if(!PlayerInfo[playerid][pMayaodatroi])
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong Blockchain: Ban khong dat may ao.");
    }
    if(!IsPlayerInRangeOfDynamicObject(playerid, mayao, 3.0))
    {
        return SCM(playerid, COLOR_SYNTAX, "He Thong Blockchain: Ban khong nam trong pham vi cua may ao.");
    }
    if(PlayerInfo[playerid][pMayaobat] == 1){
        PlayerInfo[playerid][pMayaotat] = 1;
        PlayerInfo[playerid][pMayaobat] = 0;
        DestroyDynamic3DTextLabel( Text3D:mayao3DText );
        format(string, sizeof(string), "May ao cua:%s\nCong Suat: 1000HZ/h\n[/khoidongmayao] de khoi dong\nKhoi Dong:{FF0000}OFF{FF0000}", GetPlayerNameEx(playerid));
        mayao3DText = CreateDynamic3DTextLabel(string, COLOR_LIGHTORANGE, x, y, z - 0.8, 10.0, .worldid = GetPlayerVirtualWorld(playerid), .interiorid = GetPlayerInterior(playerid));
    }
    else if(PlayerInfo[playerid][pMayaobat] == 0){
        SendClientMessage(playerid,COLOR_RED,"He Thong Blockchain: May ao da trong trang thai {FF0000}OFF{FF0000}");
    }
    return 1;
}
/*stock onplayeruser(playerid, PlayerText:playertextid){
    if(playertextid == bitcoin[playerid][3]){
        ShowPlayerDialog(playerid, DIALOG_BUY, DIALOG_STYLE_INPUT, "BITCOIN - [BUY]", "Vui Long Nhap Gia Tri:", "Dong Y", "Huy Bo");
        tatbangthongtinbitcoin(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    if(playertextid == bitcoin[playerid][4]){
        ShowPlayerDialog(playerid, DIALOG_SELL, DIALOG_STYLE_INPUT, "BITCOIN - [SELL]", "Vui Long Nhap Gia Tri:", "Dong Y", "Huy Bo");
        tatbangthongtinbitcoin(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    if(playertextid == bitcoin[playerid][14])
    {
        tatbangthongtinbitcoin(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    return true;
}*/

stock batbangthongtinbitcoin(playerid){
    bitcoin[playerid][0] = CreatePlayerTextDraw(playerid, 155.834640, 59.333320, "mdl-2018:Bitcoin");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][0], 0.000000, 0.000000);
    PlayerTextDrawTextSize(playerid, bitcoin[playerid][0], 343.000000, 215.000000);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][0], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][0], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][0], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][0], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][0], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][0], 4);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][0], 0);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][0], 0);

    bitcoin[playerid][1] = CreatePlayerTextDraw(playerid, 324.670288, 85.000114, "Giao Dich BitCoin");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][1], 0.450600, 2.451667);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][1], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][1], 255);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][1], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][1], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][1], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][1], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][1], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][1], 0);

    bitcoin[playerid][2] = CreatePlayerTextDraw(playerid, 329.355621, 119.999992, "1 BTC = $56230.30");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][2], 0.390629, 1.979166);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][2], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][2], -16776961);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][2], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][2], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][2], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][2], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][2], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][2], 0);

    bitcoin[playerid][3] = CreatePlayerTextDraw(playerid, 362.702941, 160.250030, "BUY");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][3], 0.400000, 1.600000);
    PlayerTextDrawTextSize(playerid, bitcoin[playerid][3], 0.000000, 50.000000);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][3], 2);
    PlayerTextDrawColor(playerid, bitcoin[playerid][3], -1);
    PlayerTextDrawUseBox(playerid, bitcoin[playerid][3], 1);
    PlayerTextDrawBoxColor(playerid, bitcoin[playerid][3], 8388863);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][3], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][3], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][3], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][3], 1);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][3], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][3], 0);
    PlayerTextDrawSetSelectable(playerid, bitcoin[playerid][3], true);

    bitcoin[playerid][4] = CreatePlayerTextDraw(playerid, 440.759674, 160.249893, "SELL");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][4], 0.408433, 1.693333);
    PlayerTextDrawTextSize(playerid, bitcoin[playerid][4], 0.000000, 50.000000);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][4], 2);
    PlayerTextDrawColor(playerid, bitcoin[playerid][4], -1);
    PlayerTextDrawUseBox(playerid, bitcoin[playerid][4], 1);
    PlayerTextDrawBoxColor(playerid, bitcoin[playerid][4], -16776961);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][4], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][4], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][4], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][4], 1);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][4], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][4], 0);
    PlayerTextDrawSetSelectable(playerid, bitcoin[playerid][4], true);

    bitcoin[playerid][5] = CreatePlayerTextDraw(playerid, 236.588577, 147.416610, "VI DIEN TU");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][5], 0.409838, 1.932500);
    PlayerTextDrawTextSize(playerid, bitcoin[playerid][5], 0.000000, 158.000000);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][5], 2);
    PlayerTextDrawColor(playerid, bitcoin[playerid][5], -1);
    PlayerTextDrawUseBox(playerid, bitcoin[playerid][5], 1);
    PlayerTextDrawBoxColor(playerid, bitcoin[playerid][5], 255);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][5], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][5], 1);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][5], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][5], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][5], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][5], 0);

    bitcoin[playerid][6] = CreatePlayerTextDraw(playerid, 158.345565, 174.833328, "Tai Khoan:");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][6], 0.213059, 1.343332);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][6], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][6], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][6], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][6], 1);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][6], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][6], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][6], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][6], 0);

    bitcoin[playerid][7] = CreatePlayerTextDraw(playerid, 216.649124, 174.833328, "Tyler_Pylon");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][7], 0.213059, 1.343332);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][7], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][7], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][7], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][7], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][7], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][7], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][7], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][7], 0);

    bitcoin[playerid][8] = CreatePlayerTextDraw(playerid, 159.751129, 198.166671, "So Dien Thoai:");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][8], 0.213059, 1.343332);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][8], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][8], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][8], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][8], 1);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][8], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][8], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][8], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][8], 0);

    bitcoin[playerid][9] = CreatePlayerTextDraw(playerid, 233.515884, 197.583312, "012345");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][9], 0.232737, 1.430832);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][9], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][9], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][9], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][9], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][9], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][9], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][9], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][9], 0);

    bitcoin[playerid][10] = CreatePlayerTextDraw(playerid, 160.219650, 223.249984, "Bitcoin:");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][10], 0.213059, 1.343332);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][10], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][10], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][10], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][10], 1);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][10], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][10], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][10], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][10], 0);

    bitcoin[playerid][11] = CreatePlayerTextDraw(playerid, 202.593490, 223.249954, "0 BTC");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][11], 0.232737, 1.430832);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][11], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][11], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][11], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][11], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][11], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][11], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][11], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][11], 0);

    bitcoin[playerid][12] = CreatePlayerTextDraw(playerid, 160.688171, 248.916671, "Tinh Trang May Ao:");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][12], 0.213059, 1.343332);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][12], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][12], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][12], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][12], 1);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][12], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][12], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][12], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][12], 0);

    bitcoin[playerid][13] = CreatePlayerTextDraw(playerid, 256.941955, 248.916641, "Hu Hong");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][13], 0.232737, 1.430832);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][13], 1);
    PlayerTextDrawColor(playerid, bitcoin[playerid][13], -1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][13], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][13], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][13], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][13], 2);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][13], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][13], 0);

    bitcoin[playerid][14] = CreatePlayerTextDraw(playerid, 488.653320, 64.366615, "X");
    PlayerTextDrawLetterSize(playerid, bitcoin[playerid][14], 0.400936, 1.284999);
    PlayerTextDrawTextSize(playerid, bitcoin[playerid][14], 0.000000, 13.000000);
    PlayerTextDrawAlignment(playerid, bitcoin[playerid][14], 2);
    PlayerTextDrawColor(playerid, bitcoin[playerid][14], -1);
    PlayerTextDrawUseBox(playerid, bitcoin[playerid][14], 1);
    PlayerTextDrawBoxColor(playerid, bitcoin[playerid][14], -16776961);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][14], 0);
    PlayerTextDrawSetOutline(playerid, bitcoin[playerid][14], 0);
    PlayerTextDrawBackgroundColor(playerid, bitcoin[playerid][14], 255);
    PlayerTextDrawFont(playerid, bitcoin[playerid][14], 1);
    PlayerTextDrawSetProportional(playerid, bitcoin[playerid][14], 1);
    PlayerTextDrawSetShadow(playerid, bitcoin[playerid][14], 0);
    PlayerTextDrawSetSelectable(playerid, bitcoin[playerid][14], true);

    PlayerTextDrawShow(playerid, bitcoin[playerid][0]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][1]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][2]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][3]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][4]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][5]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][6]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][7]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][8]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][9]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][10]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][11]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][12]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][13]);
    PlayerTextDrawShow(playerid, bitcoin[playerid][14]);
    return 1;
}

stock tatbangthongtinbitcoin(playerid){
    PlayerTextDrawHide(playerid, bitcoin[playerid][0]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][1]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][2]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][3]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][4]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][5]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][6]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][7]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][8]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][9]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][10]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][11]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][12]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][13]);
    PlayerTextDrawHide(playerid, bitcoin[playerid][14]);
    return 1;
}

hook OnPlayerClickPlayerTD(playerid, PlayerText:playertextid){
    if(playertextid == bitcoin[playerid][3]){
        ShowPlayerDialog(playerid, DIALOG_BUY, DIALOG_STYLE_INPUT, "BITCOIN - [BUY]", "Vui Long Nhap Gia Tri:", "Dong Y", "Huy Bo");
        tatbangthongtinbitcoin(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    if(playertextid == bitcoin[playerid][4]){
        ShowPlayerDialog(playerid, DIALOG_SELL, DIALOG_STYLE_INPUT, "BITCOIN - [SELL]", "Vui Long Nhap Gia Tri:", "Dong Y", "Huy Bo");
        tatbangthongtinbitcoin(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    if(playertextid == bitcoin[playerid][14])
    {
        tatbangthongtinbitcoin(playerid);
        CancelSelectTextDraw(playerid);
        return 1;
    }
    return true;
}