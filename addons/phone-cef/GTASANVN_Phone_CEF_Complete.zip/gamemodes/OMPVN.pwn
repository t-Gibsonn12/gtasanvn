#pragma disablerecursion
#pragma warning disable 212
#pragma warning disable 239,219
#define SSCANF_NO_NICE_FEATURES
#include <a_samp>
#undef MAX_PLAYERS
#define MAX_PLAYERS 1000
#include <a_http>
#include <a_mysql>
#include <foreach>
#include <sscanf2>
#include <streamer>
#include <streamer>
#include <ZCMD>
#include <mSelection>
#include <progress2>
#include <SKY> 
#include <selection>
#include <tp>
#include <core>
#include <float>
#include <sampvoice>
#include <map-zones>
#include <YSI_Coding\y_hooks>
#include <cef>

#include "./main/omp_base.pwn"
#include "./main/gtasanvn_auth.pwn"
#include "./main/notify.pwn"
#include "./main/gtasanvn_phone.pwn"
#include "./main/gtasanvn_speedo.pwn"
#include "./main/System/CameraAI.pwn"
//#include "./main/System/bitcoin.pwn"
//#include "./main/Job/JobMatuy.pwn"
//#include "./main/System/lucthungrac.pwn"
//#include "./main/System/phone.pwn"
//#include "./main/Job/systemmuaxang.pwn"
//#include "./main/Job/JobMatuy.pwn"
//#include "./main/System/Systemnghiavuquansu.pwn"
//#include "./main/System/Chiakhoaxe.pwn"


hook OnGameModeInit()
{
	print(">>>>>>>>>>>>>>>>>> TYLER Loading <<<<<<<<<<<<<<<<<<");

	return 1;
}
